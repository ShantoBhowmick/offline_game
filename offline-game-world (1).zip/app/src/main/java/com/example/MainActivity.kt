package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.core.data.AppDatabase
import com.example.core.data.GameRepository
import com.example.core.data.SettingsDataStore
import com.example.core.model.GameId
import com.example.games.BlockPuzzleScreen
import com.example.games.BubbleShooterScreen
import com.example.games.CandyMatchScreen
import com.example.games.CarromScreen
import com.example.games.CheckersScreen
import com.example.games.ChessScreen
import com.example.games.ConnectFourScreen
import com.example.games.FruitSliceScreen
import com.example.games.Game2048Screen
import com.example.games.JigsawPuzzleScreen
import com.example.games.LudoScreen
import com.example.games.MemoryMatchScreen
import com.example.games.MinesweeperScreen
import com.example.games.NumberPuzzleScreen
import com.example.games.SnakeGameScreen
import com.example.games.SolitaireScreen
import com.example.games.SudokuScreen
import com.example.games.TicTacToeScreen
import com.example.games.TwentyNineScreen
import com.example.games.WordPuzzleScreen
import com.example.ui.components.rememberGameSession
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.OfflineGameWorldTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        val database = AppDatabase.getInstance(applicationContext)
        val settings = SettingsDataStore(applicationContext)
        val repository = GameRepository(database.gameProgressDao(), settings)

        setContent {
            OfflineGameWorldTheme {
                OfflineGameWorldApp(repository = repository)
            }
        }
    }
}

@Composable
fun OfflineGameWorldApp(repository: GameRepository) {
    val navController = rememberNavController()
    val homeViewModel: HomeViewModel = viewModel(
        factory = remember(repository) { HomeViewModel.Factory(repository) }
    )
    val homeState by homeViewModel.uiState.collectAsStateWithLifecycle()

    NavHost(
        navController = navController,
        startDestination = "home",
        enterTransition = {
            slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(240)) + fadeIn(tween(220))
        },
        exitTransition = {
            fadeOut(tween(180))
        },
        popEnterTransition = {
            fadeIn(tween(200))
        },
        popExitTransition = {
            slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Right, tween(240)) + fadeOut(tween(180))
        }
    ) {
        composable("home") {
            HomeScreen(
                uiState = homeState,
                onSearchQueryChange = homeViewModel::onSearchQueryChange,
                onCategorySelected = homeViewModel::onCategorySelected,
                onToggleFavorite = homeViewModel::onToggleFavorite,
                onToggleMute = homeViewModel::onToggleMute,
                onOpenGame = { gameId ->
                    navController.navigate("game/${gameId.routeKey}") {
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(
            route = "game/{gameId}",
            arguments = listOf(navArgument("gameId") { type = NavType.StringType })
        ) { entry ->
            val gameId = GameId.fromRouteKey(entry.arguments?.getString("gameId"))
            if (gameId == null) {
                navController.popBackStack()
                return@composable
            }

            val session = rememberGameSession(
                gameId = gameId,
                repository = repository,
                onBack = { navController.popBackStack() }
            )

            if (session == null) {
                Box(
                    modifier = Modifier.fillMaxSize().background(BgObsidian),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = NeonCyan)
                }
            } else {
                when (gameId) {
                    GameId.LUDO -> LudoScreen(session)
                    GameId.TWENTY_NINE -> TwentyNineScreen(session)
                    GameId.TIC_TAC_TOE -> TicTacToeScreen(session)
                    GameId.CARROM -> CarromScreen(session)
                    GameId.SNAKE -> SnakeGameScreen(session)
                    GameId.CANDY_MATCH -> CandyMatchScreen(session)
                    GameId.SUDOKU -> SudokuScreen(session)
                    GameId.CHESS -> ChessScreen(session)
                    GameId.MINESWEEPER -> MinesweeperScreen(session)
                    GameId.GAME_2048 -> Game2048Screen(session)
                    GameId.BUBBLE_SHOOTER -> BubbleShooterScreen(session)
                    GameId.MEMORY_MATCH -> MemoryMatchScreen(session)
                    GameId.BLOCK_PUZZLE -> BlockPuzzleScreen(session)
                    GameId.SOLITAIRE -> SolitaireScreen(session)
                    GameId.CHECKERS -> CheckersScreen(session)
                    GameId.CONNECT_FOUR -> ConnectFourScreen(session)
                    GameId.FRUIT_SLICE -> FruitSliceScreen(session)
                    GameId.WORD_PUZZLE -> WordPuzzleScreen(session)
                    GameId.JIGSAW_PUZZLE -> JigsawPuzzleScreen(session)
                    GameId.NUMBER_PUZZLE -> NumberPuzzleScreen(session)
                }
            }
        }
    }
}
