package com.example.core.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

object SoundManager {
    @Volatile
    var isMuted: Boolean = false

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    fun playTap() = playTone(freqStart = 580.0, freqEnd = 680.0, durationMs = 45, volume = 0.22)
    fun playMove() = playTone(freqStart = 420.0, freqEnd = 520.0, durationMs = 60, volume = 0.25)
    fun playCapture() = playTone(freqStart = 720.0, freqEnd = 280.0, durationMs = 110, volume = 0.30)
    fun playMatch() = playChord(listOf(523.25, 659.25, 783.99), durationMs = 140, volume = 0.26)
    fun playSlice() = playTone(freqStart = 1200.0, freqEnd = 380.0, durationMs = 90, volume = 0.28)
    fun playBounce() = playTone(freqStart = 320.0, freqEnd = 460.0, durationMs = 55, volume = 0.24)
    fun playDice() = playTone(freqStart = 300.0, freqEnd = 650.0, durationMs = 80, volume = 0.25)
    fun playError() = playTone(freqStart = 210.0, freqEnd = 140.0, durationMs = 150, volume = 0.30)
    fun playWin() = playArpeggio(listOf(523.25, 659.25, 783.99, 1046.50), noteMs = 95)
    fun playLose() = playArpeggio(listOf(392.0, 349.23, 311.13, 261.63), noteMs = 120)

    private fun playTone(freqStart: Double, freqEnd: Double, durationMs: Int, volume: Double) {
        if (isMuted) return
        scope.launch {
            runCatching {
                val sampleRate = 22050
                val count = (sampleRate * durationMs / 1000).coerceAtLeast(1)
                val samples = ShortArray(count)
                var phase = 0.0
                for (i in 0 until count) {
                    val t = i.toDouble() / count
                    val freq = freqStart + (freqEnd - freqStart) * t
                    val env = exp(-3.5 * t)
                    phase += 2.0 * PI * freq / sampleRate
                    samples[i] = (sin(phase) * env * volume * Short.MAX_VALUE).toInt().toShort()
                }
                writePcm(samples, sampleRate)
            }
        }
    }

    private fun playChord(freqs: List<Double>, durationMs: Int, volume: Double) {
        if (isMuted) return
        scope.launch {
            runCatching {
                val sampleRate = 22050
                val count = (sampleRate * durationMs / 1000).coerceAtLeast(1)
                val samples = ShortArray(count)
                for (i in 0 until count) {
                    val t = i.toDouble() / count
                    val env = exp(-3.0 * t)
                    var sum = 0.0
                    for (f in freqs) {
                        sum += sin(2.0 * PI * f * i / sampleRate)
                    }
                    samples[i] = ((sum / freqs.size) * env * volume * Short.MAX_VALUE).toInt().toShort()
                }
                writePcm(samples, sampleRate)
            }
        }
    }

    private fun playArpeggio(freqs: List<Double>, noteMs: Int) {
        if (isMuted) return
        scope.launch {
            runCatching {
                val sampleRate = 22050
                val perNote = (sampleRate * noteMs / 1000).coerceAtLeast(1)
                val samples = ShortArray(perNote * freqs.size)
                freqs.forEachIndexed { idx, f ->
                    for (i in 0 until perNote) {
                        val t = i.toDouble() / perNote
                        val env = exp(-2.8 * t)
                        val v = sin(2.0 * PI * f * i / sampleRate) * env * 0.28 * Short.MAX_VALUE
                        samples[idx * perNote + i] = v.toInt().toShort()
                    }
                }
                writePcm(samples, sampleRate)
            }
        }
    }

    private fun writePcm(samples: ShortArray, sampleRate: Int) {
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(samples.size * 2)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBuf)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(samples, 0, samples.size)
        track.play()
        val sleepMs = (samples.size * 1000L / sampleRate) + 40L
        Thread.sleep(sleepMs)
        track.stop()
        track.release()
    }
}
