package com.example.core.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GameProgressDao {
    @Query("SELECT * FROM game_progress")
    fun observeAllProgress(): Flow<List<GameProgressEntity>>

    @Query("SELECT * FROM game_progress WHERE gameId = :gameId")
    fun observeGameProgress(gameId: String): Flow<GameProgressEntity?>

    @Query("SELECT * FROM game_progress WHERE gameId = :gameId")
    suspend fun getProgress(gameId: String): GameProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgress(entity: GameProgressEntity)

    @Query("UPDATE game_progress SET isFavorite = :favorite WHERE gameId = :gameId")
    suspend fun updateFavorite(gameId: String, favorite: Boolean)

    @Query("UPDATE game_progress SET savedStateJson = :savedJson, lastPlayedTimestamp = :timestamp WHERE gameId = :gameId")
    suspend fun updateSavedState(gameId: String, savedJson: String?, timestamp: Long)
}
