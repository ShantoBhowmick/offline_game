package com.example.core.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_progress")
data class GameProgressEntity(
    @PrimaryKey val gameId: String,
    val bestScore: Int = 0,
    val gamesPlayed: Int = 0,
    val gamesWon: Int = 0,
    val isFavorite: Boolean = false,
    val lastPlayedTimestamp: Long = 0L,
    val savedStateJson: String? = null,
    val lastDifficulty: String = "MEDIUM",
    val lastPlayerMode: String = "SINGLE_PLAYER"
)
