package com.example.core.data

import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.core.model.GameId
import com.example.core.model.PlayerMode
import kotlinx.coroutines.flow.Flow

class GameRepository(
    private val dao: GameProgressDao,
    private val settings: SettingsDataStore
) {
    val allProgress: Flow<List<GameProgressEntity>> = dao.observeAllProgress()
    val isMuted: Flow<Boolean> = settings.isMutedFlow
    val hapticsEnabled: Flow<Boolean> = settings.hapticsEnabledFlow

    fun observeGame(gameId: GameId): Flow<GameProgressEntity?> =
        dao.observeGameProgress(gameId.routeKey)

    suspend fun getProgress(gameId: GameId): GameProgressEntity? =
        dao.getProgress(gameId.routeKey)

    suspend fun setMuted(muted: Boolean) {
        SoundManager.isMuted = muted
        settings.setMuted(muted)
    }

    suspend fun toggleFavorite(gameId: GameId) {
        val current = dao.getProgress(gameId.routeKey)
        if (current == null) {
            dao.upsertProgress(
                GameProgressEntity(
                    gameId = gameId.routeKey,
                    isFavorite = true
                )
            )
        } else {
            dao.updateFavorite(gameId.routeKey, !current.isFavorite)
        }
    }

    suspend fun markGameOpened(gameId: GameId, difficulty: Difficulty, mode: PlayerMode) {
        val current = dao.getProgress(gameId.routeKey) ?: GameProgressEntity(gameId = gameId.routeKey)
        dao.upsertProgress(
            current.copy(
                lastPlayedTimestamp = System.currentTimeMillis(),
                lastDifficulty = difficulty.name,
                lastPlayerMode = mode.name
            )
        )
    }

    suspend fun saveInProgressState(gameId: GameId, stateJson: String?) {
        val current = dao.getProgress(gameId.routeKey) ?: GameProgressEntity(gameId = gameId.routeKey)
        dao.upsertProgress(
            current.copy(
                savedStateJson = stateJson,
                lastPlayedTimestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun recordGameResult(
        gameId: GameId,
        score: Int,
        won: Boolean,
        clearSavedState: Boolean = true
    ) {
        val current = dao.getProgress(gameId.routeKey) ?: GameProgressEntity(gameId = gameId.routeKey)
        dao.upsertProgress(
            current.copy(
                bestScore = maxOf(current.bestScore, score),
                gamesPlayed = current.gamesPlayed + 1,
                gamesWon = current.gamesWon + if (won) 1 else 0,
                lastPlayedTimestamp = System.currentTimeMillis(),
                savedStateJson = if (clearSavedState) null else current.savedStateJson
            )
        )
    }
}
