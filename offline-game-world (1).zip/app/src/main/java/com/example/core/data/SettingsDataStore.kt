package com.example.core.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "offline_game_world_settings")

class SettingsDataStore(private val context: Context) {
    private val keyMuted = booleanPreferencesKey("sound_muted")
    private val keyHaptics = booleanPreferencesKey("haptics_enabled")

    val isMutedFlow: Flow<Boolean> = context.settingsDataStore.data.map { prefs ->
        prefs[keyMuted] ?: false
    }

    val hapticsEnabledFlow: Flow<Boolean> = context.settingsDataStore.data.map { prefs ->
        prefs[keyHaptics] ?: true
    }

    suspend fun setMuted(muted: Boolean) {
        context.settingsDataStore.edit { prefs ->
            prefs[keyMuted] = muted
        }
    }

    suspend fun setHapticsEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { prefs ->
            prefs[keyHaptics] = enabled
        }
    }
}
