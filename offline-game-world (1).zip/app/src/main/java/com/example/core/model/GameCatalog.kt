package com.example.core.model

import androidx.compose.ui.graphics.Color

enum class GameId(val routeKey: String) {
    LUDO("ludo"),
    TWENTY_NINE("twenty_nine"),
    TIC_TAC_TOE("tic_tac_toe"),
    CARROM("carrom"),
    SNAKE("snake"),
    CANDY_MATCH("candy_match"),
    SUDOKU("sudoku"),
    CHESS("chess"),
    MINESWEEPER("minesweeper"),
    GAME_2048("game_2048"),
    BUBBLE_SHOOTER("bubble_shooter"),
    MEMORY_MATCH("memory_match"),
    BLOCK_PUZZLE("block_puzzle"),
    SOLITAIRE("solitaire"),
    CHECKERS("checkers"),
    CONNECT_FOUR("connect_four"),
    FRUIT_SLICE("fruit_slice"),
    WORD_PUZZLE("word_puzzle"),
    JIGSAW_PUZZLE("jigsaw_puzzle"),
    NUMBER_PUZZLE("number_puzzle");

    companion object {
        fun fromRouteKey(key: String?): GameId? = entries.find { it.routeKey == key }
    }
}

enum class GameCategory(val displayName: String) {
    ALL("All Games"),
    BOARD("Board"),
    CARDS("Cards"),
    PUZZLE("Puzzle"),
    ARCADE("Arcade"),
    STRATEGY("Strategy")
}

enum class Difficulty(val label: String) {
    EASY("Easy"),
    MEDIUM("Medium"),
    HARD("Hard")
}

enum class PlayerMode(val label: String) {
    SINGLE_PLAYER("1P vs AI"),
    LOCAL_MULTIPLAYER("Pass & Play")
}

data class GameInfo(
    val id: GameId,
    val title: String,
    val subtitle: String,
    val category: GameCategory,
    val accentStart: Color,
    val accentEnd: Color,
    val isFeatured: Boolean = false,
    val isPopular: Boolean = false,
    val supportsDifficulty: Boolean = true,
    val supportsMultiplayer: Boolean = false,
    val playersLabel: String = "1P",
    val instructions: List<String>
)

object GameCatalog {
    val games: List<GameInfo> = listOf(
        GameInfo(
            id = GameId.LUDO,
            title = "Ludo Royal",
            subtitle = "Classic 4-player cross board race",
            category = GameCategory.BOARD,
            accentStart = Color(0xFFFFB800),
            accentEnd = Color(0xFFFF5A5F),
            isFeatured = true,
            isPopular = true,
            supportsDifficulty = false,
            supportsMultiplayer = true,
            playersLabel = "1P - 4P",
            instructions = listOf(
                "Tap the Dice to roll. Roll a 6 to move a token out of your Home Base.",
                "Tap any highlighted token to advance it clockwise around the track.",
                "Landing on an opponent's token sends it back to base—unless it rests on a Star safe square.",
                "Rolling a 6 or capturing an opponent grants a bonus roll. Reach the center crown with all 4 tokens first!"
            )
        ),
        GameInfo(
            id = GameId.TWENTY_NINE,
            title = "29 Card Game",
            subtitle = "Partnership trump trick-taker",
            category = GameCategory.CARDS,
            accentStart = Color(0xFF00E5FF),
            accentEnd = Color(0xFF3B82F6),
            isFeatured = true,
            isPopular = true,
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "2v2 AI",
            instructions = listOf(
                "32 cards are used (7 to Ace). Card points: Jack = 3, Nine = 2, Ace = 1, Ten = 1, others = 0 (28 pts + 1 for last trick = 29).",
                "Bid between 16 and 28 to win the contract and choose the hidden Trump suit.",
                "Players must follow the led suit. If void, you may reveal the hidden Trump to trump the trick.",
                "Your team (South & North) wins the round by meeting or exceeding your bid."
            )
        ),
        GameInfo(
            id = GameId.TIC_TAC_TOE,
            title = "Tic Tac Toe",
            subtitle = "Neon 3x3 tactical duel",
            category = GameCategory.BOARD,
            accentStart = Color(0xFF00E5FF),
            accentEnd = Color(0xFF8B5CF6),
            isPopular = true,
            supportsDifficulty = true,
            supportsMultiplayer = true,
            playersLabel = "1P / 2P",
            instructions = listOf(
                "Take turns placing X and O on the 3x3 grid.",
                "Align 3 of your marks horizontally, vertically, or diagonally to win.",
                "Switch between 1P vs AI (Easy, Medium, Unbeatable Hard) or 2P Pass & Play."
            )
        ),
        GameInfo(
            id = GameId.CARROM,
            title = "Carrom Striker",
            subtitle = "Physics disc pocketing arena",
            category = GameCategory.BOARD,
            accentStart = Color(0xFFD97706),
            accentEnd = Color(0xFF78350F),
            isFeatured = true,
            isPopular = true,
            supportsDifficulty = true,
            supportsMultiplayer = true,
            playersLabel = "1P / 2P",
            instructions = listOf(
                "Slide the striker along your baseline using the slider or by dragging it left/right.",
                "Drag back from the striker to aim and set shot power, then release to strike!",
                "Pocket all of your assigned coins (White or Black) plus the Red Queen (pocket a coin immediately after to cover her).",
                "Pocketing your striker incurs a foul and returns a coin."
            )
        ),
        GameInfo(
            id = GameId.SNAKE,
            title = "Neon Snake",
            subtitle = "Classic arcade serpent rush",
            category = GameCategory.ARCADE,
            accentStart = Color(0xFF10B981),
            accentEnd = Color(0xFF06B6D4),
            isPopular = true,
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Swipe anywhere on the arena or use the on-screen D-pad to steer the snake.",
                "Eat glowing energy apples (+10) and golden bonus fruits (+30) to grow longer.",
                "Avoid hitting the arena walls or your own tail! Higher difficulty increases speed."
            )
        ),
        GameInfo(
            id = GameId.CANDY_MATCH,
            title = "Gem Candy Pop",
            subtitle = "Sweet match-3 cascade puzzle",
            category = GameCategory.PUZZLE,
            accentStart = Color(0xFFFF2E93),
            accentEnd = Color(0xFF8B5CF6),
            isFeatured = true,
            isPopular = true,
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Tap one gem and tap an adjacent gem (or swipe) to swap them.",
                "Match 3 or more identical gems in a row or column to clear them and trigger cascades.",
                "Reach the target score before running out of moves!"
            )
        ),
        GameInfo(
            id = GameId.SUDOKU,
            title = "Sudoku Zen",
            subtitle = "9x9 logic number placement",
            category = GameCategory.PUZZLE,
            accentStart = Color(0xFF3B82F6),
            accentEnd = Color(0xFF6366F1),
            isPopular = true,
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Fill every row, column, and 3x3 subgrid with digits 1 through 9 without repeats.",
                "Tap a cell and select a digit below. Toggle Notes mode to jot down candidates.",
                "Use Hint if you get stuck, and avoid 3 mistakes!"
            )
        ),
        GameInfo(
            id = GameId.CHESS,
            title = "Grand Chess",
            subtitle = "Full 8x8 strategy & tactics",
            category = GameCategory.STRATEGY,
            accentStart = Color(0xFF6366F1),
            accentEnd = Color(0xFF1E1B4B),
            isFeatured = true,
            isPopular = true,
            supportsDifficulty = true,
            supportsMultiplayer = true,
            playersLabel = "1P / 2P",
            instructions = listOf(
                "Tap a piece to reveal all legal moves including castling, en passant, and captures.",
                "Advance pawns to the opposite back rank to promote into Queen, Rook, Bishop, or Knight.",
                "Checkmate the opponent's King! Play against the offline AI or challenge a friend locally."
            )
        ),
        GameInfo(
            id = GameId.MINESWEEPER,
            title = "Mine Sweeper",
            subtitle = "Classic hazard deduction grid",
            category = GameCategory.STRATEGY,
            accentStart = Color(0xFFFF5A5F),
            accentEnd = Color(0xFFF59E0B),
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Tap a tile to uncover it. Your very first tap is always safe!",
                "Numbers show how many mines lie in the 8 surrounding tiles.",
                "Switch to Flag mode (or long-press a tile) to mark suspected mines. Clear all safe tiles to win."
            )
        ),
        GameInfo(
            id = GameId.GAME_2048,
            title = "2048 Fusion",
            subtitle = "Slide & merge power-of-two tiles",
            category = GameCategory.PUZZLE,
            accentStart = Color(0xFFF59E0B),
            accentEnd = Color(0xFFEA580C),
            isPopular = true,
            supportsDifficulty = false,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Swipe Up, Down, Left, or Right to slide all tiles across the 4x4 board.",
                "Matching tiles collide and merge into their sum (2+2=4, 4+4=8 ... up to 2048!).",
                "Use Undo to revert a misstep. Keep merging past 2048 for high scores!"
            )
        ),
        GameInfo(
            id = GameId.BUBBLE_SHOOTER,
            title = "Bubble Burst",
            subtitle = "Aim, bounce & pop color clusters",
            category = GameCategory.ARCADE,
            accentStart = Color(0xFFEC4899),
            accentEnd = Color(0xFF06B6D4),
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Drag across the arena to aim your cannon—use side walls to bank tricky ricochet shots.",
                "Release to launch the bubble. Connect 3 or more of the same color to pop them!",
                "Any bubbles left floating without an anchor to the ceiling drop for bonus points."
            )
        ),
        GameInfo(
            id = GameId.MEMORY_MATCH,
            title = "Memory Pairs",
            subtitle = "Card flip recall challenge",
            category = GameCategory.PUZZLE,
            accentStart = Color(0xFF8B5CF6),
            accentEnd = Color(0xFFEC4899),
            supportsDifficulty = true,
            supportsMultiplayer = true,
            playersLabel = "1P / 2P",
            instructions = listOf(
                "Tap any two face-down cards to flip them over.",
                "Find matching symbol pairs to keep them revealed and build streak combos.",
                "Clear the entire grid in as few moves as possible, or outscore a friend in 2P mode!"
            )
        ),
        GameInfo(
            id = GameId.BLOCK_PUZZLE,
            title = "Block Matrix",
            subtitle = "10x10 polyomino line clearer",
            category = GameCategory.PUZZLE,
            accentStart = Color(0xFF06B6D4),
            accentEnd = Color(0xFF3B82F6),
            isPopular = true,
            supportsDifficulty = false,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Select one of the 3 blocks below, then tap or drag onto the 10x10 board to place it.",
                "Complete full horizontal rows or vertical columns to clear lines and score combo multipliers.",
                "The game ends when none of the available pieces fit on the board."
            )
        ),
        GameInfo(
            id = GameId.SOLITAIRE,
            title = "Klondike Solitaire",
            subtitle = "Timeless single-player patience",
            category = GameCategory.CARDS,
            accentStart = Color(0xFF10B981),
            accentEnd = Color(0xFF047857),
            isPopular = true,
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Build 4 Foundation piles up by suit from Ace to King.",
                "In the Tableau, stack cards in descending order with alternating colors (Red on Black).",
                "Tap a card to select or auto-move it, or draw new cards from the Stock pile."
            )
        ),
        GameInfo(
            id = GameId.CHECKERS,
            title = "Checkers Pro",
            subtitle = "Diagonal jumps & king crowns",
            category = GameCategory.STRATEGY,
            accentStart = Color(0xFFEF4444),
            accentEnd = Color(0xFF991B1B),
            supportsDifficulty = true,
            supportsMultiplayer = true,
            playersLabel = "1P / 2P",
            instructions = listOf(
                "Move your pieces diagonally forward onto dark squares.",
                "Jump over adjacent opponent pieces to capture them—multi-jumps are mandatory!",
                "Reach the far edge to crown a King, which can move and capture both forward and backward."
            )
        ),
        GameInfo(
            id = GameId.CONNECT_FOUR,
            title = "Connect 4 Neon",
            subtitle = "Vertical disc drop strategy",
            category = GameCategory.BOARD,
            accentStart = Color(0xFFFBBF24),
            accentEnd = Color(0xFFEF4444),
            supportsDifficulty = true,
            supportsMultiplayer = true,
            playersLabel = "1P / 2P",
            instructions = listOf(
                "Tap any column to drop your glowing disc to the lowest open slot.",
                "Connect 4 discs in a row horizontally, vertically, or diagonally to win!",
                "Block your opponent's threats while setting up double-win traps."
            )
        ),
        GameInfo(
            id = GameId.FRUIT_SLICE,
            title = "Fruit Blade",
            subtitle = "60fps arcade swipe slicer",
            category = GameCategory.ARCADE,
            accentStart = Color(0xFF22C55E),
            accentEnd = Color(0xFFEAB308),
            isFeatured = true,
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Swipe your finger across airborne fruits to slice them in half!",
                "Slice multiple fruits in a single swipe for Combo bonus points.",
                "Do NOT slice dark Bombs—and don't let more than 3 fruits drop unsliced!"
            )
        ),
        GameInfo(
            id = GameId.WORD_PUZZLE,
            title = "Word Cipher",
            subtitle = "Offline word deduction puzzle",
            category = GameCategory.PUZZLE,
            accentStart = Color(0xFF14B8A6),
            accentEnd = Color(0xFF0F766E),
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Guess the hidden English word within 6 tries (4, 5, or 6 letters by difficulty).",
                "Green = right letter in the right spot. Amber = right letter in the wrong spot. Gray = not in the word.",
                "Use the Hint button to reveal one letter if you need a clue."
            )
        ),
        GameInfo(
            id = GameId.JIGSAW_PUZZLE,
            title = "Art Jigsaw",
            subtitle = "Interlocking tile art assembly",
            category = GameCategory.PUZZLE,
            accentStart = Color(0xFFA855F7),
            accentEnd = Color(0xFF6366F1),
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Tap any two puzzle tiles to swap their positions and reconstruct the artwork.",
                "Tiles placed in their true position lock in with a golden highlight!",
                "Toggle the Ghost Preview eye icon anytime to peek at the finished picture."
            )
        ),
        GameInfo(
            id = GameId.NUMBER_PUZZLE,
            title = "Slide 15",
            subtitle = "Classic sliding tile order",
            category = GameCategory.PUZZLE,
            accentStart = Color(0xFF0EA5E9),
            accentEnd = Color(0xFF2563EB),
            supportsDifficulty = true,
            supportsMultiplayer = false,
            playersLabel = "1P",
            instructions = listOf(
                "Tap any numbered tile adjacent to the empty slot (or swipe toward it) to slide it.",
                "Arrange all numbers sequentially from 1 upward with the blank space at the bottom-right.",
                "Choose 3x3 (Easy), 4x4 (Medium), or 5x5 (Hard) grids."
            )
        )
    )

    fun getById(id: GameId): GameInfo = games.first { it.id == id }
}
