package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextSecondary

private data class BlockShape(
    val cells: List<Pair<Int, Int>>, // (dr, dc)
    val color: Color
)

private val blockPalette = listOf(
    BlockShape(listOf(0 to 0), NeonCyan),
    BlockShape(listOf(0 to 0, 0 to 1), NeonAmber),
    BlockShape(listOf(0 to 0, 1 to 0), NeonAmber),
    BlockShape(listOf(0 to 0, 0 to 1, 0 to 2), NeonEmerald),
    BlockShape(listOf(0 to 0, 1 to 0, 2 to 0), NeonEmerald),
    BlockShape(listOf(0 to 0, 0 to 1, 1 to 0, 1 to 1), NeonMagenta),
    BlockShape(listOf(0 to 0, 1 to 0, 1 to 1), NeonViolet),
    BlockShape(listOf(0 to 0, 0 to 1, 1 to 1), Color(0xFF3B82F6)),
    BlockShape(listOf(0 to 0, 0 to 1, 0 to 2, 1 to 1), Color(0xFFFF5A5F)),
    BlockShape(listOf(0 to 0, 0 to 1, 0 to 2, 1 to 0, 1 to 1, 1 to 2), Color(0xFF14B8A6)),
    BlockShape(listOf(0 to 0, 1 to 0, 2 to 0, 2 to 1), Color(0xFFF97316)),
    BlockShape(listOf(0 to 0, 0 to 1, 0 to 2, 0 to 3), Color(0xFF38BDF8))
)

@Composable
fun BlockPuzzleScreen(session: GameSessionController) {
    val size = 10
    var grid by remember { mutableStateOf(List(size * size) { null as Color? }) }
    var tray by remember { mutableStateOf(List(3) { blockPalette.random() as BlockShape? }) }
    var selectedTrayIdx by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }

    fun canPlace(b: List<Color?>, shape: BlockShape, r: Int, c: Int): Boolean {
        return shape.cells.all { (dr, dc) ->
            val nr = r + dr
            val nc = c + dc
            nr in 0 until size && nc in 0 until size && b[nr * size + nc] == null
        }
    }

    fun anyPieceFits(b: List<Color?>, pieces: List<BlockShape?>): Boolean {
        val active = pieces.filterNotNull()
        if (active.isEmpty()) return true
        for (shape in active) {
            for (r in 0 until size) {
                for (c in 0 until size) {
                    if (canPlace(b, shape, r, c)) return true
                }
            }
        }
        return false
    }

    fun placeAt(r: Int, c: Int) {
        if (isPaused || isGameOver) return
        val shape = tray.getOrNull(selectedTrayIdx) ?: return
        if (!canPlace(grid, shape, r, c)) {
            SoundManager.playError()
            return
        }

        val next = grid.toMutableList()
        shape.cells.forEach { (dr, dc) ->
            next[(r + dr) * size + (c + dc)] = shape.color
        }

        // Check full rows & columns simultaneously
        val fullRows = (0 until size).filter { row -> (0 until size).all { col -> next[row * size + col] != null } }
        val fullCols = (0 until size).filter { col -> (0 until size).all { row -> next[row * size + col] != null } }

        fullRows.forEach { row -> for (col in 0 until size) next[row * size + col] = null }
        fullCols.forEach { col -> for (row in 0 until size) next[row * size + col] = null }

        val clearedLines = fullRows.size + fullCols.size
        val gain = shape.cells.size * 10 + if (clearedLines > 0) clearedLines * clearedLines * 100 else 0
        score += gain
        if (clearedLines > 0) SoundManager.playMatch() else SoundManager.playMove()

        grid = next
        var nextTray = tray.toMutableList()
        nextTray[selectedTrayIdx] = null
        if (nextTray.all { it == null }) {
            nextTray = MutableList(3) { blockPalette.random() }
        }
        tray = nextTray
        selectedTrayIdx = nextTray.indexOfFirst { it != null }.coerceAtLeast(0)

        if (!anyPieceFits(next, nextTray)) {
            isGameOver = true
            SoundManager.playLose()
            session.onRecordResult(score, score >= 500, true)
        }
    }

    fun restart() {
        grid = List(size * size) { null }
        tray = List(3) { blockPalette.random() }
        selectedTrayIdx = 0
        score = 0
        isGameOver = false
        isPaused = false
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        scoreText = "SCORE $score",
        bestScoreText = "BEST ${maxOf(score, session.bestScore)}",
        gameOverTitle = if (isGameOver) "No Space Left!" else null,
        gameOverSubtitle = "Final Score: $score",
        isWin = score >= 500,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Select a block below, then tap top-left target cell on the 10x10 grid",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Spacer(Modifier.height(10.dp))

            // 10x10 Matrix
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 360.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(SurfaceCard)
                    .border(1.5.dp, SurfaceBorder, RoundedCornerShape(16.dp))
                    .padding(6.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    for (r in 0 until size) {
                        Row(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            for (c in 0 until size) {
                                val cellColor = grid[r * size + c]
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(cellColor ?: Color(0xFF0E1426))
                                        .border(0.5.dp, SurfaceBorder, RoundedCornerShape(4.dp))
                                        .clickable { placeAt(r, c) }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // 3 Piece Tray
            Row(
                modifier = Modifier.fillMaxWidth().widthIn(max = 360.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                tray.forEachIndexed { idx, shape ->
                    val isSelected = idx == selectedTrayIdx && shape != null
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(92.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) Color(0xFF1A2442) else SurfaceCard)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) NeonCyan else SurfaceBorder,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable(enabled = shape != null) {
                                selectedTrayIdx = idx
                                SoundManager.playTap()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (shape != null) {
                            val maxR = shape.cells.maxOf { it.first }
                            val maxC = shape.cells.maxOf { it.second }
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                for (r in 0..maxR) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        for (c in 0..maxC) {
                                            val filled = (r to c) in shape.cells
                                            Box(
                                                modifier = Modifier
                                                    .size(16.dp)
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(if (filled) shape.color else Color.Transparent)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
