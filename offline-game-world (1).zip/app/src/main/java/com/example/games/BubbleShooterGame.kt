package com.example.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

private val bubblePalette = listOf(
    NeonMagenta,
    NeonCyan,
    NeonAmber,
    NeonEmerald,
    NeonViolet,
    NeonCoral
)

private data class BubbleCell(val row: Int, val col: Int, val colorIdx: Int)
private data class FlyingBubble(var x: Float, var y: Float, var vx: Float, var vy: Float, val colorIdx: Int)

@Composable
fun BubbleShooterScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    val cols = 9
    val maxRows = 12
    val colorCount = when (difficulty) {
        Difficulty.EASY -> 4; Difficulty.MEDIUM -> 5; Difficulty.HARD -> 6
    }

    fun initialGrid(): List<BubbleCell> {
        val list = mutableListOf<BubbleCell>()
        for (r in 0 until 5) {
            val rowCols = if (r % 2 == 1) cols - 1 else cols
            for (c in 0 until rowCols) {
                list.add(BubbleCell(r, c, (0 until colorCount).random()))
            }
        }
        return list
    }

    var bubbles by remember(difficulty) { mutableStateOf(initialGrid()) }
    var currentColor by remember(difficulty) { mutableIntStateOf((0 until colorCount).random()) }
    var nextColor by remember(difficulty) { mutableIntStateOf((0 until colorCount).random()) }
    var aimAngle by remember { mutableFloatStateOf(-Math.PI.toFloat() / 2f) }
    var flying by remember { mutableStateOf<FlyingBubble?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var shotsTaken by remember { mutableIntStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }
    var gameResult by remember { mutableIntStateOf(0) } // 0 playing, 1 won, -1 lost

    fun cellCenter(row: Int, col: Int): Pair<Float, Float> {
        val radius = 1f / (cols * 2f)
        val xOffset = if (row % 2 == 1) radius else 0f
        val cx = radius + xOffset + col * (radius * 2f)
        val cy = radius + row * (radius * 1.75f)
        return cx to cy
    }

    fun neighborsOf(r: Int, c: Int): List<Pair<Int, Int>> {
        val even = r % 2 == 0
        return if (even) {
            listOf(r to c - 1, r to c + 1, r - 1 to c - 1, r - 1 to c, r + 1 to c - 1, r + 1 to c)
        } else {
            listOf(r to c - 1, r to c + 1, r - 1 to c, r - 1 to c + 1, r + 1 to c, r + 1 to c + 1)
        }
    }

    fun restart(diff: Difficulty = difficulty) {
        val cc = when (diff) { Difficulty.EASY -> 4; Difficulty.MEDIUM -> 5; Difficulty.HARD -> 6 }
        bubbles = initialGrid()
        currentColor = (0 until cc).random()
        nextColor = (0 until cc).random()
        flying = null
        score = 0
        shotsTaken = 0
        gameResult = 0
        isPaused = false
    }

    fun snapFlyingBubble(fb: FlyingBubble) {
        val radius = 1f / (cols * 2f)
        val occupied = bubbles.associateBy { it.row to it.col }
        var bestR = 0
        var bestC = 0
        var bestDist = Float.MAX_VALUE

        for (r in 0 until maxRows) {
            val rowCols = if (r % 2 == 1) cols - 1 else cols
            for (c in 0 until rowCols) {
                if ((r to c) in occupied) continue
                val hasSupport = r == 0 || neighborsOf(r, c).any { it in occupied }
                if (!hasSupport) continue
                val (cx, cy) = cellCenter(r, c)
                val d = hypot(fb.x - cx, fb.y - cy)
                if (d < bestDist) {
                    bestDist = d
                    bestR = r
                    bestC = c
                }
            }
        }

        val placed = BubbleCell(bestR, bestC, fb.colorIdx)
        val map = (bubbles + placed).associateBy { it.row to it.col }.toMutableMap()

        // BFS same-color cluster
        val cluster = mutableSetOf<Pair<Int, Int>>()
        val q = ArrayDeque<Pair<Int, Int>>()
        q.add(bestR to bestC)
        while (q.isNotEmpty()) {
            val cur = q.removeFirst()
            if (cur in cluster) continue
            val cell = map[cur] ?: continue
            if (cell.colorIdx != fb.colorIdx) continue
            cluster.add(cur)
            neighborsOf(cur.first, cur.second).forEach { n ->
                if (n !in cluster && map[n]?.colorIdx == fb.colorIdx) q.add(n)
            }
        }

        if (cluster.size >= 3) {
            cluster.forEach { map.remove(it) }
            // Drop floating bubbles not connected to row 0
            val anchored = mutableSetOf<Pair<Int, Int>>()
            val aq = ArrayDeque<Pair<Int, Int>>()
            map.keys.filter { it.first == 0 }.forEach { aq.add(it) }
            while (aq.isNotEmpty()) {
                val cur = aq.removeFirst()
                if (cur in anchored || cur !in map) continue
                anchored.add(cur)
                neighborsOf(cur.first, cur.second).forEach { n ->
                    if (n !in anchored && n in map) aq.add(n)
                }
            }
            val droppedCount = map.size - anchored.size
            val poppedCount = cluster.size
            score += poppedCount * 20 + droppedCount * 40
            bubbles = anchored.mapNotNull { map[it] }
            SoundManager.playMatch()
        } else {
            bubbles = map.values.toList()
            SoundManager.playTap()
        }

        shotsTaken++
        // Every 7 shots, add a new row from top
        if (shotsTaken % 7 == 0 && bubbles.isNotEmpty()) {
            val shifted = bubbles.map { it.copy(row = it.row + 1) }
            val newTop = (0 until cols).map { c -> BubbleCell(0, c, (0 until colorCount).random()) }
            bubbles = shifted + newTop
        }

        val activeColors = bubbles.map { it.colorIdx }.distinct()
        currentColor = if (nextColor in activeColors || activeColors.isEmpty()) nextColor else activeColors.random()
        nextColor = if (activeColors.isEmpty()) 0 else activeColors.random()

        if (bubbles.isEmpty()) {
            gameResult = 1
            SoundManager.playWin()
            session.onRecordResult(score + 300, true, true)
        } else if (bubbles.any { it.row >= maxRows - 1 }) {
            gameResult = -1
            SoundManager.playLose()
            session.onRecordResult(score, false, true)
        }
    }

    // Projectile flight loop
    LaunchedEffect(flying != null, isPaused) {
        if (flying == null || isPaused) return@LaunchedEffect
        val radius = 1f / (cols * 2f)
        while (flying != null && !isPaused) {
            delay(16)
            val fb = flying ?: break
            fb.x += fb.vx
            fb.y += fb.vy
            if (fb.x < radius) {
                fb.x = radius; fb.vx = -fb.vx; SoundManager.playBounce()
            } else if (fb.x > 1f - radius) {
                fb.x = 1f - radius; fb.vx = -fb.vx; SoundManager.playBounce()
            }

            val hitCeiling = fb.y <= radius
            val hitBubble = bubbles.any { cell ->
                val (cx, cy) = cellCenter(cell.row, cell.col)
                hypot(fb.x - cx, fb.y - cy) <= radius * 1.88f
            }
            if (hitCeiling || hitBubble) {
                flying = null
                snapFlyingBubble(fb)
            } else {
                flying = fb.copy()
            }
        }
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; restart(it) },
        scoreText = "SCORE $score",
        bestScoreText = "BEST ${maxOf(score, session.bestScore)}",
        gameOverTitle = when (gameResult) {
            1 -> "All Bubbles Cleared!"
            -1 -> "Bubbles Reached Bottom!"
            else -> null
        },
        gameOverSubtitle = "Final Score: $score",
        isWin = gameResult == 1,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 380.dp)
                    .aspectRatio(0.74f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(2.dp, SurfaceBorder, RoundedCornerShape(20.dp))
                    .pointerInput(isPaused, gameResult, flying != null) {
                        if (isPaused || gameResult != 0) return@pointerInput
                        detectDragGestures(
                            onDrag = { change, _ ->
                                change.consume()
                                if (flying == null) {
                                    val cannonX = size.width / 2f
                                    val cannonY = size.height * 0.92f
                                    val dx = change.position.x - cannonX
                                    val dy = (change.position.y - cannonY).coerceAtMost(-30f)
                                    aimAngle = atan2(dy, dx).coerceIn(-Math.PI.toFloat() + 0.22f, -0.22f)
                                }
                            },
                            onDragEnd = {
                                if (flying == null && !isPaused && gameResult == 0) {
                                    val speed = 0.025f
                                    flying = FlyingBubble(
                                        x = 0.5f,
                                        y = 1.24f,
                                        vx = cos(aimAngle) * speed,
                                        vy = sin(aimAngle) * speed,
                                        colorIdx = currentColor
                                    )
                                    SoundManager.playMove()
                                }
                            }
                        )
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val radius = w / (cols * 2f)

                    // Grid bubbles
                    bubbles.forEach { cell ->
                        val (nx, ny) = cellCenter(cell.row, cell.col)
                        val cx = nx * w
                        val cy = ny * w
                        val col = bubblePalette[cell.colorIdx % bubblePalette.size]
                        drawCircle(col, radius * 0.94f, Offset(cx, cy))
                        drawCircle(Color.White.copy(alpha = 0.35f), radius * 0.28f, Offset(cx - radius * 0.3f, cy - radius * 0.3f))
                    }

                    // Danger line
                    val dangerY = h * 0.85f
                    drawLine(
                        NeonCoral.copy(alpha = 0.5f),
                        Offset(0f, dangerY),
                        Offset(w, dangerY),
                        strokeWidth = 2f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
                    )

                    // Cannon + Aim trajectory
                    val cannonCenter = Offset(w * 0.5f, h * 0.92f)
                    if (flying == null && gameResult == 0) {
                        val endX = cannonCenter.x + cos(aimAngle) * (w * 0.45f)
                        val endY = cannonCenter.y + sin(aimAngle) * (w * 0.45f)
                        drawLine(
                            color = bubblePalette[currentColor].copy(alpha = 0.8f),
                            start = cannonCenter,
                            end = Offset(endX, endY),
                            strokeWidth = 4f,
                            cap = StrokeCap.Round,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f))
                        )
                    }

                    // Current bubble in cannon
                    drawCircle(bubblePalette[currentColor], radius * 0.94f, cannonCenter)
                    // Next preview bottom-left
                    drawCircle(bubblePalette[nextColor], radius * 0.65f, Offset(w * 0.14f, h * 0.92f))

                    // Flying bubble
                    flying?.let { fb ->
                        drawCircle(bubblePalette[fb.colorIdx], radius * 0.94f, Offset(fb.x * w, fb.y * w))
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(
                text = "Drag anywhere on the arena to aim & release to shoot!",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}
