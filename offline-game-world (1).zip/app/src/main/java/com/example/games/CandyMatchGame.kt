package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextSecondary
import kotlin.math.abs

private val gemColors = listOf(
    NeonMagenta,
    NeonCyan,
    NeonAmber,
    NeonEmerald,
    NeonViolet,
    NeonCoral
)

private val gemSymbols = listOf("◆", "●", "★", "▲", "⬢", "♥")

object CandyMatchEngine {
    const val SIZE = 8

    fun createBoard(): List<Int> {
        val board = MutableList(SIZE * SIZE) { (0 until 6).random() }
        // Clear any initial matches
        while (findMatches(board).isNotEmpty()) {
            for (idx in findMatches(board)) {
                board[idx] = (0 until 6).random()
            }
        }
        return board
    }

    fun findMatches(board: List<Int>): Set<Int> {
        val matched = mutableSetOf<Int>()
        for (r in 0 until SIZE) {
            var c = 0
            while (c < SIZE - 2) {
                val v = board[r * SIZE + c]
                if (v >= 0 && v == board[r * SIZE + c + 1] && v == board[r * SIZE + c + 2]) {
                    var k = c
                    while (k < SIZE && board[r * SIZE + k] == v) {
                        matched.add(r * SIZE + k)
                        k++
                    }
                    c = k
                } else c++
            }
        }
        for (c in 0 until SIZE) {
            var r = 0
            while (r < SIZE - 2) {
                val v = board[r * SIZE + c]
                if (v >= 0 && v == board[(r + 1) * SIZE + c] && v == board[(r + 2) * SIZE + c]) {
                    var k = r
                    while (k < SIZE && board[k * SIZE + c] == v) {
                        matched.add(k * SIZE + c)
                        k++
                    }
                    r = k
                } else r++
            }
        }
        return matched
    }

    fun resolveCascades(initial: List<Int>): Pair<List<Int>, Int> {
        val b = initial.toMutableList()
        var points = 0
        var combo = 1
        while (true) {
            val matches = findMatches(b)
            if (matches.isEmpty()) break
            points += matches.size * 15 * combo
            matches.forEach { b[it] = -1 }
            // Gravity drop
            for (c in 0 until SIZE) {
                var writeRow = SIZE - 1
                for (r in SIZE - 1 downTo 0) {
                    val v = b[r * SIZE + c]
                    if (v >= 0) {
                        b[writeRow * SIZE + c] = v
                        if (writeRow != r) b[r * SIZE + c] = -1
                        writeRow--
                    }
                }
                while (writeRow >= 0) {
                    b[writeRow * SIZE + c] = (0 until 6).random()
                    writeRow--
                }
            }
            combo++
        }
        return b to points
    }
}

@Composable
fun CandyMatchScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    val (targetScore, initialMoves) = when (difficulty) {
        Difficulty.EASY -> 800 to 25
        Difficulty.MEDIUM -> 1200 to 22
        Difficulty.HARD -> 1700 to 20
    }

    var board by remember { mutableStateOf(CandyMatchEngine.createBoard()) }
    var selectedIdx by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }
    var movesLeft by remember(difficulty) { mutableIntStateOf(initialMoves) }
    var isPaused by remember { mutableStateOf(false) }
    var status by remember { mutableIntStateOf(0) } // 0 playing, 1 won, -1 lost

    fun restart(diff: Difficulty = difficulty) {
        val m = when (diff) {
            Difficulty.EASY -> 25; Difficulty.MEDIUM -> 22; Difficulty.HARD -> 20
        }
        board = CandyMatchEngine.createBoard()
        selectedIdx = -1
        score = 0
        movesLeft = m
        status = 0
        isPaused = false
    }

    fun tapCell(idx: Int) {
        if (isPaused || status != 0) return
        if (selectedIdx < 0) {
            selectedIdx = idx
            SoundManager.playTap()
            return
        }
        if (selectedIdx == idx) {
            selectedIdx = -1
            return
        }
        val r1 = selectedIdx / 8; val c1 = selectedIdx % 8
        val r2 = idx / 8; val c2 = idx % 8
        if (abs(r1 - r2) + abs(c1 - c2) != 1) {
            selectedIdx = idx
            SoundManager.playTap()
            return
        }

        val swapped = board.toMutableList()
        val tmp = swapped[selectedIdx]
        swapped[selectedIdx] = swapped[idx]
        swapped[idx] = tmp
        selectedIdx = -1

        if (CandyMatchEngine.findMatches(swapped).isEmpty()) {
            SoundManager.playError()
            return
        }

        val (resolved, pts) = CandyMatchEngine.resolveCascades(swapped)
        board = resolved
        score += pts
        movesLeft--
        SoundManager.playMatch()

        if (score >= targetScore) {
            status = 1
            val finalScore = score + movesLeft * 30
            score = finalScore
            SoundManager.playWin()
            session.onRecordResult(finalScore, true, true)
        } else if (movesLeft <= 0) {
            status = -1
            SoundManager.playLose()
            session.onRecordResult(score, false, true)
        }
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; restart(it) },
        scoreText = "SCORE $score / $targetScore",
        bestScoreText = "MOVES $movesLeft",
        gameOverTitle = when (status) {
            1 -> "Sweet Victory!"
            -1 -> "Out of Moves!"
            else -> null
        },
        gameOverSubtitle = "Score: $score (Goal: $targetScore)",
        isWin = status == 1,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            LinearProgressIndicator(
                progress = { (score.toFloat() / targetScore.toFloat()).coerceIn(0f, 1f) },
                color = NeonMagenta,
                trackColor = SurfaceCard,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 380.dp)
                    .height(10.dp)
                    .clip(CircleShape)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Tap two adjacent gems to swap and match 3+",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Spacer(Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 380.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(SurfaceCard)
                    .border(1.5.dp, SurfaceBorder, RoundedCornerShape(18.dp))
                    .padding(6.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (r in 0 until 8) {
                        Row(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            for (c in 0 until 8) {
                                val idx = r * 8 + c
                                val gem = board[idx].coerceIn(0, 5)
                                val col = gemColors[gem]
                                val isSel = idx == selectedIdx
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(col.copy(alpha = if (isSel) 0.42f else 0.22f))
                                        .border(
                                            width = if (isSel) 2.5.dp else 1.dp,
                                            color = if (isSel) Color.White else col.copy(alpha = 0.65f),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clickable { tapCell(idx) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = gemSymbols[gem],
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = col
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
