package com.example.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.core.model.PlayerMode
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

// Normalized board coordinates: [0f, 1f] x [0f, 1f]
private enum class CarromCoinType { WHITE, BLACK, QUEEN, STRIKER }

private data class CarromDisc(
    val id: Int,
    val type: CarromCoinType,
    var x: Float,
    var y: Float,
    var vx: Float = 0f,
    var vy: Float = 0f,
    val radius: Float = 0.025f,
    var active: Boolean = true
)

private fun initialCarromDiscs(): List<CarromDisc> {
    val list = mutableListOf<CarromDisc>()
    list.add(CarromDisc(0, CarromCoinType.QUEEN, 0.5f, 0.5f))
    var id = 1
    // Inner ring of 6 alternating coins
    for (i in 0 until 6) {
        val angle = (i * 60.0) * Math.PI / 180.0
        val type = if (i % 2 == 0) CarromCoinType.WHITE else CarromCoinType.BLACK
        list.add(CarromDisc(id++, type, 0.5f + (0.056 * cos(angle)).toFloat(), 0.5f + (0.056 * sin(angle)).toFloat()))
    }
    // Outer ring of 12 alternating coins
    for (i in 0 until 12) {
        val angle = (i * 30.0) * Math.PI / 180.0
        val type = if (i % 2 == 0) CarromCoinType.WHITE else CarromCoinType.BLACK
        list.add(CarromDisc(id++, type, 0.5f + (0.112 * cos(angle)).toFloat(), 0.5f + (0.112 * sin(angle)).toFloat()))
    }
    // Striker
    list.add(CarromDisc(99, CarromCoinType.STRIKER, 0.5f, 0.82f, radius = 0.032f))
    return list
}

@Composable
fun CarromScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var playerMode by remember { mutableStateOf(session.initialPlayerMode) }
    var discs by remember { mutableStateOf(initialCarromDiscs()) }
    var turn by remember { mutableIntStateOf(1) } // 1 = Bottom (White), 2 = Top (Black)
    var strikerPosX by remember { mutableFloatStateOf(0.5f) }
    var isSimulating by remember { mutableStateOf(false) }
    var dragStart by remember { mutableStateOf<Offset?>(null) }
    var dragCurr by remember { mutableStateOf<Offset?>(null) }
    var queenOwner by remember { mutableIntStateOf(0) } // 0 = on board, 1 = P1 covered, 2 = P2 covered
    var queenPendingCoverBy by remember { mutableIntStateOf(0) }
    var statusMsg by remember { mutableStateOf("Slide striker, pull back & release to shoot!") }
    var isPaused by remember { mutableStateOf(false) }
    var winner by remember { mutableIntStateOf(0) }

    val pockets = remember {
        listOf(0.06f to 0.06f, 0.94f to 0.06f, 0.06f to 0.94f, 0.94f to 0.94f)
    }

    fun resetStrikerForTurn(nextTurn: Int, currentDiscs: List<CarromDisc>): List<CarromDisc> {
        val y = if (nextTurn == 1) 0.82f else 0.18f
        strikerPosX = 0.5f
        return currentDiscs.map {
            if (it.type == CarromCoinType.STRIKER) it.copy(x = 0.5f, y = y, vx = 0f, vy = 0f, active = true)
            else it
        }
    }

    fun restart() {
        discs = initialCarromDiscs()
        turn = 1
        strikerPosX = 0.5f
        isSimulating = false
        dragStart = null
        dragCurr = null
        queenOwner = 0
        queenPendingCoverBy = 0
        winner = 0
        statusMsg = "Slide striker, pull back & release to shoot!"
        isPaused = false
    }

    fun shootStriker(vx: Float, vy: Float) {
        discs = discs.map {
            if (it.type == CarromCoinType.STRIKER) it.copy(vx = vx, vy = vy, active = true) else it
        }
        isSimulating = true
        SoundManager.playBounce()
    }

    // 60fps Physics Loop
    LaunchedEffect(isSimulating, isPaused) {
        if (!isSimulating || isPaused) return@LaunchedEffect
        val pocketedThisTurn = mutableListOf<CarromCoinType>()
        var working = discs.map { it.copy() }

        while (isSimulating && !isPaused) {
            delay(16)
            var anyMoving = false
            // Move & wall bounce
            for (d in working) {
                if (!d.active) continue
                d.x += d.vx
                d.y += d.vy
                d.vx *= 0.976f
                d.vy *= 0.976f
                if (hypot(d.vx, d.vy) < 0.0007f) {
                    d.vx = 0f; d.vy = 0f
                } else {
                    anyMoving = true
                }
                val minB = 0.04f + d.radius
                val maxB = 0.96f - d.radius
                if (d.x < minB) { d.x = minB; d.vx = -d.vx * 0.85f; SoundManager.playBounce() }
                if (d.x > maxB) { d.x = maxB; d.vx = -d.vx * 0.85f; SoundManager.playBounce() }
                if (d.y < minB) { d.y = minB; d.vy = -d.vy * 0.85f; SoundManager.playBounce() }
                if (d.y > maxB) { d.y = maxB; d.vy = -d.vy * 0.85f; SoundManager.playBounce() }
            }

            // Elastic disc-disc collisions
            for (i in working.indices) {
                val a = working[i]
                if (!a.active) continue
                for (j in i + 1 until working.size) {
                    val b = working[j]
                    if (!b.active) continue
                    val dx = b.x - a.x
                    val dy = b.y - a.y
                    val dist = hypot(dx, dy)
                    val minDist = a.radius + b.radius
                    if (dist < minDist && dist > 0.0001f) {
                        val nx = dx / dist
                        val ny = dy / dist
                        val overlap = (minDist - dist) * 0.5f
                        a.x -= nx * overlap; a.y -= ny * overlap
                        b.x += nx * overlap; b.y += ny * overlap
                        val dvx = a.vx - b.vx
                        val dvy = a.vy - b.vy
                        val impact = dvx * nx + dvy * ny
                        if (impact > 0) {
                            a.vx -= impact * nx * 0.94f
                            a.vy -= impact * ny * 0.94f
                            b.vx += impact * nx * 0.94f
                            b.vy += impact * ny * 0.94f
                            SoundManager.playTap()
                        }
                    }
                }
            }

            // Pocket check
            for (d in working) {
                if (!d.active) continue
                for ((px, py) in pockets) {
                    if (hypot(d.x - px, d.y - py) < 0.048f) {
                        d.active = false
                        d.vx = 0f; d.vy = 0f
                        pocketedThisTurn.add(d.type)
                        SoundManager.playCapture()
                        break
                    }
                }
            }

            discs = working.map { it.copy() }
            if (!anyMoving) {
                isSimulating = false
                val myType = if (turn == 1) CarromCoinType.WHITE else CarromCoinType.BLACK
                val pocketedStriker = CarromCoinType.STRIKER in pocketedThisTurn
                val pocketedMine = pocketedThisTurn.count { it == myType }
                val pocketedQueen = CarromCoinType.QUEEN in pocketedThisTurn

                if (pocketedQueen) {
                    if (pocketedMine > 0) queenOwner = turn
                    else queenPendingCoverBy = turn
                } else if (queenPendingCoverBy == turn) {
                    if (pocketedMine > 0) queenOwner = turn
                    else {
                        // Return Queen to center
                        working = working.map {
                            if (it.type == CarromCoinType.QUEEN) it.copy(x = 0.5f, y = 0.5f, active = true) else it
                        }
                    }
                    queenPendingCoverBy = 0
                }

                if (pocketedStriker) {
                    // Foul: return 1 coin if available
                    val toRestore = working.firstOrNull { it.type == myType && !it.active }
                    if (toRestore != null) {
                        working = working.map {
                            if (it.id == toRestore.id) it.copy(x = 0.5f, y = 0.5f, active = true) else it
                        }
                    }
                    statusMsg = "Striker Foul! Turn passes."
                }

                val whiteLeft = working.count { it.type == CarromCoinType.WHITE && it.active }
                val blackLeft = working.count { it.type == CarromCoinType.BLACK && it.active }

                when {
                    whiteLeft == 0 -> {
                        winner = 1
                        SoundManager.playWin()
                        session.onRecordResult(500, true, true)
                    }
                    blackLeft == 0 -> {
                        winner = 2
                        if (playerMode == PlayerMode.LOCAL_MULTIPLAYER) SoundManager.playWin() else SoundManager.playLose()
                        session.onRecordResult(100, false, true)
                    }
                    else -> {
                        val keepTurn = !pocketedStriker && (pocketedMine > 0 || pocketedQueen)
                        val nextTurn = if (keepTurn) turn else if (turn == 1) 2 else 1
                        turn = nextTurn
                        discs = resetStrikerForTurn(nextTurn, working)
                        statusMsg = if (keepTurn) "Nice shot! Shoot again" else "Player $nextTurn's Turn"
                    }
                }
            }
        }
    }

    // AI Turn
    LaunchedEffect(turn, isSimulating, winner, playerMode, isPaused) {
        if (!isPaused && winner == 0 && !isSimulating && playerMode == PlayerMode.SINGLE_PLAYER && turn == 2) {
            delay(650)
            val targets = discs.filter { it.type == CarromCoinType.BLACK && it.active }
            val target = targets.randomOrNull() ?: discs.firstOrNull { it.type == CarromCoinType.QUEEN && it.active }
            if (target != null) {
                val sx = target.x.coerceIn(0.24f, 0.76f)
                strikerPosX = sx
                discs = discs.map { if (it.type == CarromCoinType.STRIKER) it.copy(x = sx, y = 0.18f) else it }
                val dx = target.x - sx
                val dy = target.y - 0.18f
                val dist = hypot(dx, dy).coerceAtLeast(0.01f)
                val jitter = when (difficulty) {
                    Difficulty.EASY -> ((Math.random() - 0.5) * 0.28).toFloat()
                    Difficulty.MEDIUM -> ((Math.random() - 0.5) * 0.12).toFloat()
                    Difficulty.HARD -> 0f
                }
                val speed = 0.034f
                shootStriker((dx / dist + jitter) * speed, (dy / dist) * speed)
            }
        }
    }

    val whiteLeft = discs.count { it.type == CarromCoinType.WHITE && it.active }
    val blackLeft = discs.count { it.type == CarromCoinType.BLACK && it.active }
    val isHumanTurn = playerMode == PlayerMode.LOCAL_MULTIPLAYER || turn == 1

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; restart() },
        playerMode = playerMode,
        onPlayerModeChange = { playerMode = it; restart() },
        scoreText = "W:${9 - whiteLeft}  B:${9 - blackLeft}",
        bestScoreText = if (queenOwner > 0) "QUEEN P$queenOwner" else "QUEEN ON BOARD",
        gameOverTitle = when (winner) {
            1 -> if (playerMode == PlayerMode.SINGLE_PLAYER) "You Win!" else "White Wins!"
            2 -> if (playerMode == PlayerMode.SINGLE_PLAYER) "AI Wins!" else "Black Wins!"
            else -> null
        },
        gameOverSubtitle = "Pocketed — White: ${9 - whiteLeft}/9, Black: ${9 - blackLeft}/9",
        isWin = winner == 1 || (winner == 2 && playerMode == PlayerMode.LOCAL_MULTIPLAYER),
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = statusMsg,
                style = MaterialTheme.typography.titleSmall,
                color = if (turn == 1) NeonCyan else NeonAmber
            )
            Spacer(Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 390.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF451A03))
                    .border(8.dp, Color(0xFF78350F), RoundedCornerShape(20.dp))
                    .padding(12.dp)
                    .pointerInput(isSimulating, isPaused, winner, isHumanTurn) {
                        if (isSimulating || isPaused || winner != 0 || !isHumanTurn) return@pointerInput
                        detectDragGestures(
                            onDragStart = { pos ->
                                dragStart = pos
                                dragCurr = pos
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                dragCurr = change.position
                            },
                            onDragEnd = {
                                val s = dragStart
                                val c = dragCurr
                                dragStart = null
                                dragCurr = null
                                if (s != null && c != null) {
                                    val dx = (s.x - c.x) / size.width
                                    val dy = (s.y - c.y) / size.height
                                    val pull = hypot(dx, dy)
                                    if (pull > 0.03f) {
                                        val power = (pull * 0.16f).coerceIn(0.010f, 0.046f)
                                        shootStriker((dx / pull) * power, (dy / pull) * power)
                                    }
                                }
                            },
                            onDragCancel = {
                                dragStart = null
                                dragCurr = null
                            }
                        )
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    // Wooden playing surface
                    drawRoundRect(Color(0xFFF3D5A5), Offset.Zero, size, CornerRadius(14f, 14f))
                    // Center circle
                    drawCircle(Color(0xFF92400E), w * 0.14f, Offset(w * 0.5f, h * 0.5f), style = Stroke(3f))
                    drawCircle(NeonCoral.copy(alpha = 0.45f), w * 0.045f, Offset(w * 0.5f, h * 0.5f), style = Stroke(2f))
                    // Baselines
                    drawLine(Color(0xFF78350F), Offset(w * 0.22f, h * 0.82f), Offset(w * 0.78f, h * 0.82f), 3f)
                    drawLine(Color(0xFF78350F), Offset(w * 0.22f, h * 0.18f), Offset(w * 0.78f, h * 0.18f), 3f)
                    // 4 Corner pockets
                    pockets.forEach { (px, py) ->
                        drawCircle(Color(0xFF0F172A), w * 0.048f, Offset(px * w, py * h))
                    }
                    // Aim guide while dragging
                    val s = dragStart
                    val c = dragCurr
                    val striker = discs.firstOrNull { it.type == CarromCoinType.STRIKER }
                    if (s != null && c != null && striker != null && !isSimulating) {
                        val dx = s.x - c.x
                        val dy = s.y - c.y
                        val len = hypot(dx, dy).coerceAtLeast(1f)
                        val sx = striker.x * w
                        val sy = striker.y * h
                        drawLine(
                            color = NeonCyan,
                            start = Offset(sx, sy),
                            end = Offset(sx + (dx / len) * (w * 0.35f), sy + (dy / len) * (h * 0.35f)),
                            strokeWidth = 4f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f))
                        )
                    }
                    // Discs
                    discs.filter { it.active }.forEach { d ->
                        val col = when (d.type) {
                            CarromCoinType.WHITE -> Color(0xFFF8FAFC)
                            CarromCoinType.BLACK -> Color(0xFF1E293B)
                            CarromCoinType.QUEEN -> NeonCoral
                            CarromCoinType.STRIKER -> NeonCyan
                        }
                        val cx = d.x * w
                        val cy = d.y * h
                        val r = d.radius * w
                        drawCircle(col, r, Offset(cx, cy))
                        drawCircle(Color(0xFF475569), r, Offset(cx, cy), style = Stroke(2f))
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Striker Baseline Position Slider
            Row(
                modifier = Modifier.fillMaxWidth().widthIn(max = 390.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Striker:", style = MaterialTheme.typography.labelLarge, color = TextPrimary)
                Slider(
                    value = strikerPosX,
                    onValueChange = { x ->
                        if (!isSimulating && isHumanTurn && winner == 0) {
                            strikerPosX = x
                            discs = discs.map {
                                if (it.type == CarromCoinType.STRIKER) it.copy(x = x) else it
                            }
                        }
                    },
                    valueRange = 0.22f..0.78f,
                    colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan),
                    modifier = Modifier.weight(1f)
                )
            }
            Text(
                text = "Drag backward anywhere on board to aim & shoot",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}
