package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.core.model.PlayerMode
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import kotlinx.coroutines.delay
import kotlin.math.abs

// 0 = empty, 1 = P1 man, 2 = P1 king, -1 = P2 man, -2 = P2 king
object CheckersEngine {
    data class Move(val from: Int, val to: Int, val captured: Int? = null)

    fun initialBoard(): IntArray {
        val b = IntArray(64)
        for (r in 0..7) {
            for (c in 0..7) {
                if ((r + c) % 2 == 1) {
                    if (r < 3) b[r * 8 + c] = -1
                    else if (r > 4) b[r * 8 + c] = 1
                }
            }
        }
        return b
    }

    fun owner(piece: Int): Int = when {
        piece > 0 -> 1
        piece < 0 -> -1
        else -> 0
    }

    fun legalMovesForPlayer(board: IntArray, player: Int, forcedFrom: Int? = null): List<Move> {
        val jumps = mutableListOf<Move>()
        val slides = mutableListOf<Move>()

        val indices = if (forcedFrom != null) listOf(forcedFrom) else (0..63).toList()
        for (idx in indices) {
            val piece = board[idx]
            if (owner(piece) != player) continue
            val r = idx / 8
            val c = idx % 8
            val isKing = abs(piece) == 2
            val rowDirs = when {
                isKing -> listOf(-1, 1)
                player == 1 -> listOf(-1)
                else -> listOf(1)
            }
            for (dr in rowDirs) {
                for (dc in listOf(-1, 1)) {
                    val nr = r + dr
                    val nc = c + dc
                    if (nr in 0..7 && nc in 0..7) {
                        val nIdx = nr * 8 + nc
                        if (board[nIdx] == 0 && forcedFrom == null) {
                            slides.add(Move(idx, nIdx))
                        } else if (owner(board[nIdx]) == -player) {
                            val jr = r + dr * 2
                            val jc = c + dc * 2
                            if (jr in 0..7 && jc in 0..7 && board[jr * 8 + jc] == 0) {
                                jumps.add(Move(idx, jr * 8 + jc, nIdx))
                            }
                        }
                    }
                }
            }
        }
        return if (jumps.isNotEmpty()) jumps else slides
    }

    fun applyMove(board: IntArray, move: Move): Pair<IntArray, Boolean> {
        val next = board.copyOf()
        var piece = next[move.from]
        next[move.from] = 0
        move.captured?.let { next[it] = 0 }
        val toRow = move.to / 8
        var promoted = false
        if (piece == 1 && toRow == 0) {
            piece = 2; promoted = true
        } else if (piece == -1 && toRow == 7) {
            piece = -2; promoted = true
        }
        next[move.to] = piece
        return next to promoted
    }

    fun chooseAiMove(board: IntArray, difficulty: Difficulty, forcedFrom: Int?): Move? {
        val moves = legalMovesForPlayer(board, -1, forcedFrom)
        if (moves.isEmpty()) return null
        if (difficulty == Difficulty.EASY) return moves.random()

        var bestScore = Int.MIN_VALUE
        var bestMove = moves.first()
        val depth = if (difficulty == Difficulty.HARD) 3 else 1
        for (m in moves) {
            val (next, _) = applyMove(board, m)
            val s = minimax(next, depth - 1, false)
            if (s > bestScore) {
                bestScore = s
                bestMove = m
            }
        }
        return bestMove
    }

    private fun minimax(board: IntArray, depth: Int, isAi: Boolean): Int {
        val player = if (isAi) -1 else 1
        val moves = legalMovesForPlayer(board, player)
        if (depth == 0 || moves.isEmpty()) {
            var score = 0
            for (p in board) {
                score += when (p) {
                    -1 -> 10
                    -2 -> 18
                    1 -> -10
                    2 -> -18
                    else -> 0
                }
            }
            return score
        }
        return if (isAi) {
            moves.maxOf { m -> minimax(applyMove(board, m).first, depth - 1, false) }
        } else {
            moves.minOf { m -> minimax(applyMove(board, m).first, depth - 1, true) }
        }
    }
}

@Composable
fun CheckersScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var playerMode by remember { mutableStateOf(session.initialPlayerMode) }
    var board by remember { mutableStateOf(CheckersEngine.initialBoard()) }
    var turn by remember { mutableIntStateOf(1) } // 1 Red (bottom), -1 Cyan (top)
    var selectedIdx by remember { mutableIntStateOf(-1) }
    var forcedChainFrom by remember { mutableStateOf<Int?>(null) }
    var isPaused by remember { mutableStateOf(false) }
    var winner by remember { mutableIntStateOf(0) } // 0 playing, 1 P1, -1 P2

    val legalMoves = remember(board, turn, forcedChainFrom) {
        CheckersEngine.legalMovesForPlayer(board, turn, forcedChainFrom)
    }

    fun restart() {
        board = CheckersEngine.initialBoard()
        turn = 1
        selectedIdx = -1
        forcedChainFrom = null
        winner = 0
        isPaused = false
    }

    fun executeMove(move: CheckersEngine.Move) {
        val (nextBoard, promoted) = CheckersEngine.applyMove(board, move)
        board = nextBoard
        selectedIdx = -1

        if (move.captured != null) {
            SoundManager.playCapture()
            if (!promoted) {
                val followUp = CheckersEngine.legalMovesForPlayer(nextBoard, turn, move.to).filter { it.captured != null }
                if (followUp.isNotEmpty()) {
                    forcedChainFrom = move.to
                    selectedIdx = move.to
                    return
                }
            }
        } else {
            SoundManager.playMove()
        }

        forcedChainFrom = null
        val nextTurn = -turn
        val nextMoves = CheckersEngine.legalMovesForPlayer(nextBoard, nextTurn)
        if (nextMoves.isEmpty()) {
            winner = turn
            val p1Won = winner == 1
            if (p1Won || playerMode == PlayerMode.LOCAL_MULTIPLAYER) SoundManager.playWin() else SoundManager.playLose()
            session.onRecordResult(if (p1Won) 300 else 0, p1Won, true)
        } else {
            turn = nextTurn
        }
    }

    LaunchedEffect(turn, winner, playerMode, isPaused, forcedChainFrom) {
        if (!isPaused && winner == 0 && playerMode == PlayerMode.SINGLE_PLAYER && turn == -1) {
            delay(380)
            val aiMove = CheckersEngine.chooseAiMove(board, difficulty, forcedChainFrom)
            if (aiMove != null) executeMove(aiMove)
        }
    }

    val p1Count = board.count { it > 0 }
    val p2Count = board.count { it < 0 }

    val overTitle = when (winner) {
        1 -> if (playerMode == PlayerMode.SINGLE_PLAYER) "You Win!" else "Crimson Wins!"
        -1 -> if (playerMode == PlayerMode.SINGLE_PLAYER) "AI Wins!" else "Cyan Wins!"
        else -> null
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; restart() },
        playerMode = playerMode,
        onPlayerModeChange = { playerMode = it; restart() },
        scoreText = "RED $p1Count  CYAN $p2Count",
        bestScoreText = "BEST ${session.bestScore}",
        gameOverTitle = overTitle,
        gameOverSubtitle = "Remaining pieces — Red: $p1Count, Cyan: $p2Count",
        isWin = winner == 1 || (winner == -1 && playerMode == PlayerMode.LOCAL_MULTIPLAYER),
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = when {
                    winner != 0 -> "Game Over"
                    forcedChainFrom != null -> "Multi-jump required!"
                    turn == 1 -> "Crimson's Turn"
                    playerMode == PlayerMode.SINGLE_PLAYER -> "Cyan AI thinking..."
                    else -> "Cyan's Turn"
                },
                style = MaterialTheme.typography.titleMedium,
                color = if (turn == 1) NeonCoral else NeonCyan
            )
            Spacer(Modifier.height(14.dp))

            val highlightedTargets = legalMoves.filter { it.from == selectedIdx }.associateBy { it.to }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 390.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .border(2.dp, SurfaceBorder, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    for (r in 0..7) {
                        Row(modifier = Modifier.fillMaxWidth().weight(1f)) {
                            for (c in 0..7) {
                                val idx = r * 8 + c
                                val dark = (r + c) % 2 == 1
                                val piece = board[idx]
                                val isSel = idx == selectedIdx
                                val moveTarget = highlightedTargets[idx]
                                val canSelect = legalMoves.any { it.from == idx }

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                        .background(
                                            when {
                                                isSel -> NeonAmber.copy(alpha = 0.35f)
                                                moveTarget != null -> NeonEmerald.copy(alpha = 0.28f)
                                                dark -> Color(0xFF151E36)
                                                else -> Color(0xFF283556)
                                            }
                                        )
                                        .clickable(
                                            enabled = !isPaused && winner == 0 &&
                                                (playerMode == PlayerMode.LOCAL_MULTIPLAYER || turn == 1)
                                        ) {
                                            if (moveTarget != null) {
                                                executeMove(moveTarget)
                                            } else if (canSelect) {
                                                selectedIdx = idx
                                                SoundManager.playTap()
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (piece != 0) {
                                        val isP1 = piece > 0
                                        val isKing = abs(piece) == 2
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize(0.74f)
                                                .clip(CircleShape)
                                                .background(if (isP1) NeonCoral else NeonCyan)
                                                .border(
                                                    width = if (isKing) 2.5.dp else 1.5.dp,
                                                    color = if (isKing) NeonAmber else Color.White.copy(alpha = 0.7f),
                                                    shape = CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isKing) {
                                                Text("★", color = NeonAmber, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    } else if (moveTarget != null) {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .clip(CircleShape)
                                                .background(NeonEmerald)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
