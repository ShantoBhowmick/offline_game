package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.core.model.PlayerMode
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.delay
import kotlin.math.abs

// Piece encoding: >0 White, <0 Black. 1=Pawn, 2=Knight, 3=Bishop, 4=Rook, 5=Queen, 6=King
object ChessEngine {
    data class ChessState(
        val board: IntArray,
        val turn: Int = 1, // 1 White, -1 Black
        val wCastleK: Boolean = true,
        val wCastleQ: Boolean = true,
        val bCastleK: Boolean = true,
        val bCastleQ: Boolean = true,
        val enPassantSq: Int = -1
    )

    data class ChessMove(
        val from: Int,
        val to: Int,
        val promotion: Int = 0,
        val isEnPassant: Boolean = false,
        val castleRookFrom: Int = -1,
        val castleRookTo: Int = -1
    )

    fun initialState(): ChessState {
        val b = intArrayOf(
            -4, -2, -3, -5, -6, -3, -2, -4,
            -1, -1, -1, -1, -1, -1, -1, -1,
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,
            1, 1, 1, 1, 1, 1, 1, 1,
            4, 2, 3, 5, 6, 3, 2, 4
        )
        return ChessState(board = b)
    }

    fun pieceSymbol(p: Int): String = when (p) {
        6 -> "♔"; 5 -> "♕"; 4 -> "♖"; 3 -> "♗"; 2 -> "♘"; 1 -> "♙"
        -6 -> "♚"; -5 -> "♛"; -4 -> "♜"; -3 -> "♝"; -2 -> "♞"; -1 -> "♟"
        else -> ""
    }

    fun pieceValue(p: Int): Int = when (abs(p)) {
        1 -> 100; 2 -> 320; 3 -> 330; 4 -> 500; 5 -> 900; 6 -> 20000
        else -> 0
    }

    private fun owner(p: Int): Int = if (p > 0) 1 else if (p < 0) -1 else 0

    fun isInCheck(board: IntArray, player: Int): Boolean {
        val kingSq = board.indexOfFirst { it == player * 6 }
        if (kingSq < 0) return true
        return isSquareAttacked(board, kingSq, -player)
    }

    private fun isSquareAttacked(board: IntArray, sq: Int, byPlayer: Int): Boolean {
        val r = sq / 8; val c = sq % 8
        // Pawn attacks
        val pawnDir = if (byPlayer == 1) 1 else -1 // white pawns attack upward (from r+1)
        for (dc in listOf(-1, 1)) {
            val pr = r + pawnDir; val pc = c + dc
            if (pr in 0..7 && pc in 0..7 && board[pr * 8 + pc] == byPlayer) return true
        }
        // Knight
        val knightOffsets = listOf(-2 to -1, -2 to 1, -1 to -2, -1 to 2, 1 to -2, 1 to 2, 2 to -1, 2 to 1)
        for ((dr, dc) in knightOffsets) {
            val nr = r + dr; val nc = c + dc
            if (nr in 0..7 && nc in 0..7 && board[nr * 8 + nc] == byPlayer * 2) return true
        }
        // King
        for (dr in -1..1) for (dc in -1..1) {
            if (dr == 0 && dc == 0) continue
            val nr = r + dr; val nc = c + dc
            if (nr in 0..7 && nc in 0..7 && board[nr * 8 + nc] == byPlayer * 6) return true
        }
        // Rook / Queen orthogonal
        val orth = listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1)
        for ((dr, dc) in orth) {
            var nr = r + dr; var nc = c + dc
            while (nr in 0..7 && nc in 0..7) {
                val p = board[nr * 8 + nc]
                if (p != 0) {
                    if (owner(p) == byPlayer && (abs(p) == 4 || abs(p) == 5)) return true
                    break
                }
                nr += dr; nc += dc
            }
        }
        // Bishop / Queen diagonal
        val diag = listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1)
        for ((dr, dc) in diag) {
            var nr = r + dr; var nc = c + dc
            while (nr in 0..7 && nc in 0..7) {
                val p = board[nr * 8 + nc]
                if (p != 0) {
                    if (owner(p) == byPlayer && (abs(p) == 3 || abs(p) == 5)) return true
                    break
                }
                nr += dr; nc += dc
            }
        }
        return false
    }

    fun legalMoves(state: ChessState): List<ChessMove> {
        val pseudo = mutableListOf<ChessMove>()
        val b = state.board
        val turn = state.turn

        for (sq in 0..63) {
            val p = b[sq]
            if (owner(p) != turn) continue
            val r = sq / 8; val c = sq % 8
            when (abs(p)) {
                1 -> { // Pawn
                    val dir = if (turn == 1) -1 else 1
                    val startRow = if (turn == 1) 6 else 1
                    val promoRow = if (turn == 1) 0 else 7
                    val fwd = (r + dir) * 8 + c
                    if (r + dir in 0..7 && b[fwd] == 0) {
                        if (r + dir == promoRow) {
                            listOf(5, 4, 3, 2).forEach { pr -> pseudo.add(ChessMove(sq, fwd, promotion = pr * turn)) }
                        } else {
                            pseudo.add(ChessMove(sq, fwd))
                            if (r == startRow) {
                                val fwd2 = (r + dir * 2) * 8 + c
                                if (b[fwd2] == 0) pseudo.add(ChessMove(sq, fwd2))
                            }
                        }
                    }
                    for (dc in listOf(-1, 1)) {
                        val nc = c + dc; val nr = r + dir
                        if (nr in 0..7 && nc in 0..7) {
                            val capSq = nr * 8 + nc
                            if (owner(b[capSq]) == -turn) {
                                if (nr == promoRow) {
                                    listOf(5, 4, 3, 2).forEach { pr -> pseudo.add(ChessMove(sq, capSq, promotion = pr * turn)) }
                                } else {
                                    pseudo.add(ChessMove(sq, capSq))
                                }
                            } else if (capSq == state.enPassantSq) {
                                pseudo.add(ChessMove(sq, capSq, isEnPassant = true))
                            }
                        }
                    }
                }
                2 -> { // Knight
                    val offs = listOf(-2 to -1, -2 to 1, -1 to -2, -1 to 2, 1 to -2, 1 to 2, 2 to -1, 2 to 1)
                    for ((dr, dc) in offs) {
                        val nr = r + dr; val nc = c + dc
                        if (nr in 0..7 && nc in 0..7 && owner(b[nr * 8 + nc]) != turn) {
                            pseudo.add(ChessMove(sq, nr * 8 + nc))
                        }
                    }
                }
                3, 4, 5 -> { // Sliding
                    val dirs = mutableListOf<Pair<Int, Int>>()
                    if (abs(p) != 4) dirs.addAll(listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1))
                    if (abs(p) != 3) dirs.addAll(listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1))
                    for ((dr, dc) in dirs) {
                        var nr = r + dr; var nc = c + dc
                        while (nr in 0..7 && nc in 0..7) {
                            val tSq = nr * 8 + nc
                            if (owner(b[tSq]) == turn) break
                            pseudo.add(ChessMove(sq, tSq))
                            if (b[tSq] != 0) break
                            nr += dr; nc += dc
                        }
                    }
                }
                6 -> { // King
                    for (dr in -1..1) for (dc in -1..1) {
                        if (dr == 0 && dc == 0) continue
                        val nr = r + dr; val nc = c + dc
                        if (nr in 0..7 && nc in 0..7 && owner(b[nr * 8 + nc]) != turn) {
                            pseudo.add(ChessMove(sq, nr * 8 + nc))
                        }
                    }
                    // Castling
                    if (turn == 1 && sq == 60 && !isInCheck(b, 1)) {
                        if (state.wCastleK && b[61] == 0 && b[62] == 0 && b[63] == 4 &&
                            !isSquareAttacked(b, 61, -1) && !isSquareAttacked(b, 62, -1)
                        ) {
                            pseudo.add(ChessMove(60, 62, castleRookFrom = 63, castleRookTo = 61))
                        }
                        if (state.wCastleQ && b[59] == 0 && b[58] == 0 && b[57] == 0 && b[56] == 4 &&
                            !isSquareAttacked(b, 59, -1) && !isSquareAttacked(b, 58, -1)
                        ) {
                            pseudo.add(ChessMove(60, 58, castleRookFrom = 56, castleRookTo = 59))
                        }
                    } else if (turn == -1 && sq == 4 && !isInCheck(b, -1)) {
                        if (state.bCastleK && b[5] == 0 && b[6] == 0 && b[7] == -4 &&
                            !isSquareAttacked(b, 5, 1) && !isSquareAttacked(b, 6, 1)
                        ) {
                            pseudo.add(ChessMove(4, 6, castleRookFrom = 7, castleRookTo = 5))
                        }
                        if (state.bCastleQ && b[3] == 0 && b[2] == 0 && b[1] == 0 && b[0] == -4 &&
                            !isSquareAttacked(b, 3, 1) && !isSquareAttacked(b, 2, 1)
                        ) {
                            pseudo.add(ChessMove(4, 2, castleRookFrom = 0, castleRookTo = 3))
                        }
                    }
                }
            }
        }

        return pseudo.filter { m ->
            val next = applyMove(state, m)
            !isInCheck(next.board, turn)
        }
    }

    fun applyMove(state: ChessState, move: ChessMove): ChessState {
        val b = state.board.copyOf()
        val moving = b[move.from]
        b[move.from] = 0
        if (move.isEnPassant) {
            val capRow = move.from / 8
            val capCol = move.to % 8
            b[capRow * 8 + capCol] = 0
        }
        b[move.to] = if (move.promotion != 0) move.promotion else moving
        if (move.castleRookFrom >= 0) {
            b[move.castleRookTo] = b[move.castleRookFrom]
            b[move.castleRookFrom] = 0
        }
        val nextEp = if (abs(moving) == 1 && abs(move.from / 8 - move.to / 8) == 2) {
            ((move.from / 8 + move.to / 8) / 2) * 8 + (move.from % 8)
        } else -1

        return ChessState(
            board = b,
            turn = -state.turn,
            wCastleK = state.wCastleK && move.from != 60 && move.from != 63 && move.to != 63,
            wCastleQ = state.wCastleQ && move.from != 60 && move.from != 56 && move.to != 56,
            bCastleK = state.bCastleK && move.from != 4 && move.from != 7 && move.to != 7,
            bCastleQ = state.bCastleQ && move.from != 4 && move.from != 0 && move.to != 0,
            enPassantSq = nextEp
        )
    }

    fun chooseAiMove(state: ChessState, difficulty: Difficulty): ChessMove? {
        val moves = legalMoves(state)
        if (moves.isEmpty()) return null
        if (difficulty == Difficulty.EASY) return moves.random()

        val depth = if (difficulty == Difficulty.HARD) 2 else 1
        var bestScore = Int.MIN_VALUE
        var bestMove = moves.first()
        val ordered = moves.sortedByDescending { if (state.board[it.to] != 0) pieceValue(state.board[it.to]) else 0 }
        for (m in ordered) {
            val s = -negamax(applyMove(state, m), depth, Int.MIN_VALUE + 1, Int.MAX_VALUE)
            if (s > bestScore) {
                bestScore = s
                bestMove = m
            }
        }
        return bestMove
    }

    private fun negamax(state: ChessState, depth: Int, alphaInit: Int, beta: Int): Int {
        val moves = legalMoves(state)
        if (moves.isEmpty()) {
            return if (isInCheck(state.board, state.turn)) -50000 - depth else 0
        }
        if (depth == 0) return evaluate(state.board) * state.turn

        var alpha = alphaInit
        var best = Int.MIN_VALUE + 1
        val ordered = moves.sortedByDescending { if (state.board[it.to] != 0) pieceValue(state.board[it.to]) else 0 }
        for (m in ordered) {
            val score = -negamax(applyMove(state, m), depth - 1, -beta, -alpha)
            if (score > best) best = score
            if (best > alpha) alpha = best
            if (alpha >= beta) break
        }
        return best
    }

    private fun evaluate(board: IntArray): Int {
        var score = 0
        for (sq in 0..63) {
            val p = board[sq]
            if (p != 0) {
                val r = sq / 8; val c = sq % 8
                val centerBonus = if (r in 2..5 && c in 2..5) 14 else 0
                score += if (p > 0) (pieceValue(p) + centerBonus) else -(pieceValue(p) + centerBonus)
            }
        }
        return score
    }
}

@Composable
fun ChessScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var playerMode by remember { mutableStateOf(session.initialPlayerMode) }
    var state by remember { mutableStateOf(ChessEngine.initialState()) }
    var selectedSq by remember { mutableIntStateOf(-1) }
    var pendingPromoMoves by remember { mutableStateOf<List<ChessEngine.ChessMove>>(emptyList()) }
    var isPaused by remember { mutableStateOf(false) }
    var gameOutcome by remember { mutableStateOf<String?>(null) }
    var playerWon by remember { mutableStateOf(false) }

    val legalMoves = remember(state) { ChessEngine.legalMoves(state) }
    val inCheck = remember(state) { ChessEngine.isInCheck(state.board, state.turn) }

    fun restart() {
        state = ChessEngine.initialState()
        selectedSq = -1
        pendingPromoMoves = emptyList()
        gameOutcome = null
        playerWon = false
        isPaused = false
    }

    fun commitMove(move: ChessEngine.ChessMove) {
        val captured = state.board[move.to] != 0 || move.isEnPassant
        val next = ChessEngine.applyMove(state, move)
        state = next
        selectedSq = -1
        pendingPromoMoves = emptyList()
        if (captured) SoundManager.playCapture() else SoundManager.playMove()

        val nextLegal = ChessEngine.legalMoves(next)
        if (nextLegal.isEmpty()) {
            val check = ChessEngine.isInCheck(next.board, next.turn)
            if (check) {
                val whiteWon = next.turn == -1
                gameOutcome = if (whiteWon) {
                    if (playerMode == PlayerMode.SINGLE_PLAYER) "Checkmate! You Win" else "Checkmate! White Wins"
                } else {
                    if (playerMode == PlayerMode.SINGLE_PLAYER) "Checkmate! AI Wins" else "Checkmate! Black Wins"
                }
                playerWon = whiteWon || playerMode == PlayerMode.LOCAL_MULTIPLAYER
                if (playerWon) SoundManager.playWin() else SoundManager.playLose()
                session.onRecordResult(if (whiteWon) 500 else 0, whiteWon, true)
            } else {
                gameOutcome = "Stalemate — Draw"
                SoundManager.playBounce()
                session.onRecordResult(100, false, true)
            }
        }
    }

    LaunchedEffect(state, playerMode, isPaused, gameOutcome) {
        if (!isPaused && gameOutcome == null && playerMode == PlayerMode.SINGLE_PLAYER && state.turn == -1) {
            delay(360)
            val aiMove = ChessEngine.chooseAiMove(state, difficulty)
            if (aiMove != null) commitMove(aiMove)
        }
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; restart() },
        playerMode = playerMode,
        onPlayerModeChange = { playerMode = it; restart() },
        scoreText = if (state.turn == 1) "WHITE TURN" else "BLACK TURN",
        bestScoreText = if (inCheck) "CHECK!" else "BEST ${session.bestScore}",
        gameOverTitle = gameOutcome,
        gameOverSubtitle = "Tap Play Again to start a new match",
        isWin = playerWon,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = when {
                    gameOutcome != null -> gameOutcome!!
                    inCheck -> "${if (state.turn == 1) "White" else "Black"} King is in CHECK!"
                    state.turn == 1 -> "White's Move"
                    playerMode == PlayerMode.SINGLE_PLAYER -> "Black AI thinking..."
                    else -> "Black's Move"
                },
                style = MaterialTheme.typography.titleMedium,
                color = if (inCheck) NeonCoral else if (state.turn == 1) TextPrimary else NeonCyan
            )
            Spacer(Modifier.height(12.dp))

            val targetMoves = legalMoves.filter { it.from == selectedSq }.groupBy { it.to }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 400.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(2.dp, SurfaceBorder, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    for (r in 0..7) {
                        Row(modifier = Modifier.fillMaxWidth().weight(1f)) {
                            for (c in 0..7) {
                                val sq = r * 8 + c
                                val p = state.board[sq]
                                val light = (r + c) % 2 == 0
                                val isSel = sq == selectedSq
                                val targetsHere = targetMoves[sq]
                                val isKingCheck = inCheck && p == state.turn * 6

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                        .background(
                                            when {
                                                isKingCheck -> NeonCoral.copy(alpha = 0.65f)
                                                isSel -> NeonAmber.copy(alpha = 0.45f)
                                                targetsHere != null -> NeonEmerald.copy(alpha = 0.30f)
                                                light -> Color(0xFF334155)
                                                else -> Color(0xFF141B2D)
                                            }
                                        )
                                        .clickable(
                                            enabled = !isPaused && gameOutcome == null &&
                                                (playerMode == PlayerMode.LOCAL_MULTIPLAYER || state.turn == 1)
                                        ) {
                                            if (targetsHere != null) {
                                                if (targetsHere.size > 1) {
                                                    pendingPromoMoves = targetsHere
                                                } else {
                                                    commitMove(targetsHere.first())
                                                }
                                            } else if (legalMoves.any { it.from == sq }) {
                                                selectedSq = sq
                                                SoundManager.playTap()
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (p != 0) {
                                        Text(
                                            text = ChessEngine.pieceSymbol(p),
                                            fontSize = 27.sp,
                                            color = if (p > 0) Color(0xFFF8FAFC) else Color(0xFF38BDF8)
                                        )
                                    } else if (targetsHere != null) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize(0.28f)
                                                .clip(CircleShape)
                                                .background(NeonEmerald)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (pendingPromoMoves.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { pendingPromoMoves = emptyList() },
            containerColor = SurfaceCard,
            title = { Text("Promote Pawn", color = TextPrimary) },
            text = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    pendingPromoMoves.forEach { move ->
                        Button(onClick = { commitMove(move) }) {
                            Text(ChessEngine.pieceSymbol(move.promotion), fontSize = 24.sp)
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}
