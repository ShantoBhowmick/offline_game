package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.core.model.PlayerMode
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

object ConnectFourEngine {
    const val ROWS = 6
    const val COLS = 7

    fun dropRow(board: IntArray, col: Int): Int {
        for (r in ROWS - 1 downTo 0) {
            if (board[r * COLS + col] == 0) return r
        }
        return -1
    }

    fun checkWinner(board: IntArray): Pair<Int, Set<Int>> {
        val dirs = listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)
        for (r in 0 until ROWS) {
            for (c in 0 until COLS) {
                val p = board[r * COLS + c]
                if (p == 0) continue
                for ((dr, dc) in dirs) {
                    val cells = (0..3).map { k ->
                        val nr = r + dr * k
                        val nc = c + dc * k
                        if (nr in 0 until ROWS && nc in 0 until COLS) nr * COLS + nc else -1
                    }
                    if (cells.all { it >= 0 && board[it] == p }) {
                        return p to cells.toSet()
                    }
                }
            }
        }
        return if (board.none { it == 0 }) 3 to emptySet() else 0 to emptySet()
    }

    fun chooseAiCol(board: IntArray, difficulty: Difficulty): Int {
        val validCols = (0 until COLS).filter { dropRow(board, it) >= 0 }
        if (validCols.isEmpty()) return -1
        if (difficulty == Difficulty.EASY) return validCols.random()

        // Immediate win or block
        for (col in validCols) {
            val copy = board.copyOf()
            val r = dropRow(copy, col)
            copy[r * COLS + col] = 2
            if (checkWinner(copy).first == 2) return col
        }
        for (col in validCols) {
            val copy = board.copyOf()
            val r = dropRow(copy, col)
            copy[r * COLS + col] = 1
            if (checkWinner(copy).first == 1) return col
        }
        if (difficulty == Difficulty.MEDIUM) {
            return if (Math.random() < 0.5 && 3 in validCols) 3 else validCols.random()
        }

        // Hard: shallow depth-4 heuristic minimax prioritizing center columns
        var bestScore = Int.MIN_VALUE
        var bestCol = validCols.first()
        for (col in listOf(3, 2, 4, 1, 5, 0, 6).filter { it in validCols }) {
            val copy = board.copyOf()
            val r = dropRow(copy, col)
            copy[r * COLS + col] = 2
            val s = minimax(copy, 3, false, Int.MIN_VALUE, Int.MAX_VALUE)
            if (s > bestScore) {
                bestScore = s
                bestCol = col
            }
        }
        return bestCol
    }

    private fun minimax(board: IntArray, depth: Int, isMax: Boolean, alphaInit: Int, betaInit: Int): Int {
        val w = checkWinner(board).first
        if (w == 2) return 10000 + depth
        if (w == 1) return -10000 - depth
        if (w == 3 || depth == 0) return scoreBoard(board)

        var alpha = alphaInit
        var beta = betaInit
        val valid = listOf(3, 2, 4, 1, 5, 0, 6).filter { dropRow(board, it) >= 0 }
        if (isMax) {
            var best = Int.MIN_VALUE
            for (c in valid) {
                val r = dropRow(board, c)
                board[r * COLS + c] = 2
                best = maxOf(best, minimax(board, depth - 1, false, alpha, beta))
                board[r * COLS + c] = 0
                alpha = maxOf(alpha, best)
                if (alpha >= beta) break
            }
            return best
        } else {
            var best = Int.MAX_VALUE
            for (c in valid) {
                val r = dropRow(board, c)
                board[r * COLS + c] = 1
                best = minOf(best, minimax(board, depth - 1, true, alpha, beta))
                board[r * COLS + c] = 0
                beta = minOf(beta, best)
                if (alpha >= beta) break
            }
            return best
        }
    }

    private fun scoreBoard(board: IntArray): Int {
        var score = 0
        for (r in 0 until ROWS) {
            if (board[r * COLS + 3] == 2) score += 4
            if (board[r * COLS + 3] == 1) score -= 4
        }
        return score
    }
}

@Composable
fun ConnectFourScreen(session: GameSessionController) {
    var board by remember { mutableStateOf(IntArray(42)) }
    var turn by remember { mutableIntStateOf(1) }
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var playerMode by remember { mutableStateOf(session.initialPlayerMode) }
    var isPaused by remember { mutableStateOf(false) }
    var winner by remember { mutableIntStateOf(0) }
    var winCells by remember { mutableStateOf(emptySet<Int>()) }
    var p1Wins by remember { mutableIntStateOf(0) }
    var p2Wins by remember { mutableIntStateOf(0) }

    fun reset() {
        board = IntArray(42)
        turn = 1
        winner = 0
        winCells = emptySet()
    }

    fun dropInColumn(col: Int) {
        if (isPaused || winner != 0) return
        val row = ConnectFourEngine.dropRow(board, col)
        if (row < 0) {
            SoundManager.playError()
            return
        }
        val next = board.copyOf()
        next[row * ConnectFourEngine.COLS + col] = turn
        board = next
        val (w, cells) = ConnectFourEngine.checkWinner(next)
        if (w != 0) {
            winner = w
            winCells = cells
            when (w) {
                1 -> {
                    p1Wins++
                    SoundManager.playWin()
                    session.onRecordResult(p1Wins * 150, true, true)
                }
                2 -> {
                    p2Wins++
                    if (playerMode == PlayerMode.SINGLE_PLAYER) SoundManager.playLose() else SoundManager.playWin()
                    session.onRecordResult(p1Wins * 150, false, true)
                }
                else -> {
                    SoundManager.playBounce()
                    session.onRecordResult(p1Wins * 150, false, true)
                }
            }
        } else {
            SoundManager.playMove()
            turn = if (turn == 1) 2 else 1
        }
    }

    LaunchedEffect(turn, winner, playerMode, isPaused) {
        if (!isPaused && winner == 0 && playerMode == PlayerMode.SINGLE_PLAYER && turn == 2) {
            delay(360)
            val col = ConnectFourEngine.chooseAiCol(board, difficulty)
            if (col >= 0) dropInColumn(col)
        }
    }

    val overTitle = when (winner) {
        1 -> if (playerMode == PlayerMode.SINGLE_PLAYER) "You Win!" else "Gold Wins!"
        2 -> if (playerMode == PlayerMode.SINGLE_PLAYER) "AI Wins!" else "Red Wins!"
        3 -> "Board Full — Draw!"
        else -> null
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { reset() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; reset() },
        playerMode = playerMode,
        onPlayerModeChange = { playerMode = it; p1Wins = 0; p2Wins = 0; reset() },
        scoreText = "P1:$p1Wins  P2:$p2Wins",
        bestScoreText = "BEST ${session.bestScore}",
        gameOverTitle = overTitle,
        gameOverSubtitle = "Tap Play Again for another match",
        isWin = winner == 1 || (winner == 2 && playerMode == PlayerMode.LOCAL_MULTIPLAYER),
        onPlayAgain = { reset() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = when {
                    winner != 0 -> "Match Finished"
                    turn == 1 -> if (playerMode == PlayerMode.SINGLE_PLAYER) "Your Turn (Gold) — Tap a column" else "Gold Player's Turn"
                    playerMode == PlayerMode.SINGLE_PLAYER -> "AI (Red) is thinking..."
                    else -> "Red Player's Turn"
                },
                style = MaterialTheme.typography.titleMedium,
                color = if (turn == 1) NeonAmber else NeonCoral
            )
            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 400.dp)
                    .aspectRatio(7f / 6f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF172554))
                    .border(2.dp, Color(0xFF3B82F6), RoundedCornerShape(20.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (c in 0 until ConnectFourEngine.COLS) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(
                                    enabled = !isPaused && winner == 0 &&
                                        (playerMode == PlayerMode.LOCAL_MULTIPLAYER || turn == 1)
                                ) { dropInColumn(c) }
                                .testTag("c4_col_$c"),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            for (r in 0 until ConnectFourEngine.ROWS) {
                                val idx = r * ConnectFourEngine.COLS + c
                                val cell = board[idx]
                                val isWin = idx in winCells
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth()
                                        .clip(CircleShape)
                                        .background(
                                            when (cell) {
                                                1 -> NeonAmber
                                                2 -> NeonCoral
                                                else -> BgObsidian
                                            }
                                        )
                                        .border(
                                            width = if (isWin) 3.dp else 1.dp,
                                            color = if (isWin) NeonEmerald else SurfaceBorder,
                                            shape = CircleShape
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
