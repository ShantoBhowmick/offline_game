package com.example.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlin.math.hypot

private data class FruitEntity(
    val id: Int,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val radius: Float,
    val color: Color,
    val innerColor: Color,
    val isBomb: Boolean,
    var sliced: Boolean = false
)

private data class JuiceSplash(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val color: Color,
    var life: Float = 1f
)

@Composable
fun FruitSliceScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var fruits by remember { mutableStateOf<List<FruitEntity>>(emptyList()) }
    var splashes by remember { mutableStateOf<List<JuiceSplash>>(emptyList()) }
    var bladePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var score by remember { mutableIntStateOf(0) }
    var lives by remember { mutableIntStateOf(3) }
    var isPaused by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }
    var nextId by remember { mutableIntStateOf(1) }

    val fruitTypes = remember {
        listOf(
            Color(0xFF22C55E) to Color(0xFFFF5A5F), // Watermelon
            Color(0xFFF97316) to Color(0xFFFDBA74), // Orange
            Color(0xFFEF4444) to Color(0xFFFEE2E2), // Apple
            Color(0xFFEAB308) to Color(0xFFFEF08A), // Lemon
            Color(0xFFA855F7) to Color(0xFFE9D5FF)  // Plum
        )
    }

    fun restart() {
        fruits = emptyList()
        splashes = emptyList()
        bladePoints = emptyList()
        score = 0
        lives = 3
        isGameOver = false
        isPaused = false
    }

    // 60fps Spawn & Physics Loop
    LaunchedEffect(isPaused, isGameOver, difficulty) {
        if (isPaused || isGameOver) return@LaunchedEffect
        var tick = 0
        val spawnInterval = when (difficulty) {
            Difficulty.EASY -> 52; Difficulty.MEDIUM -> 40; Difficulty.HARD -> 28
        }
        val bombChance = when (difficulty) {
            Difficulty.EASY -> 0.12; Difficulty.MEDIUM -> 0.20; Difficulty.HARD -> 0.28
        }

        while (!isPaused && !isGameOver) {
            delay(16)
            tick++

            val updatedFruits = fruits.toMutableList()
            if (tick % spawnInterval == 1) {
                val count = if (difficulty == Difficulty.HARD && Math.random() < 0.45) 2 else 1
                repeat(count) {
                    val isBomb = Math.random() < bombChance
                    val (outer, inner) = fruitTypes.random()
                    val startX = (0.18f + Math.random() * 0.64).toFloat()
                    val vx = ((0.5f - startX) * 0.014f) + ((Math.random() - 0.5) * 0.008).toFloat()
                    val vy = (-0.029f - Math.random() * 0.007).toFloat()
                    updatedFruits.add(
                        FruitEntity(
                            id = nextId++,
                            x = startX,
                            y = 1.06f,
                            vx = vx,
                            vy = vy,
                            radius = if (isBomb) 0.056f else 0.064f,
                            color = if (isBomb) Color(0xFF1E293B) else outer,
                            innerColor = if (isBomb) NeonCoral else inner,
                            isBomb = isBomb
                        )
                    )
                }
            }

            val gravity = 0.00058f
            val keptFruits = mutableListOf<FruitEntity>()
            for (f in updatedFruits) {
                f.x += f.vx
                f.y += f.vy
                f.vy += gravity
                if (f.y > 1.16f && f.vy > 0f) {
                    if (!f.sliced && !f.isBomb) {
                        lives--
                        SoundManager.playError()
                        if (lives <= 0) {
                            isGameOver = true
                            SoundManager.playLose()
                            session.onRecordResult(score, score >= 150, true)
                        }
                    }
                } else {
                    keptFruits.add(f)
                }
            }
            fruits = keptFruits

            // Update splash particles
            splashes = splashes.mapNotNull { sp ->
                sp.x += sp.vx
                sp.y += sp.vy
                sp.vy += 0.0004f
                sp.life -= 0.035f
                if (sp.life > 0f) sp.copy() else null
            }

            if (bladePoints.size > 1 && tick % 2 == 0) {
                bladePoints = bladePoints.drop(1)
            }
        }
    }

    fun sliceAtNormalized(nx: Float, ny: Float) {
        if (isPaused || isGameOver) return
        val newSplashes = splashes.toMutableList()
        var slicedCount = 0
        val nextFruits = fruits.mapNotNull { f ->
            if (!f.sliced && hypot(nx - f.x, ny - f.y) <= f.radius * 1.25f) {
                if (f.isBomb) {
                    isGameOver = true
                    SoundManager.playLose()
                    session.onRecordResult(score, score >= 150, true)
                    null
                } else {
                    slicedCount++
                    repeat(8) {
                        val ang = Math.random() * Math.PI * 2
                        val spd = (0.005 + Math.random() * 0.012).toFloat()
                        newSplashes.add(
                            JuiceSplash(
                                x = f.x,
                                y = f.y,
                                vx = (kotlin.math.cos(ang) * spd).toFloat(),
                                vy = (kotlin.math.sin(ang) * spd).toFloat(),
                                color = f.innerColor
                            )
                        )
                    }
                    null
                }
            } else {
                f
            }
        }
        if (slicedCount > 0) {
            score += slicedCount * 15 + if (slicedCount > 1) 20 else 0
            SoundManager.playSlice()
            fruits = nextFruits
            splashes = newSplashes
        }
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; restart() },
        scoreText = "SCORE $score",
        bestScoreText = "LIVES ${"♥".repeat(lives.coerceAtLeast(0))}",
        gameOverTitle = if (isGameOver) "Game Over!" else null,
        gameOverSubtitle = "Final Score: $score",
        isWin = score >= 150,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 400.dp)
                    .aspectRatio(0.78f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(2.dp, NeonEmerald.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .pointerInput(isPaused, isGameOver) {
                        if (isPaused || isGameOver) return@pointerInput
                        detectDragGestures(
                            onDragStart = { p ->
                                bladePoints = listOf(p)
                                sliceAtNormalized(p.x / size.width, p.y / size.height)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val p = change.position
                                bladePoints = (bladePoints + p).takeLast(12)
                                sliceAtNormalized(p.x / size.width, p.y / size.height)
                            },
                            onDragEnd = { bladePoints = emptyList() },
                            onDragCancel = { bladePoints = emptyList() }
                        )
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    splashes.forEach { sp ->
                        drawCircle(
                            color = sp.color.copy(alpha = sp.life.coerceIn(0f, 1f)),
                            radius = 7f,
                            center = Offset(sp.x * w, sp.y * h)
                        )
                    }

                    fruits.forEach { f ->
                        val cx = f.x * w
                        val cy = f.y * h
                        val r = f.radius * w
                        drawCircle(f.color, r, Offset(cx, cy))
                        if (f.isBomb) {
                            drawCircle(NeonCoral, r * 0.35f, Offset(cx, cy))
                        } else {
                            drawCircle(f.innerColor, r * 0.72f, Offset(cx, cy))
                        }
                    }

                    for (i in 1 until bladePoints.size) {
                        drawLine(
                            color = NeonCyan,
                            start = bladePoints[i - 1],
                            end = bladePoints[i],
                            strokeWidth = (i * 1.4f).coerceAtLeast(3f),
                            cap = StrokeCap.Round
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(
                text = "Swipe across fruits to slice! Avoid dark red-core bombs!",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}
