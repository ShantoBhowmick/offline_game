package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.abs

enum class SwipeDir { UP, DOWN, LEFT, RIGHT }

object Engine2048 {
    fun newBoard(): List<Int> {
        val b = MutableList(16) { 0 }
        spawnTile(b)
        spawnTile(b)
        return b
    }

    fun spawnTile(board: MutableList<Int>): Boolean {
        val empty = board.indices.filter { board[it] == 0 }
        if (empty.isEmpty()) return false
        board[empty.random()] = if (Math.random() < 0.9) 2 else 4
        return true
    }

    fun slide(board: List<Int>, dir: SwipeDir): Triple<List<Int>, Int, Boolean> {
        val next = board.toMutableList()
        var scoreGain = 0
        var moved = false

        fun lineIndices(line: Int): List<Int> = when (dir) {
            SwipeDir.LEFT -> (0..3).map { line * 4 + it }
            SwipeDir.RIGHT -> (3 downTo 0).map { line * 4 + it }
            SwipeDir.UP -> (0..3).map { it * 4 + line }
            SwipeDir.DOWN -> (3 downTo 0).map { it * 4 + line }
        }

        for (line in 0..3) {
            val idxs = lineIndices(line)
            val values = idxs.map { board[it] }.filter { it != 0 }
            val merged = mutableListOf<Int>()
            var i = 0
            while (i < values.size) {
                if (i + 1 < values.size && values[i] == values[i + 1]) {
                    val sum = values[i] * 2
                    merged.add(sum)
                    scoreGain += sum
                    i += 2
                } else {
                    merged.add(values[i])
                    i += 1
                }
            }
            while (merged.size < 4) merged.add(0)
            idxs.forEachIndexed { pos, boardIdx ->
                if (next[boardIdx] != merged[pos]) moved = true
                next[boardIdx] = merged[pos]
            }
        }

        if (moved) spawnTile(next)
        return Triple(next, scoreGain, moved)
    }

    fun hasMoves(board: List<Int>): Boolean {
        if (board.any { it == 0 }) return true
        for (r in 0..3) {
            for (c in 0..3) {
                val v = board[r * 4 + c]
                if (c < 3 && v == board[r * 4 + c + 1]) return true
                if (r < 3 && v == board[(r + 1) * 4 + c]) return true
            }
        }
        return false
    }
}

@Composable
fun Game2048Screen(session: GameSessionController) {
    var board by remember { mutableStateOf(Engine2048.newBoard()) }
    var score by remember { mutableIntStateOf(0) }
    var prevBoard by remember { mutableStateOf<List<Int>?>(null) }
    var prevScore by remember { mutableIntStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }
    var won2048Shown by remember { mutableStateOf(false) }
    var show2048Banner by remember { mutableStateOf(false) }

    fun saveNow(b: List<Int>, s: Int) {
        session.onSaveState("$s|${b.joinToString(",")}")
    }

    LaunchedEffect(Unit) {
        val saved = session.savedStateJson
        if (!saved.isNullOrBlank() && saved.contains("|")) {
            val parts = saved.split("|")
            val s = parts[0].toIntOrNull() ?: 0
            val tiles = parts[1].split(",").mapNotNull { it.toIntOrNull() }
            if (tiles.size == 16 && Engine2048.hasMoves(tiles)) {
                board = tiles
                score = s
                if (tiles.any { it >= 2048 }) won2048Shown = true
            }
        }
    }

    fun restart() {
        board = Engine2048.newBoard()
        score = 0
        prevBoard = null
        isGameOver = false
        won2048Shown = false
        show2048Banner = false
        saveNow(board, 0)
    }

    fun performSwipe(dir: SwipeDir) {
        if (isPaused || isGameOver) return
        val (next, gain, moved) = Engine2048.slide(board, dir)
        if (!moved) return
        prevBoard = board
        prevScore = score
        board = next
        score += gain
        if (gain > 0) SoundManager.playMatch() else SoundManager.playMove()

        if (!won2048Shown && next.any { it >= 2048 }) {
            won2048Shown = true
            show2048Banner = true
            SoundManager.playWin()
            session.onRecordResult(score, true, false)
        }

        if (!Engine2048.hasMoves(next)) {
            isGameOver = true
            SoundManager.playLose()
            session.onRecordResult(score, won2048Shown, true)
        } else {
            saveNow(next, score)
        }
    }

    var dragAccumX = remember { 0f }
    var dragAccumY = remember { 0f }
    var handledGesture = remember { false }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = {
            if (!isGameOver) saveNow(board, score)
            session.onExit()
        },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        scoreText = "SCORE $score",
        bestScoreText = "BEST ${maxOf(score, session.bestScore)}",
        gameOverTitle = if (isGameOver) "No Moves Left!" else null,
        gameOverSubtitle = "Final Score: $score",
        isWin = won2048Shown,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ScoreChip("SCORE", score, NeonAmber)
                    ScoreChip("BEST", maxOf(score, session.bestScore), Color(0xFF00E5FF))
                }
                Button(
                    onClick = {
                        val pb = prevBoard
                        if (pb != null && !isGameOver) {
                            SoundManager.playTap()
                            board = pb
                            score = prevScore
                            prevBoard = null
                            saveNow(pb, prevScore)
                        }
                    },
                    enabled = prevBoard != null && !isGameOver,
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated, contentColor = TextPrimary),
                    modifier = Modifier.height(44.dp).testTag("2048_undo")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo")
                    Spacer(Modifier.padding(start = 6.dp))
                    Text("Undo")
                }
            }

            if (show2048Banner) {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "2048 Reached! Keep swiping for a higher score!",
                    style = MaterialTheme.typography.labelLarge,
                    color = NeonAmber
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 380.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.5.dp, SurfaceBorder, RoundedCornerShape(20.dp))
                    .pointerInput(isPaused, isGameOver) {
                        detectDragGestures(
                            onDragStart = {
                                dragAccumX = 0f
                                dragAccumY = 0f
                                handledGesture = false
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                if (handledGesture) return@detectDragGestures
                                dragAccumX += dragAmount.x
                                dragAccumY += dragAmount.y
                                val threshold = 48f
                                if (abs(dragAccumX) > threshold || abs(dragAccumY) > threshold) {
                                    handledGesture = true
                                    if (abs(dragAccumX) > abs(dragAccumY)) {
                                        performSwipe(if (dragAccumX > 0) SwipeDir.RIGHT else SwipeDir.LEFT)
                                    } else {
                                        performSwipe(if (dragAccumY > 0) SwipeDir.DOWN else SwipeDir.UP)
                                    }
                                }
                            }
                        )
                    }
                    .padding(10.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (r in 0..3) {
                        Row(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (c in 0..3) {
                                val value = board[r * 4 + c]
                                val (bg, fg) = tileColors(value)
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(bg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (value > 0) {
                                        Text(
                                            text = "$value",
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = when {
                                                value >= 1024 -> 20.sp
                                                value >= 128 -> 24.sp
                                                else -> 28.sp
                                            },
                                            color = fg
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Swipe anywhere on the board to slide & merge tiles",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun ScoreChip(label: String, value: Int, accent: Color) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceCard)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = accent)
        Text(
            "$value",
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = TextPrimary
        )
    }
}

private fun tileColors(value: Int): Pair<Color, Color> = when (value) {
    0 -> Color(0xFF0E1426) to Color.Transparent
    2 -> Color(0xFF1E293B) to Color(0xFFF8FAFC)
    4 -> Color(0xFF334155) to Color(0xFFF8FAFC)
    8 -> Color(0xFFEA580C) to Color.White
    16 -> Color(0xFFF97316) to Color.White
    32 -> Color(0xFFEF4444) to Color.White
    64 -> Color(0xFFDC2626) to Color.White
    128 -> Color(0xFFF59E0B) to BgObsidian
    256 -> Color(0xFFFBBF24) to BgObsidian
    512 -> Color(0xFF10B981) to BgObsidian
    1024 -> Color(0xFF06B6D4) to BgObsidian
    else -> Color(0xFF8B5CF6) to Color.White
}
