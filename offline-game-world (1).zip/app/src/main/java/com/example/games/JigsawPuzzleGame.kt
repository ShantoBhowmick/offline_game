package com.example.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun JigsawPuzzleScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    val gridN = when (difficulty) {
        Difficulty.EASY -> 3
        Difficulty.MEDIUM -> 4
        Difficulty.HARD -> 5
    }

    fun shuffledTiles(n: Int): List<Int> {
        val list = (0 until n * n).shuffled()
        return if (list.indices.all { list[it] == it }) shuffledTiles(n) else list
    }

    var tiles by remember(difficulty) { mutableStateOf(shuffledTiles(gridN)) }
    var selectedSlot by remember(difficulty) { mutableIntStateOf(-1) }
    var moves by remember(difficulty) { mutableIntStateOf(0) }
    var showPreview by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }
    var won by remember(difficulty) { mutableStateOf(false) }

    fun restart(diff: Difficulty = difficulty) {
        val n = when (diff) {
            Difficulty.EASY -> 3; Difficulty.MEDIUM -> 4; Difficulty.HARD -> 5
        }
        tiles = shuffledTiles(n)
        selectedSlot = -1
        moves = 0
        won = false
        isPaused = false
    }

    fun tapSlot(slot: Int) {
        if (isPaused || won) return
        if (tiles[slot] == slot) {
            SoundManager.playTap()
            return
        }
        if (selectedSlot < 0) {
            selectedSlot = slot
            SoundManager.playTap()
            return
        }
        if (selectedSlot == slot) {
            selectedSlot = -1
            return
        }
        val next = tiles.toMutableList()
        val tmp = next[selectedSlot]
        next[selectedSlot] = next[slot]
        next[slot] = tmp
        tiles = next
        selectedSlot = -1
        moves++
        if (next[slot] == slot) SoundManager.playMatch() else SoundManager.playMove()

        if (next.indices.all { next[it] == it }) {
            won = true
            val score = (gridN * gridN * 80 - moves * 5).coerceAtLeast(150)
            SoundManager.playWin()
            session.onRecordResult(score, true, true)
        }
    }

    val lockedCount = tiles.indices.count { tiles[it] == it }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; restart(it) },
        scoreText = "LOCKED $lockedCount/${gridN * gridN}",
        bestScoreText = "MOVES $moves",
        gameOverTitle = if (won) "Artwork Assembled!" else null,
        gameOverSubtitle = "Completed ${gridN}x${gridN} puzzle in $moves swaps",
        isWin = won,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().widthIn(max = 380.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tap any two unlocked tiles to swap",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Button(
                    onClick = { showPreview = !showPreview; SoundManager.playTap() },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated, contentColor = TextPrimary)
                ) {
                    Icon(
                        if (showPreview) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = "Preview Artwork"
                    )
                    Spacer(Modifier.padding(start = 6.dp))
                    Text(if (showPreview) "Hide Guide" else "Preview")
                }
            }

            Spacer(Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 380.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(SurfaceCard)
                    .border(2.dp, SurfaceBorder, RoundedCornerShape(18.dp))
                    .padding(6.dp)
            ) {
                if (showPreview) {
                    Canvas(modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))) {
                        drawVectorLandscape(size.width, size.height)
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        for (r in 0 until gridN) {
                            Row(
                                modifier = Modifier.fillMaxWidth().weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                for (c in 0 until gridN) {
                                    val slot = r * gridN + c
                                    val tileId = tiles[slot]
                                    val srcR = tileId / gridN
                                    val srcC = tileId % gridN
                                    val isLocked = tileId == slot
                                    val isSel = slot == selectedSlot

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxSize()
                                            .clip(RoundedCornerShape(6.dp))
                                            .border(
                                                width = if (isSel) 2.5.dp else if (isLocked) 1.5.dp else 1.dp,
                                                color = when {
                                                    isSel -> NeonCyan
                                                    isLocked -> NeonEmerald
                                                    else -> SurfaceBorder
                                                },
                                                shape = RoundedCornerShape(6.dp)
                                            )
                                            .clickable { tapSlot(slot) }
                                    ) {
                                        Canvas(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .alpha(if (isLocked) 1f else 0.92f)
                                        ) {
                                            val fullW = size.width * gridN
                                            val fullH = size.height * gridN
                                            clipRect {
                                                translate(left = -srcC * size.width, top = -srcR * size.height) {
                                                    drawVectorLandscape(fullW, fullH)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawVectorLandscape(w: Float, h: Float) {
    // Cosmic Neon Sunset Mountain Artwork
    drawRect(
        brush = Brush.verticalGradient(
            listOf(Color(0xFF0F172A), Color(0xFF4C1D95), Color(0xFFDB2777), Color(0xFFF59E0B))
        ),
        size = Size(w, h)
    )
    // Glowing Sun
    drawCircle(
        brush = Brush.radialGradient(listOf(NeonAmber, NeonMagenta, Color.Transparent)),
        radius = w * 0.24f,
        center = Offset(w * 0.5f, h * 0.38f)
    )
    drawCircle(Color(0xFFFDE047), radius = w * 0.14f, center = Offset(w * 0.5f, h * 0.38f))

    // Stars
    val stars = listOf(0.15f to 0.14f, 0.28f to 0.22f, 0.72f to 0.16f, 0.84f to 0.26f, 0.42f to 0.12f)
    stars.forEach { (sx, sy) ->
        drawCircle(NeonCyan, radius = w * 0.012f, center = Offset(w * sx, h * sy))
    }

    // Back Mountain
    val backMtn = Path().apply {
        moveTo(0f, h * 0.75f)
        lineTo(w * 0.28f, h * 0.42f)
        lineTo(w * 0.55f, h * 0.66f)
        lineTo(w * 0.80f, h * 0.38f)
        lineTo(w, h * 0.70f)
        lineTo(w, h)
        lineTo(0f, h)
        close()
    }
    drawPath(backMtn, Color(0xFF1E1B4B))

    // Front Mountain + Cyan Lake Reflection
    val frontMtn = Path().apply {
        moveTo(0f, h * 0.82f)
        lineTo(w * 0.38f, h * 0.55f)
        lineTo(w * 0.68f, h * 0.80f)
        lineTo(w, h * 0.62f)
        lineTo(w, h)
        lineTo(0f, h)
        close()
    }
    drawPath(frontMtn, Color(0xFF090D1A))
    drawRect(
        brush = Brush.verticalGradient(listOf(NeonCyan.copy(alpha = 0.55f), Color(0xFF0F172A))),
        topLeft = Offset(0f, h * 0.80f),
        size = Size(w, h * 0.20f)
    )
}
