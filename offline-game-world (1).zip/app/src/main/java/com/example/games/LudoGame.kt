package com.example.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.PlayerMode
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

// 0=Red(Bottom-Left), 1=Green(Top-Left), 2=Yellow(Top-Right), 3=Blue(Bottom-Right)
private object LudoBoard {
    val playerColors = listOf(
        Color(0xFFEF4444), // Red
        Color(0xFF22C55E), // Green
        Color(0xFFFACC15), // Yellow
        Color(0xFF3B82F6)  // Blue
    )
    val playerNames = listOf("Red", "Green", "Yellow", "Blue")

    // 52 outer track coordinates (row, col) in 15x15 grid clockwise starting at Red's exit (13, 6)
    val outerTrack: List<Pair<Int, Int>> = listOf(
        13 to 6, 12 to 6, 11 to 6, 10 to 6, 9 to 6, // 0..4 going up
        8 to 5, 8 to 4, 8 to 3, 8 to 2, 8 to 1, 8 to 0, // 5..10 going left
        7 to 0, // 11
        6 to 0, 6 to 1, 6 to 2, 6 to 3, 6 to 4, 6 to 5, // 12..17 going right (13 = Green start)
        5 to 6, 4 to 6, 3 to 6, 2 to 6, 1 to 6, 0 to 6, // 18..23 going up
        0 to 7, // 24
        0 to 8, 1 to 8, 2 to 8, 3 to 8, 4 to 8, 5 to 8, // 25..30 going down (26 = Yellow start)
        6 to 9, 6 to 10, 6 to 11, 6 to 12, 6 to 13, 6 to 14, // 31..36 going right
        7 to 14, // 37
        8 to 14, 8 to 13, 8 to 12, 8 to 11, 8 to 10, 8 to 9, // 38..43 going left (39 = Blue start)
        9 to 8, 10 to 8, 11 to 8, 12 to 8, 13 to 8, 14 to 8, // 44..49 going down
        14 to 7, 14 to 6 // 50..51
    )

    val startOffsets = listOf(0, 13, 26, 39)
    val safeTrackIndices = setOf(0, 8, 13, 21, 26, 34, 39, 47)

    val homeStretches: List<List<Pair<Int, Int>>> = listOf(
        listOf(13 to 7, 12 to 7, 11 to 7, 10 to 7, 9 to 7, 8 to 7), // Red
        listOf(7 to 1, 7 to 2, 7 to 3, 7 to 4, 7 to 5, 7 to 6),     // Green
        listOf(1 to 7, 2 to 7, 3 to 7, 4 to 7, 5 to 7, 6 to 7),     // Yellow
        listOf(7 to 13, 7 to 12, 7 to 11, 7 to 10, 7 to 9, 7 to 8)  // Blue
    )

    val basePositions: List<List<Pair<Int, Int>>> = listOf(
        listOf(10 to 1, 10 to 4, 13 to 1, 13 to 4),   // Red BL
        listOf(1 to 1, 1 to 4, 4 to 1, 4 to 4),       // Green TL
        listOf(1 to 10, 1 to 13, 4 to 10, 4 to 13),   // Yellow TR
        listOf(10 to 10, 10 to 13, 13 to 10, 13 to 13)// Blue BR
    )

    // step: -1 = base, 0..50 = outer track relative, 51..56 = home stretch (56 = home finished!)
    fun tokenCell(player: Int, tokenIdx: Int, step: Int): Pair<Int, Int> {
        return when {
            step < 0 -> basePositions[player][tokenIdx]
            step <= 50 -> outerTrack[(startOffsets[player] + step) % 52]
            else -> homeStretches[player][(step - 51).coerceIn(0, 5)]
        }
    }

    fun outerIndex(player: Int, step: Int): Int? {
        if (step !in 0..50) return null
        return (startOffsets[player] + step) % 52
    }
}

@Composable
fun LudoScreen(session: GameSessionController) {
    var playerMode by remember { mutableStateOf(session.initialPlayerMode) }
    // 4 players x 4 tokens = 16 steps (-1 base, 0..56)
    var tokens by remember { mutableStateOf(List(4) { List(4) { -1 } }) }
    var currentPlayer by remember { mutableIntStateOf(0) }
    var diceValue by remember { mutableIntStateOf(0) }
    var awaitingMove by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("Roll the dice to begin!") }
    var isPaused by remember { mutableStateOf(false) }
    var winnerPlayer by remember { mutableIntStateOf(-1) }

    fun legalTokenIndices(player: Int, roll: Int, allTokens: List<List<Int>>): List<Int> {
        if (roll <= 0) return emptyList()
        return (0..3).filter { idx ->
            val step = allTokens[player][idx]
            when {
                step == -1 -> roll == 6
                step < 56 -> step + roll <= 56
                else -> false
            }
        }
    }

    fun restart() {
        tokens = List(4) { List(4) { -1 } }
        currentPlayer = 0
        diceValue = 0
        awaitingMove = false
        statusText = "Red's Turn — Tap Roll Dice"
        winnerPlayer = -1
        isPaused = false
    }

    fun advanceTurn(bonusTurn: Boolean) {
        awaitingMove = false
        if (!bonusTurn) {
            currentPlayer = (currentPlayer + 1) % 4
        }
        statusText = "${LudoBoard.playerNames[currentPlayer]}'s Turn" + if (bonusTurn) " (Bonus Roll!)" else ""
    }

    fun moveToken(player: Int, tokenIdx: Int) {
        if (!awaitingMove || player != currentPlayer || winnerPlayer >= 0) return
        val curStep = tokens[player][tokenIdx]
        val nextStep = if (curStep == -1) 0 else curStep + diceValue
        if (nextStep > 56) return

        val nextTokens = tokens.map { it.toMutableList() }.toMutableList()
        nextTokens[player][tokenIdx] = nextStep

        var captured = false
        val targetOuter = LudoBoard.outerIndex(player, nextStep)
        if (targetOuter != null && targetOuter !in LudoBoard.safeTrackIndices) {
            for (op in 0..3) {
                if (op == player) continue
                for (ot in 0..3) {
                    if (LudoBoard.outerIndex(op, nextTokens[op][ot]) == targetOuter) {
                        nextTokens[op][ot] = -1
                        captured = true
                    }
                }
            }
        }

        tokens = nextTokens
        when {
            nextStep == 56 -> SoundManager.playMatch()
            captured -> SoundManager.playCapture()
            else -> SoundManager.playMove()
        }

        if (nextTokens[player].all { it == 56 }) {
            winnerPlayer = player
            val humanWon = player == 0 || playerMode == PlayerMode.LOCAL_MULTIPLAYER
            if (humanWon) SoundManager.playWin() else SoundManager.playLose()
            session.onRecordResult(if (player == 0) 600 else 100, player == 0, true)
            return
        }

        val bonus = diceValue == 6 || captured || nextStep == 56
        advanceTurn(bonus)
    }

    fun rollDice() {
        if (isPaused || awaitingMove || winnerPlayer >= 0) return
        val roll = (1..6).random()
        diceValue = roll
        SoundManager.playDice()
        val legal = legalTokenIndices(currentPlayer, roll, tokens)
        if (legal.isEmpty()) {
            statusText = "${LudoBoard.playerNames[currentPlayer]} rolled $roll — No moves"
            awaitingMove = false
            currentPlayer = (currentPlayer + 1) % 4
        } else {
            awaitingMove = true
            statusText = "${LudoBoard.playerNames[currentPlayer]} rolled $roll — Pick a token"
            if (legal.size == 1 && (playerMode == PlayerMode.LOCAL_MULTIPLAYER || currentPlayer == 0)) {
                // Keep manual tap or auto-move when only 1 choice for snappy feel
                moveToken(currentPlayer, legal.first())
            }
        }
    }

    // AI Bot Turns (Players 1, 2, 3 when in SINGLE_PLAYER)
    LaunchedEffect(currentPlayer, awaitingMove, isPaused, winnerPlayer, playerMode) {
        if (!isPaused && winnerPlayer < 0 && playerMode == PlayerMode.SINGLE_PLAYER && currentPlayer != 0) {
            delay(450)
            if (!awaitingMove) {
                rollDice()
                delay(350)
            }
            if (awaitingMove && currentPlayer != 0) {
                val legal = legalTokenIndices(currentPlayer, diceValue, tokens)
                if (legal.isNotEmpty()) {
                    // Prefer capture, then leaving base, then furthest token
                    val pick = legal.maxByOrNull { idx ->
                        val s = tokens[currentPlayer][idx]
                        val ns = if (s == -1) 0 else s + diceValue
                        var score = ns
                        if (s == -1) score += 80
                        if (ns == 56) score += 120
                        val oIdx = LudoBoard.outerIndex(currentPlayer, ns)
                        if (oIdx != null && oIdx !in LudoBoard.safeTrackIndices) {
                            val hits = (0..3).any { op ->
                                op != currentPlayer && (0..3).any { ot -> LudoBoard.outerIndex(op, tokens[op][ot]) == oIdx }
                            }
                            if (hits) score += 200
                        }
                        score
                    } ?: legal.first()
                    moveToken(currentPlayer, pick)
                }
            }
        }
    }

    val isHumanTurn = playerMode == PlayerMode.LOCAL_MULTIPLAYER || currentPlayer == 0
    val legalForCurrent = if (awaitingMove) legalTokenIndices(currentPlayer, diceValue, tokens) else emptyList()

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        playerMode = playerMode,
        onPlayerModeChange = { playerMode = it; restart() },
        scoreText = "TURN: ${LudoBoard.playerNames[currentPlayer].uppercase()}",
        bestScoreText = if (diceValue > 0) "DICE $diceValue" else "4 PLAYERS",
        gameOverTitle = if (winnerPlayer >= 0) "${LudoBoard.playerNames[winnerPlayer]} Wins!" else null,
        gameOverSubtitle = "All 4 tokens reached the center crown!",
        isWin = winnerPlayer == 0 || (winnerPlayer >= 0 && playerMode == PlayerMode.LOCAL_MULTIPLAYER),
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = statusText,
                style = MaterialTheme.typography.titleMedium,
                color = LudoBoard.playerColors[currentPlayer]
            )

            // 15x15 Ludo Board
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 390.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0E1426))
                    .border(2.dp, SurfaceBorder, RoundedCornerShape(16.dp))
                    .padding(4.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cell = size.width / 15f
                    // Draw base quadrants
                    fun drawBase(r0: Int, c0: Int, col: Color) {
                        drawRoundRect(
                            col.copy(alpha = 0.28f),
                            Offset(c0 * cell, r0 * cell),
                            Size(cell * 6f, cell * 6f),
                            CornerRadius(12f, 12f)
                        )
                        drawRoundRect(
                            col,
                            Offset(c0 * cell, r0 * cell),
                            Size(cell * 6f, cell * 6f),
                            CornerRadius(12f, 12f),
                            style = Stroke(3f)
                        )
                    }
                    drawBase(9, 0, LudoBoard.playerColors[0]) // Red BL
                    drawBase(0, 0, LudoBoard.playerColors[1]) // Green TL
                    drawBase(0, 9, LudoBoard.playerColors[2]) // Yellow TR
                    drawBase(9, 9, LudoBoard.playerColors[3]) // Blue BR

                    // Draw outer track
                    LudoBoard.outerTrack.forEachIndexed { idx, (r, c) ->
                        val startPlayer = LudoBoard.startOffsets.indexOf(idx)
                        val fill = when {
                            startPlayer >= 0 -> LudoBoard.playerColors[startPlayer].copy(alpha = 0.55f)
                            idx in LudoBoard.safeTrackIndices -> Color(0xFF334155)
                            else -> Color(0xFF1E293B)
                        }
                        drawRect(fill, Offset(c * cell + 1f, r * cell + 1f), Size(cell - 2f, cell - 2f))
                        if (idx in LudoBoard.safeTrackIndices) {
                            drawCircle(NeonAmber, cell * 0.16f, Offset(c * cell + cell / 2f, r * cell + cell / 2f))
                        }
                    }

                    // Draw home stretches
                    LudoBoard.homeStretches.forEachIndexed { p, cells ->
                        cells.dropLast(1).forEach { (r, c) ->
                            drawRect(
                                LudoBoard.playerColors[p].copy(alpha = 0.55f),
                                Offset(c * cell + 1f, r * cell + 1f),
                                Size(cell - 2f, cell - 2f)
                            )
                        }
                    }

                    // Center Goal Crown
                    drawRoundRect(
                        NeonAmber.copy(alpha = 0.25f),
                        Offset(6 * cell, 6 * cell),
                        Size(3 * cell, 3 * cell),
                        CornerRadius(8f, 8f)
                    )
                    drawCircle(NeonAmber, cell * 0.55f, Offset(7.5f * cell, 7.5f * cell))

                    // Draw all 16 tokens
                    for (p in 0..3) {
                        for (t in 0..3) {
                            val step = tokens[p][t]
                            val (r, c) = LudoBoard.tokenCell(p, t, step)
                            val cx = c * cell + cell / 2f + (if (step == 56) (p - 1.5f) * 3f else 0f)
                            val cy = r * cell + cell / 2f + (if (step == 56) (t - 1.5f) * 2f else 0f)
                            val isHighlight = p == currentPlayer && awaitingMove && t in legalForCurrent
                            if (isHighlight) {
                                drawCircle(Color.White, cell * 0.48f, Offset(cx, cy))
                            }
                            drawCircle(LudoBoard.playerColors[p], cell * 0.37f, Offset(cx, cy))
                            drawCircle(Color.White, cell * 0.37f, Offset(cx, cy), style = Stroke(2f))
                        }
                    }
                }
            }

            // Dice + Token Selector Controls
            Column(
                modifier = Modifier.fillMaxWidth().widthIn(max = 390.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (awaitingMove && isHumanTurn && legalForCurrent.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        legalForCurrent.forEach { tIdx ->
                            val step = tokens[currentPlayer][tIdx]
                            Button(
                                onClick = { moveToken(currentPlayer, tIdx) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = LudoBoard.playerColors[currentPlayer],
                                    contentColor = BgObsidian
                                )
                            ) {
                                Text(
                                    text = if (step < 0) "Deploy #${tIdx + 1}" else "Move #${tIdx + 1}",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Button(
                    onClick = { rollDice() },
                    enabled = !isPaused && isHumanTurn && !awaitingMove && winnerPlayer < 0,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = LudoBoard.playerColors[currentPlayer],
                        contentColor = BgObsidian
                    ),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Text(
                        text = if (diceValue > 0 && awaitingMove) "Rolled: $diceValue — Choose Token Above" else "ROLL DICE (${LudoBoard.playerNames[currentPlayer]})",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
