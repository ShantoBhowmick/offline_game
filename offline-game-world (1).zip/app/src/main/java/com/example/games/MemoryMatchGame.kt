package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CrueltyFree
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.QuestionMark
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.core.model.PlayerMode
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

private data class MemoryCardModel(
    val id: Int,
    val pairKey: Int,
    val icon: ImageVector,
    val color: Color,
    val isFaceUp: Boolean = false,
    val isMatched: Boolean = false
)

@Composable
fun MemoryMatchScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var playerMode by remember { mutableStateOf(session.initialPlayerMode) }
    val (rows, cols) = when (difficulty) {
        Difficulty.EASY -> 3 to 4
        Difficulty.MEDIUM -> 4 to 4
        Difficulty.HARD -> 6 to 4
    }

    val iconPool = remember {
        listOf(
            Icons.Default.Bolt to NeonAmber,
            Icons.Default.Favorite to NeonMagenta,
            Icons.Default.Star to Color(0xFFFACC15),
            Icons.Default.Diamond to NeonCyan,
            Icons.Default.LocalFireDepartment to Color(0xFFFF5A5F),
            Icons.Default.Eco to NeonEmerald,
            Icons.Default.AcUnit to Color(0xFF60A5FA),
            Icons.Default.RocketLaunch to NeonViolet,
            Icons.Default.Pets to Color(0xFFFB923C),
            Icons.Default.MusicNote to Color(0xFFF472B6),
            Icons.Default.WbSunny to Color(0xFFFDE047),
            Icons.Default.CrueltyFree to Color(0xFF2DD4BF)
        )
    }

    fun buildDeck(r: Int, c: Int): List<MemoryCardModel> {
        val pairs = (r * c) / 2
        val chosen = iconPool.take(pairs)
        val raw = chosen.flatMapIndexed { idx, (icon, col) ->
            listOf(
                MemoryCardModel(idx * 2, idx, icon, col),
                MemoryCardModel(idx * 2 + 1, idx, icon, col)
            )
        }.shuffled()
        return raw
    }

    var cards by remember { mutableStateOf(buildDeck(rows, cols)) }
    var firstIdx by remember { mutableIntStateOf(-1) }
    var secondIdx by remember { mutableIntStateOf(-1) }
    var isChecking by remember { mutableStateOf(false) }
    var moves by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var p1Pairs by remember { mutableIntStateOf(0) }
    var p2Pairs by remember { mutableIntStateOf(0) }
    var turn by remember { mutableIntStateOf(1) }
    var streak by remember { mutableIntStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }
    var completed by remember { mutableStateOf(false) }

    fun restart(diff: Difficulty = difficulty) {
        val (nr, nc) = when (diff) {
            Difficulty.EASY -> 3 to 4
            Difficulty.MEDIUM -> 4 to 4
            Difficulty.HARD -> 6 to 4
        }
        cards = buildDeck(nr, nc)
        firstIdx = -1
        secondIdx = -1
        isChecking = false
        moves = 0
        score = 0
        p1Pairs = 0
        p2Pairs = 0
        turn = 1
        streak = 0
        completed = false
        isPaused = false
    }

    LaunchedEffect(isChecking) {
        if (isChecking && firstIdx >= 0 && secondIdx >= 0) {
            delay(650)
            val next = cards.toMutableList()
            val c1 = next[firstIdx]
            val c2 = next[secondIdx]
            if (c1.pairKey == c2.pairKey) {
                next[firstIdx] = c1.copy(isMatched = true)
                next[secondIdx] = c2.copy(isMatched = true)
                streak++
                score += 100 * streak
                if (turn == 1) p1Pairs++ else p2Pairs++
                SoundManager.playMatch()
            } else {
                next[firstIdx] = c1.copy(isFaceUp = false)
                next[secondIdx] = c2.copy(isFaceUp = false)
                streak = 0
                if (playerMode == PlayerMode.LOCAL_MULTIPLAYER) {
                    turn = if (turn == 1) 2 else 1
                }
            }
            cards = next
            firstIdx = -1
            secondIdx = -1
            isChecking = false

            if (next.all { it.isMatched }) {
                completed = true
                SoundManager.playWin()
                val finalScore = (score - moves * 5).coerceAtLeast(100)
                score = finalScore
                session.onRecordResult(finalScore, true, true)
            }
        }
    }

    fun onCardTap(idx: Int) {
        if (isPaused || isChecking || completed) return
        val card = cards[idx]
        if (card.isFaceUp || card.isMatched) return

        SoundManager.playTap()
        val next = cards.toMutableList()
        next[idx] = card.copy(isFaceUp = true)
        cards = next

        if (firstIdx < 0) {
            firstIdx = idx
        } else {
            secondIdx = idx
            moves++
            isChecking = true
        }
    }

    val overTitle = if (completed) {
        if (playerMode == PlayerMode.LOCAL_MULTIPLAYER) {
            when {
                p1Pairs > p2Pairs -> "Player 1 Wins!"
                p2Pairs > p1Pairs -> "Player 2 Wins!"
                else -> "Tie Game!"
            }
        } else "All Pairs Matched!"
    } else null

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = {
            difficulty = it
            restart(it)
        },
        playerMode = playerMode,
        onPlayerModeChange = {
            playerMode = it
            restart()
        },
        scoreText = if (playerMode == PlayerMode.LOCAL_MULTIPLAYER) "P1:$p1Pairs  P2:$p2Pairs" else "SCORE $score",
        bestScoreText = "MOVES $moves",
        gameOverTitle = overTitle,
        gameOverSubtitle = "Completed in $moves moves • Score $score",
        isWin = completed,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (playerMode == PlayerMode.LOCAL_MULTIPLAYER) {
                Text(
                    text = "Player $turn's Turn",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (turn == 1) NeonCyan else NeonMagenta
                )
                Spacer(Modifier.height(10.dp))
            }

            Column(
                modifier = Modifier.fillMaxWidth().widthIn(max = 380.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (r in 0 until rows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (c in 0 until cols) {
                            val idx = r * cols + c
                            val card = cards[idx]
                            val revealed = card.isFaceUp || card.isMatched
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(0.85f)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        when {
                                            card.isMatched -> card.color.copy(alpha = 0.22f)
                                            revealed -> SurfaceElevated
                                            else -> SurfaceCard
                                        }
                                    )
                                    .border(
                                        width = if (revealed) 1.5.dp else 1.dp,
                                        color = if (revealed) card.color else SurfaceBorder,
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .clickable { onCardTap(idx) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (revealed) {
                                    Icon(
                                        imageVector = card.icon,
                                        contentDescription = "Card Symbol",
                                        tint = card.color,
                                        modifier = Modifier.size(30.dp)
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.QuestionMark,
                                        contentDescription = "Hidden Card",
                                        tint = TextSecondary.copy(alpha = 0.45f),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
