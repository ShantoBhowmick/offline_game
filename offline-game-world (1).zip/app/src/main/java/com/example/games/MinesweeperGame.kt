package com.example.games

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.delay

private data class MineCell(
    val isMine: Boolean = false,
    val isRevealed: Boolean = false,
    val isFlagged: Boolean = false,
    val adjacent: Int = 0
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MinesweeperScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    val (rows, cols, totalMines) = when (difficulty) {
        Difficulty.EASY -> Triple(8, 8, 10)
        Difficulty.MEDIUM -> Triple(10, 9, 16)
        Difficulty.HARD -> Triple(12, 10, 25)
    }

    var grid by remember(difficulty) { mutableStateOf(List(rows * cols) { MineCell() }) }
    var minesPlaced by remember(difficulty) { mutableStateOf(false) }
    var flagMode by remember { mutableStateOf(false) }
    var elapsedSec by remember(difficulty) { mutableIntStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }
    var gameState by remember(difficulty) { mutableIntStateOf(0) } // 0 playing, 1 win, -1 lose

    fun neighbors(idx: Int): List<Int> {
        val r = idx / cols
        val c = idx % cols
        val list = mutableListOf<Int>()
        for (dr in -1..1) {
            for (dc in -1..1) {
                if (dr == 0 && dc == 0) continue
                val nr = r + dr
                val nc = c + dc
                if (nr in 0 until rows && nc in 0 until cols) list.add(nr * cols + nc)
            }
        }
        return list
    }

    fun placeMinesSafe(safeIdx: Int): List<MineCell> {
        val safeZone = neighbors(safeIdx).toSet() + safeIdx
        val candidates = (0 until rows * cols).filter { it !in safeZone }.shuffled().take(totalMines).toSet()
        val raw = MutableList(rows * cols) { idx -> MineCell(isMine = idx in candidates) }
        for (i in raw.indices) {
            if (!raw[i].isMine) {
                raw[i] = raw[i].copy(adjacent = neighbors(i).count { raw[it].isMine })
            }
        }
        return raw
    }

    fun reveal(idx: Int) {
        if (isPaused || gameState != 0) return
        var current = grid
        if (current[idx].isRevealed || current[idx].isFlagged) return

        if (!minesPlaced) {
            current = placeMinesSafe(idx)
            minesPlaced = true
        }

        val mutable = current.toMutableList()
        if (mutable[idx].isMine) {
            for (i in mutable.indices) {
                if (mutable[i].isMine) mutable[i] = mutable[i].copy(isRevealed = true)
            }
            grid = mutable
            gameState = -1
            SoundManager.playLose()
            session.onRecordResult(0, false, true)
            return
        }

        val queue = ArrayDeque<Int>()
        queue.add(idx)
        while (queue.isNotEmpty()) {
            val cur = queue.removeFirst()
            if (mutable[cur].isRevealed || mutable[cur].isFlagged) continue
            mutable[cur] = mutable[cur].copy(isRevealed = true)
            if (mutable[cur].adjacent == 0) {
                neighbors(cur).forEach { n ->
                    if (!mutable[n].isRevealed && !mutable[n].isMine) queue.add(n)
                }
            }
        }

        grid = mutable
        SoundManager.playMove()

        val unrevealedSafe = mutable.count { !it.isMine && !it.isRevealed }
        if (unrevealedSafe == 0) {
            gameState = 1
            val score = ((totalMines * 40) - elapsedSec * 2).coerceAtLeast(100)
            SoundManager.playWin()
            session.onRecordResult(score, true, true)
        }
    }

    fun toggleFlag(idx: Int) {
        if (isPaused || gameState != 0 || grid[idx].isRevealed) return
        val next = grid.toMutableList()
        next[idx] = next[idx].copy(isFlagged = !next[idx].isFlagged)
        grid = next
        SoundManager.playTap()
    }

    fun restart() {
        grid = List(rows * cols) { MineCell() }
        minesPlaced = false
        elapsedSec = 0
        gameState = 0
        isPaused = false
    }

    LaunchedEffect(minesPlaced, isPaused, gameState) {
        while (minesPlaced && !isPaused && gameState == 0) {
            delay(1000)
            elapsedSec++
        }
    }

    val flaggedCount = grid.count { it.isFlagged }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; restart() },
        scoreText = "MINES ${totalMines - flaggedCount}",
        bestScoreText = "TIME ${elapsedSec}s",
        gameOverTitle = when (gameState) {
            1 -> "Field Cleared!"
            -1 -> "Boom! Mine Hit"
            else -> null
        },
        gameOverSubtitle = if (gameState == 1) "Cleared in ${elapsedSec}s" else "Tap Play Again to sweep a new field",
        isWin = gameState == 1,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { flagMode = !flagMode; SoundManager.playTap() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (flagMode) NeonAmber else SurfaceElevated,
                        contentColor = if (flagMode) BgObsidian else TextPrimary
                    )
                ) {
                    Icon(
                        imageVector = if (flagMode) Icons.Default.Flag else Icons.Default.Visibility,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.padding(start = 6.dp))
                    Text(if (flagMode) "Flag Mode ON" else "Reveal Mode")
                }

                Text(
                    text = "Long-press also flags",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF94A3B8)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 420.dp)
                    .aspectRatio(cols.toFloat() / rows.toFloat())
                    .clip(RoundedCornerShape(16.dp))
                    .background(SurfaceCard)
                    .border(1.5.dp, SurfaceBorder, RoundedCornerShape(16.dp))
                    .padding(6.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    for (r in 0 until rows) {
                        Row(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            for (c in 0 until cols) {
                                val idx = r * cols + c
                                val cell = grid[idx]
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(5.dp))
                                        .background(
                                            when {
                                                cell.isRevealed && cell.isMine -> NeonCoral.copy(alpha = 0.35f)
                                                cell.isRevealed -> Color(0xFF0E1426)
                                                cell.isFlagged -> NeonAmber.copy(alpha = 0.22f)
                                                else -> SurfaceElevated
                                            }
                                        )
                                        .border(
                                            0.8.dp,
                                            if (cell.isRevealed) Color(0xFF1F2B47) else SurfaceBorder,
                                            RoundedCornerShape(5.dp)
                                        )
                                        .combinedClickable(
                                            onClick = { if (flagMode) toggleFlag(idx) else reveal(idx) },
                                            onLongClick = { toggleFlag(idx) }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    when {
                                        cell.isFlagged && !cell.isRevealed -> {
                                            Icon(
                                                Icons.Default.Flag,
                                                contentDescription = "Flag",
                                                tint = NeonAmber,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                        cell.isRevealed && cell.isMine -> {
                                            Text("✸", color = NeonCoral, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                        }
                                        cell.isRevealed && cell.adjacent > 0 -> {
                                            Text(
                                                text = "${cell.adjacent}",
                                                fontFamily = JetBrainsMonoFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = when (cell.adjacent) {
                                                    1 -> NeonCyan
                                                    2 -> NeonEmerald
                                                    3 -> NeonCoral
                                                    4 -> Color(0xFFA855F7)
                                                    else -> NeonAmber
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
