package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlin.math.abs

object Slide15Engine {
    fun createSolvableBoard(n: Int): List<Int> {
        val list = (1 until n * n).toMutableList() + 0
        val mutable = list.toMutableList()
        var emptyIdx = n * n - 1
        var prevEmpty = -1
        repeat(n * n * 18) {
            val er = emptyIdx / n
            val ec = emptyIdx % n
            val neighbors = listOfNotNull(
                if (er > 0) (er - 1) * n + ec else null,
                if (er < n - 1) (er + 1) * n + ec else null,
                if (ec > 0) er * n + (ec - 1) else null,
                if (ec < n - 1) er * n + (ec + 1) else null
            ).filter { it != prevEmpty }
            val pick = neighbors.random()
            mutable[emptyIdx] = mutable[pick]
            mutable[pick] = 0
            prevEmpty = emptyIdx
            emptyIdx = pick
        }
        return if (isSolved(mutable)) createSolvableBoard(n) else mutable
    }

    fun isSolved(board: List<Int>): Boolean {
        for (i in 0 until board.lastIndex) {
            if (board[i] != i + 1) return false
        }
        return board.last() == 0
    }
}

@Composable
fun NumberPuzzleScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    val n = when (difficulty) {
        Difficulty.EASY -> 3
        Difficulty.MEDIUM -> 4
        Difficulty.HARD -> 5
    }
    var board by remember(difficulty) { mutableStateOf(Slide15Engine.createSolvableBoard(n)) }
    var moves by remember(difficulty) { mutableIntStateOf(0) }
    var elapsedSec by remember(difficulty) { mutableIntStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }
    var won by remember(difficulty) { mutableStateOf(false) }

    LaunchedEffect(isPaused, won) {
        while (!isPaused && !won) {
            delay(1000)
            elapsedSec++
        }
    }

    fun restart(diff: Difficulty = difficulty) {
        val size = when (diff) {
            Difficulty.EASY -> 3
            Difficulty.MEDIUM -> 4
            Difficulty.HARD -> 5
        }
        board = Slide15Engine.createSolvableBoard(size)
        moves = 0
        elapsedSec = 0
        won = false
        isPaused = false
    }

    fun tapTile(idx: Int) {
        if (isPaused || won || board[idx] == 0) return
        val emptyIdx = board.indexOf(0)
        val r1 = idx / n; val c1 = idx % n
        val r2 = emptyIdx / n; val c2 = emptyIdx % n
        if (abs(r1 - r2) + abs(c1 - c2) == 1) {
            val next = board.toMutableList()
            next[emptyIdx] = next[idx]
            next[idx] = 0
            board = next
            moves++
            SoundManager.playMove()
            if (Slide15Engine.isSolved(next)) {
                won = true
                val score = ((1500 - moves * 4 - elapsedSec * 2) * (n - 1)).coerceAtLeast(150)
                SoundManager.playWin()
                session.onRecordResult(score, true, true)
            }
        }
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = {
            difficulty = it
            restart(it)
        },
        scoreText = "MOVES $moves",
        bestScoreText = "TIME ${elapsedSec}s",
        gameOverTitle = if (won) "Sequence Solved!" else null,
        gameOverSubtitle = "Solved ${n}x${n} in $moves moves (${elapsedSec}s)",
        isWin = won,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Tap any tile next to the empty space to slide it",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Spacer(Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 370.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.5.dp, SurfaceBorder, RoundedCornerShape(20.dp))
                    .padding(10.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (r in 0 until n) {
                        Row(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            for (c in 0 until n) {
                                val idx = r * n + c
                                val num = board[idx]
                                val inRightPlace = num == idx + 1
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            when {
                                                num == 0 -> androidx.compose.ui.graphics.SolidColor(Color(0xFF0A0F1D))
                                                inRightPlace -> Brush.linearGradient(
                                                    listOf(Color(0xFF0284C7), Color(0xFF10B981))
                                                )
                                                else -> Brush.linearGradient(
                                                    listOf(SurfaceElevated, Color(0xFF233056))
                                                )
                                            }
                                        )
                                        .border(
                                            1.dp,
                                            if (inRightPlace) NeonEmerald else SurfaceBorder,
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable { tapTile(idx) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (num > 0) {
                                        Text(
                                            text = "$num",
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = if (n == 5) 20.sp else 26.sp,
                                            color = TextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
