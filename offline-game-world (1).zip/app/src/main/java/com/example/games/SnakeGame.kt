package com.example.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.delay
import kotlin.math.abs

private data class GridPt(val x: Int, val y: Int)

private enum class SnakeDir(val dx: Int, val dy: Int) {
    UP(0, -1), DOWN(0, 1), LEFT(-1, 0), RIGHT(1, 0);

    fun isOpposite(other: SnakeDir): Boolean = dx == -other.dx && dy == -other.dy
}

@Composable
fun SnakeGameScreen(session: GameSessionController) {
    val gridSize = 18
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var snake by remember { mutableStateOf(listOf(GridPt(9, 9), GridPt(8, 9), GridPt(7, 9))) }
    var dir by remember { mutableStateOf(SnakeDir.RIGHT) }
    var pendingDir by remember { mutableStateOf(SnakeDir.RIGHT) }
    var food by remember { mutableStateOf(GridPt(14, 9)) }
    var bonusFood by remember { mutableStateOf<GridPt?>(null) }
    var bonusTicks by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }
    var isGameOver by remember { mutableStateOf(false) }

    fun randomFreeCell(occupied: List<GridPt>): GridPt {
        val free = mutableListOf<GridPt>()
        for (y in 0 until gridSize) {
            for (x in 0 until gridSize) {
                val p = GridPt(x, y)
                if (p !in occupied) free.add(p)
            }
        }
        return if (free.isEmpty()) GridPt(0, 0) else free.random()
    }

    fun restart() {
        val initSnake = listOf(GridPt(9, 9), GridPt(8, 9), GridPt(7, 9))
        snake = initSnake
        dir = SnakeDir.RIGHT
        pendingDir = SnakeDir.RIGHT
        food = randomFreeCell(initSnake)
        bonusFood = null
        bonusTicks = 0
        score = 0
        isGameOver = false
        isPaused = false
    }

    fun setDirection(next: SnakeDir) {
        if (!next.isOpposite(dir) && next != pendingDir) {
            pendingDir = next
            SoundManager.playTap()
        }
    }

    LaunchedEffect(isPaused, isGameOver, difficulty) {
        val tickMs = when (difficulty) {
            Difficulty.EASY -> 185L
            Difficulty.MEDIUM -> 135L
            Difficulty.HARD -> 92L
        }
        while (!isPaused && !isGameOver) {
            delay(tickMs)
            dir = pendingDir
            val head = snake.first()
            val nextHead = GridPt(head.x + dir.dx, head.y + dir.dy)

            val hitWall = nextHead.x !in 0 until gridSize || nextHead.y !in 0 until gridSize
            val ateFood = nextHead == food
            val bodyToCheck = if (ateFood) snake else snake.dropLast(1)
            val hitSelf = nextHead in bodyToCheck

            if (hitWall || hitSelf) {
                isGameOver = true
                SoundManager.playLose()
                session.onRecordResult(score, score >= 100, true)
                break
            }

            val ateBonus = bonusFood != null && nextHead == bonusFood
            val nextSnake = buildList {
                add(nextHead)
                addAll(if (ateFood || ateBonus) snake else snake.dropLast(1))
            }
            snake = nextSnake

            if (ateFood) {
                score += 10
                SoundManager.playMatch()
                food = randomFreeCell(nextSnake)
                if (bonusFood == null && Math.random() < 0.25) {
                    bonusFood = randomFreeCell(nextSnake + food)
                    bonusTicks = 35
                }
            } else if (ateBonus) {
                score += 30
                SoundManager.playWin()
                bonusFood = null
                bonusTicks = 0
            }

            if (bonusFood != null) {
                bonusTicks--
                if (bonusTicks <= 0) bonusFood = null
            }
        }
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = {
            difficulty = it
            restart()
        },
        scoreText = "SCORE $score",
        bestScoreText = "BEST ${maxOf(score, session.bestScore)}",
        gameOverTitle = if (isGameOver) "Crashed!" else null,
        gameOverSubtitle = "Final Score: $score • Length ${snake.size}",
        isWin = score >= 100,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Arena Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 360.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(SurfaceCard)
                    .border(2.dp, NeonEmerald.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
                    .pointerInput(Unit) {
                        var ax = 0f
                        var ay = 0f
                        var fired = false
                        detectDragGestures(
                            onDragStart = { ax = 0f; ay = 0f; fired = false },
                            onDrag = { change, amt ->
                                change.consume()
                                if (fired) return@detectDragGestures
                                ax += amt.x
                                ay += amt.y
                                if (abs(ax) > 28f || abs(ay) > 28f) {
                                    fired = true
                                    if (abs(ax) > abs(ay)) {
                                        setDirection(if (ax > 0) SnakeDir.RIGHT else SnakeDir.LEFT)
                                    } else {
                                        setDirection(if (ay > 0) SnakeDir.DOWN else SnakeDir.UP)
                                    }
                                }
                            }
                        )
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize().padding(6.dp)) {
                    val cellW = size.width / gridSize
                    val cellH = size.height / gridSize

                    // Subtle grid dots
                    for (y in 0 until gridSize) {
                        for (x in 0 until gridSize) {
                            drawCircle(
                                color = Color(0xFF1F2A48),
                                radius = 2f,
                                center = Offset(x * cellW + cellW / 2f, y * cellH + cellH / 2f)
                            )
                        }
                    }

                    // Normal Apple
                    drawCircle(
                        color = NeonCoral,
                        radius = minOf(cellW, cellH) * 0.40f,
                        center = Offset(food.x * cellW + cellW / 2f, food.y * cellH + cellH / 2f)
                    )

                    // Bonus Golden Fruit
                    bonusFood?.let { bf ->
                        drawCircle(
                            color = NeonAmber,
                            radius = minOf(cellW, cellH) * 0.44f,
                            center = Offset(bf.x * cellW + cellW / 2f, bf.y * cellH + cellH / 2f)
                        )
                    }

                    // Snake Segments
                    snake.forEachIndexed { idx, pt ->
                        val col = when {
                            idx == 0 -> NeonCyan
                            idx % 2 == 0 -> NeonEmerald
                            else -> Color(0xFF059669)
                        }
                        val pad = if (idx == 0) 1f else 2f
                        drawRoundRect(
                            color = col,
                            topLeft = Offset(pt.x * cellW + pad, pt.y * cellH + pad),
                            size = Size(cellW - pad * 2, cellH - pad * 2),
                            cornerRadius = CornerRadius(cellW * 0.28f, cellW * 0.28f)
                        )
                    }
                }
            }

            // Mobile D-Pad Controls
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                DpadButton(Icons.Default.KeyboardArrowUp, "Up") { setDirection(SnakeDir.UP) }
                Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                    DpadButton(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Left") { setDirection(SnakeDir.LEFT) }
                    DpadButton(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Right") { setDirection(SnakeDir.RIGHT) }
                }
                DpadButton(Icons.Default.KeyboardArrowDown, "Down") { setDirection(SnakeDir.DOWN) }
            }
        }
    }
}

@Composable
private fun DpadButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    onClick: () -> Unit
) {
    FilledIconButton(
        onClick = onClick,
        shape = CircleShape,
        colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = SurfaceElevated,
            contentColor = TextPrimary
        ),
        modifier = Modifier.size(54.dp)
    ) {
        Icon(icon, contentDescription = desc, modifier = Modifier.size(28.dp))
    }
}
