package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary

private enum class CardSuit(val symbol: String, val isRed: Boolean) {
    SPADES("♠", false), HEARTS("♥", true), CLUBS("♣", false), DIAMONDS("♦", true)
}

private data class SolitaireCard(
    val suit: CardSuit,
    val rank: Int, // 1..13
    val faceUp: Boolean = false
) {
    val label: String
        get() = when (rank) {
            1 -> "A"; 11 -> "J"; 12 -> "Q"; 13 -> "K"; else -> "$rank"
        } + suit.symbol
}

private data class SolitaireState(
    val stock: List<SolitaireCard>,
    val waste: List<SolitaireCard>,
    val foundations: List<List<SolitaireCard>>,
    val tableau: List<List<SolitaireCard>>,
    val score: Int = 0
)

private sealed class SolitaireSel {
    data object Waste : SolitaireSel()
    data class Tableau(val col: Int, val index: Int) : SolitaireSel()
}

private fun dealSolitaire(): SolitaireState {
    val deck = CardSuit.entries.flatMap { suit ->
        (1..13).map { rank -> SolitaireCard(suit, rank, faceUp = false) }
    }.shuffled()
    var cursor = 0
    val tableau = MutableList(7) { col ->
        val pile = mutableListOf<SolitaireCard>()
        for (i in 0..col) {
            pile.add(deck[cursor++].copy(faceUp = i == col))
        }
        pile
    }
    val stock = deck.drop(cursor)
    return SolitaireState(
        stock = stock,
        waste = emptyList(),
        foundations = List(4) { emptyList() },
        tableau = tableau,
        score = 0
    )
}

@Composable
fun SolitaireScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var state by remember { mutableStateOf(dealSolitaire()) }
    var undoStack by remember { mutableStateOf(emptyList<SolitaireState>()) }
    var selection by remember { mutableStateOf<SolitaireSel?>(null) }
    var isPaused by remember { mutableStateOf(false) }
    var won by remember { mutableStateOf(false) }

    val drawCount = if (difficulty == Difficulty.HARD) 3 else 1

    fun pushState(next: SolitaireState) {
        undoStack = (undoStack + state).takeLast(20)
        state = next
        selection = null
        if (next.foundations.sumOf { it.size } == 52) {
            won = true
            SoundManager.playWin()
            session.onRecordResult((next.score + 500).coerceAtLeast(500), true, true)
        }
    }

    fun drawFromStock() {
        if (isPaused || won) return
        if (state.stock.isNotEmpty()) {
            val count = minOf(drawCount, state.stock.size)
            val drawn = state.stock.take(count).map { it.copy(faceUp = true) }
            pushState(state.copy(stock = state.stock.drop(count), waste = state.waste + drawn))
            SoundManager.playTap()
        } else if (state.waste.isNotEmpty()) {
            pushState(state.copy(stock = state.waste.map { it.copy(faceUp = false) }, waste = emptyList()))
            SoundManager.playTap()
        }
    }

    fun canMoveToFoundation(card: SolitaireCard, pile: List<SolitaireCard>): Boolean {
        return if (pile.isEmpty()) card.rank == 1
        else pile.last().suit == card.suit && pile.last().rank == card.rank - 1
    }

    fun canMoveToTableau(card: SolitaireCard, pile: List<SolitaireCard>): Boolean {
        return if (pile.isEmpty()) card.rank == 13
        else pile.last().faceUp && pile.last().suit.isRed != card.suit.isRed && pile.last().rank == card.rank + 1
    }

    fun flipTop(pile: List<SolitaireCard>): List<SolitaireCard> {
        if (pile.isEmpty() || pile.last().faceUp) return pile
        return pile.dropLast(1) + pile.last().copy(faceUp = true)
    }

    fun tryMoveToFoundation(fIdx: Int): Boolean {
        val sel = selection ?: return false
        val card = when (sel) {
            is SolitaireSel.Waste -> state.waste.lastOrNull()
            is SolitaireSel.Tableau -> {
                val col = state.tableau[sel.col]
                if (sel.index == col.lastIndex) col.lastOrNull() else null
            }
        } ?: return false

        if (!canMoveToFoundation(card, state.foundations[fIdx])) return false
        val newFoundations = state.foundations.toMutableList().apply { this[fIdx] = this[fIdx] + card }
        val next = when (sel) {
            is SolitaireSel.Waste -> state.copy(
                waste = state.waste.dropLast(1),
                foundations = newFoundations,
                score = state.score + 15
            )
            is SolitaireSel.Tableau -> {
                val newTab = state.tableau.toMutableList().apply {
                    this[sel.col] = flipTop(this[sel.col].dropLast(1))
                }
                state.copy(tableau = newTab, foundations = newFoundations, score = state.score + 15)
            }
        }
        pushState(next)
        SoundManager.playMatch()
        return true
    }

    fun tryMoveToTableau(targetCol: Int): Boolean {
        val sel = selection ?: return false
        val movingCards = when (sel) {
            is SolitaireSel.Waste -> state.waste.lastOrNull()?.let { listOf(it) } ?: emptyList()
            is SolitaireSel.Tableau -> {
                if (sel.col == targetCol) return false
                state.tableau[sel.col].drop(sel.index)
            }
        }
        if (movingCards.isEmpty() || !movingCards.first().faceUp) return false
        if (!canMoveToTableau(movingCards.first(), state.tableau[targetCol])) return false

        val newTab = state.tableau.toMutableList()
        newTab[targetCol] = newTab[targetCol] + movingCards
        val next = when (sel) {
            is SolitaireSel.Waste -> state.copy(
                waste = state.waste.dropLast(1),
                tableau = newTab,
                score = state.score + 5
            )
            is SolitaireSel.Tableau -> {
                newTab[sel.col] = flipTop(newTab[sel.col].dropLast(movingCards.size))
                state.copy(tableau = newTab, score = state.score + 5)
            }
        }
        pushState(next)
        SoundManager.playMove()
        return true
    }

    fun restart() {
        state = dealSolitaire()
        undoStack = emptyList()
        selection = null
        won = false
        isPaused = false
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; restart() },
        scoreText = "SCORE ${state.score}",
        bestScoreText = "DRAW $drawCount",
        gameOverTitle = if (won) "Solitaire Cleared!" else null,
        gameOverSubtitle = "Final Score: ${state.score}",
        isWin = won,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier
                .padding(10.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Top Row: Stock, Waste, Undo, 4 Foundations
            Row(
                modifier = Modifier.fillMaxWidth().widthIn(max = 460.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Stock
                SolitaireCardSlot(
                    label = if (state.stock.isNotEmpty()) "${state.stock.size}" else "↻",
                    isFaceUp = false,
                    isRed = false,
                    isSelected = false,
                    onClick = { drawFromStock() },
                    modifier = Modifier.weight(1f)
                )
                // Waste
                val topWaste = state.waste.lastOrNull()
                SolitaireCardSlot(
                    label = topWaste?.label ?: "",
                    isFaceUp = topWaste != null,
                    isRed = topWaste?.suit?.isRed == true,
                    isSelected = selection is SolitaireSel.Waste,
                    onClick = {
                        if (topWaste != null) {
                            selection = if (selection is SolitaireSel.Waste) null else SolitaireSel.Waste
                            SoundManager.playTap()
                        }
                    },
                    modifier = Modifier.weight(1f)
                )

                Button(
                    onClick = {
                        if (undoStack.isNotEmpty()) {
                            state = undoStack.last()
                            undoStack = undoStack.dropLast(1)
                            selection = null
                            SoundManager.playTap()
                        }
                    },
                    enabled = undoStack.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated, contentColor = TextPrimary),
                    modifier = Modifier.weight(1.1f).height(58.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
                ) {
                    Text("Undo", fontSize = 11.sp)
                }

                // 4 Foundations
                state.foundations.forEachIndexed { fIdx, pile ->
                    val top = pile.lastOrNull()
                    SolitaireCardSlot(
                        label = top?.label ?: "A",
                        isFaceUp = top != null,
                        isRed = top?.suit?.isRed == true,
                        isSelected = false,
                        isEmptyHint = top == null,
                        onClick = { tryMoveToFoundation(fIdx) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 7 Tableau Columns
            Row(
                modifier = Modifier.fillMaxWidth().widthIn(max = 460.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.Top
            ) {
                state.tableau.forEachIndexed { colIdx, pile ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(380.dp)
                            .clickable(enabled = pile.isEmpty()) { tryMoveToTableau(colIdx) }
                    ) {
                        if (pile.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(64.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, SurfaceBorder, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("K", color = SurfaceBorder, fontSize = 12.sp)
                            }
                        } else {
                            pile.forEachIndexed { cardIdx, card ->
                                val isSel = selection is SolitaireSel.Tableau &&
                                    (selection as SolitaireSel.Tableau).col == colIdx &&
                                    cardIdx >= (selection as SolitaireSel.Tableau).index
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .offset(y = (cardIdx * 24).dp)
                                        .height(66.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            when {
                                                !card.faceUp -> Color(0xFF065F46)
                                                isSel -> Color(0xFFFEF3C7)
                                                else -> Color(0xFFF8FAFC)
                                            }
                                        )
                                        .border(
                                            width = if (isSel) 2.dp else 1.dp,
                                            color = if (isSel) NeonAmber else if (card.faceUp) Color(0xFF94A3B8) else NeonEmerald,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable(enabled = card.faceUp) {
                                            if (selection == null) {
                                                selection = SolitaireSel.Tableau(colIdx, cardIdx)
                                                SoundManager.playTap()
                                            } else {
                                                val moved = tryMoveToTableau(colIdx)
                                                if (!moved) {
                                                    selection = SolitaireSel.Tableau(colIdx, cardIdx)
                                                    SoundManager.playTap()
                                                }
                                            }
                                        }
                                        .padding(4.dp)
                                ) {
                                    if (card.faceUp) {
                                        Text(
                                            text = card.label,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (card.suit.isRed) Color(0xFFDC2626) else Color(0xFF0F172A)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SolitaireCardSlot(
    label: String,
    isFaceUp: Boolean,
    isRed: Boolean,
    isSelected: Boolean,
    isEmptyHint: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(62.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
                when {
                    isEmptyHint -> SurfaceCard
                    !isFaceUp -> Color(0xFF065F46)
                    isSelected -> Color(0xFFFEF3C7)
                    else -> Color(0xFFF8FAFC)
                }
            )
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) NeonAmber else SurfaceBorder,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = when {
                isEmptyHint -> SurfaceBorder
                !isFaceUp -> NeonEmerald
                isRed -> Color(0xFFDC2626)
                else -> BgObsidian
            }
        )
    }
}
