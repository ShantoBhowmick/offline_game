package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

object SudokuGenerator {
    data class Puzzle(val board: List<Int>, val solution: List<Int>, val fixed: List<Boolean>)

    fun generate(difficulty: Difficulty): Puzzle {
        val solution = IntArray(81)
        fillGrid(solution, 0)
        val removeCount = when (difficulty) {
            Difficulty.EASY -> 34
            Difficulty.MEDIUM -> 45
            Difficulty.HARD -> 54
        }
        val puzzle = solution.copyOf()
        val indices = (0 until 81).shuffled()
        var removed = 0
        for (idx in indices) {
            if (removed >= removeCount) break
            puzzle[idx] = 0
            removed++
        }
        return Puzzle(
            board = puzzle.toList(),
            solution = solution.toList(),
            fixed = puzzle.map { it != 0 }
        )
    }

    private fun fillGrid(grid: IntArray, pos: Int): Boolean {
        if (pos == 81) return true
        val r = pos / 9
        val c = pos % 9
        val nums = (1..9).shuffled()
        for (n in nums) {
            if (isValid(grid, r, c, n)) {
                grid[pos] = n
                if (fillGrid(grid, pos + 1)) return true
                grid[pos] = 0
            }
        }
        return false
    }

    private fun isValid(grid: IntArray, r: Int, c: Int, num: Int): Boolean {
        for (i in 0..8) {
            if (grid[r * 9 + i] == num || grid[i * 9 + c] == num) return false
        }
        val br = (r / 3) * 3
        val bc = (c / 3) * 3
        for (dr in 0..2) {
            for (dc in 0..2) {
                if (grid[(br + dr) * 9 + (bc + dc)] == num) return false
            }
        }
        return true
    }
}

@Composable
fun SudokuScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var puzzle by remember { mutableStateOf(SudokuGenerator.generate(difficulty)) }
    var board by remember { mutableStateOf(puzzle.board) }
    var notes by remember { mutableStateOf(List(81) { emptySet<Int>() }) }
    var selectedIdx by remember { mutableIntStateOf(-1) }
    var notesMode by remember { mutableStateOf(false) }
    var mistakes by remember { mutableIntStateOf(0) }
    var elapsedSec by remember { mutableIntStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }
    var gameResult by remember { mutableIntStateOf(0) } // 0 playing, 1 won, -1 lost

    fun startNew(diff: Difficulty = difficulty) {
        val p = SudokuGenerator.generate(diff)
        puzzle = p
        board = p.board
        notes = List(81) { emptySet() }
        selectedIdx = -1
        mistakes = 0
        elapsedSec = 0
        gameResult = 0
        isPaused = false
    }

    LaunchedEffect(isPaused, gameResult) {
        while (!isPaused && gameResult == 0) {
            delay(1000)
            elapsedSec++
        }
    }

    fun enterDigit(digit: Int) {
        if (isPaused || gameResult != 0 || selectedIdx !in 0..80) return
        if (puzzle.fixed[selectedIdx]) return

        if (notesMode) {
            val cur = notes[selectedIdx]
            val nextNotes = notes.toMutableList()
            nextNotes[selectedIdx] = if (digit in cur) cur - digit else cur + digit
            notes = nextNotes
            SoundManager.playTap()
            return
        }

        val next = board.toMutableList()
        next[selectedIdx] = digit
        board = next

        if (digit != puzzle.solution[selectedIdx]) {
            mistakes++
            SoundManager.playError()
            if (mistakes >= 3) {
                gameResult = -1
                SoundManager.playLose()
                session.onRecordResult(0, false, true)
            }
        } else {
            val nextNotes = notes.toMutableList()
            nextNotes[selectedIdx] = emptySet()
            notes = nextNotes
            SoundManager.playMove()
            if (next.indices.all { next[it] == puzzle.solution[it] }) {
                gameResult = 1
                val score = ((1200 - elapsedSec * 2) * (if (difficulty == Difficulty.HARD) 2 else 1)).coerceAtLeast(200)
                SoundManager.playWin()
                session.onRecordResult(score, true, true)
            }
        }
    }

    fun useHint() {
        if (isPaused || gameResult != 0) return
        val target = if (selectedIdx in 0..80 && board[selectedIdx] != puzzle.solution[selectedIdx]) {
            selectedIdx
        } else {
            board.indices.firstOrNull { board[it] != puzzle.solution[it] } ?: return
        }
        val next = board.toMutableList()
        next[target] = puzzle.solution[target]
        board = next
        selectedIdx = target
        SoundManager.playMatch()
        if (next.indices.all { next[it] == puzzle.solution[it] }) {
            gameResult = 1
            SoundManager.playWin()
            session.onRecordResult(400, true, true)
        }
    }

    val selectedVal = if (selectedIdx in 0..80) board[selectedIdx] else 0

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { startNew() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = {
            difficulty = it
            startNew(it)
        },
        scoreText = "MISTAKES $mistakes/3",
        bestScoreText = "TIME ${elapsedSec}s",
        gameOverTitle = when (gameResult) {
            1 -> "Puzzle Solved!"
            -1 -> "3 Mistakes!"
            else -> null
        },
        gameOverSubtitle = if (gameResult == 1) "Completed in ${elapsedSec}s" else "Try again on a fresh Sudoku grid",
        isWin = gameResult == 1,
        onPlayAgain = { startNew() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // 9x9 Sudoku Grid
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 390.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(SurfaceCard)
                    .border(2.dp, Color(0xFF3B82F6), RoundedCornerShape(14.dp))
                    .padding(4.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    for (r in 0..8) {
                        val bottomThick = r == 2 || r == 5
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .padding(bottom = if (bottomThick) 2.5.dp else 0.5.dp)
                        ) {
                            for (c in 0..8) {
                                val rightThick = c == 2 || c == 5
                                val idx = r * 9 + c
                                val v = board[idx]
                                val isFixed = puzzle.fixed[idx]
                                val isSel = idx == selectedIdx
                                val isError = v != 0 && v != puzzle.solution[idx]
                                val sameRowColBox = selectedIdx >= 0 && (
                                    r == selectedIdx / 9 || c == selectedIdx % 9 ||
                                        ((r / 3) == ((selectedIdx / 9) / 3) && (c / 3) == ((selectedIdx % 9) / 3))
                                    )
                                val sameNum = selectedVal != 0 && v == selectedVal

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                        .padding(end = if (rightThick) 2.5.dp else 0.5.dp)
                                        .background(
                                            when {
                                                isSel -> NeonCyan.copy(alpha = 0.28f)
                                                isError -> NeonCoral.copy(alpha = 0.28f)
                                                sameNum -> NeonCyan.copy(alpha = 0.14f)
                                                sameRowColBox -> Color(0xFF1A2442)
                                                else -> Color(0xFF0E1426)
                                            }
                                        )
                                        .border(0.5.dp, SurfaceBorder)
                                        .clickable {
                                            selectedIdx = idx
                                            SoundManager.playTap()
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (v != 0) {
                                        Text(
                                            text = "$v",
                                            fontFamily = JetBrainsMonoFontFamily,
                                            fontWeight = if (isFixed) FontWeight.Bold else FontWeight.SemiBold,
                                            fontSize = 17.sp,
                                            color = when {
                                                isError -> NeonCoral
                                                isFixed -> TextPrimary
                                                else -> NeonCyan
                                            }
                                        )
                                    } else if (notes[idx].isNotEmpty()) {
                                        Text(
                                            text = notes[idx].sorted().joinToString(""),
                                            fontSize = 8.sp,
                                            lineHeight = 9.sp,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tools Row
            Row(
                modifier = Modifier.fillMaxWidth().widthIn(max = 390.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { notesMode = !notesMode; SoundManager.playTap() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (notesMode) NeonAmber else SurfaceElevated,
                        contentColor = if (notesMode) BgObsidian else TextPrimary
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null)
                    Spacer(Modifier.padding(start = 6.dp))
                    Text(if (notesMode) "Notes ON" else "Notes")
                }
                Button(
                    onClick = {
                        if (selectedIdx in 0..80 && !puzzle.fixed[selectedIdx]) {
                            val next = board.toMutableList()
                            next[selectedIdx] = 0
                            board = next
                            val nn = notes.toMutableList()
                            nn[selectedIdx] = emptySet()
                            notes = nn
                            SoundManager.playTap()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated, contentColor = TextPrimary),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Backspace, contentDescription = null)
                    Spacer(Modifier.padding(start = 6.dp))
                    Text("Erase")
                }
                Button(
                    onClick = { useHint() },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated, contentColor = NeonAmber),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Lightbulb, contentDescription = null)
                    Spacer(Modifier.padding(start = 6.dp))
                    Text("Hint")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 1..9 Number Pad
            Row(
                modifier = Modifier.fillMaxWidth().widthIn(max = 390.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                for (n in 1..9) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(SurfaceElevated)
                            .border(1.dp, SurfaceBorder, RoundedCornerShape(10.dp))
                            .clickable { enterDigit(n) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$n",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = NeonCyan
                        )
                    }
                }
            }
        }
    }
}
