package com.example.games

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.core.model.PlayerMode
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

object TicTacToeEngine {
    private val winLines = listOf(
        listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
        listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
        listOf(0, 4, 8), listOf(2, 4, 6)
    )

    fun checkWinner(board: List<Int>): Pair<Int, List<Int>?> {
        for (line in winLines) {
            val a = board[line[0]]
            if (a != 0 && a == board[line[1]] && a == board[line[2]]) {
                return a to line
            }
        }
        return if (board.none { it == 0 }) 3 to null else 0 to null
    }

    fun chooseAiMove(board: List<Int>, difficulty: Difficulty): Int {
        val empty = board.indices.filter { board[it] == 0 }
        if (empty.isEmpty()) return -1
        return when (difficulty) {
            Difficulty.EASY -> empty.random()
            Difficulty.MEDIUM -> {
                if (Math.random() < 0.55) bestMinimaxMove(board, 2) else empty.random()
            }
            Difficulty.HARD -> bestMinimaxMove(board, 2)
        }
    }

    private fun bestMinimaxMove(board: List<Int>, aiPlayer: Int): Int {
        var bestScore = Int.MIN_VALUE
        var move = -1
        val mutable = board.toMutableList()
        for (i in 0..8) {
            if (mutable[i] == 0) {
                mutable[i] = aiPlayer
                val score = minimax(mutable, 0, false, aiPlayer)
                mutable[i] = 0
                if (score > bestScore) {
                    bestScore = score
                    move = i
                }
            }
        }
        return move
    }

    private fun minimax(board: MutableList<Int>, depth: Int, isMax: Boolean, aiPlayer: Int): Int {
        val (winner, _) = checkWinner(board)
        if (winner == aiPlayer) return 10 - depth
        if (winner == 1) return depth - 10
        if (winner == 3) return 0

        var best = if (isMax) Int.MIN_VALUE else Int.MAX_VALUE
        for (i in 0..8) {
            if (board[i] == 0) {
                board[i] = if (isMax) aiPlayer else 1
                val score = minimax(board, depth + 1, !isMax, aiPlayer)
                board[i] = 0
                best = if (isMax) maxOf(best, score) else minOf(best, score)
            }
        }
        return best
    }
}

@Composable
fun TicTacToeScreen(session: GameSessionController) {
    var board by remember { mutableStateOf(List(9) { 0 }) }
    var currentTurn by remember { mutableIntStateOf(1) }
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var playerMode by remember { mutableStateOf(session.initialPlayerMode) }
    var isPaused by remember { mutableStateOf(false) }
    var xWins by remember { mutableIntStateOf(0) }
    var oWins by remember { mutableIntStateOf(0) }
    var draws by remember { mutableIntStateOf(0) }
    var winner by remember { mutableIntStateOf(0) } // 0 playing, 1 X, 2 O, 3 draw
    var winLine by remember { mutableStateOf<List<Int>?>(null) }

    fun resetRound() {
        board = List(9) { 0 }
        currentTurn = 1
        winner = 0
        winLine = null
    }

    // Restore saved board if present
    LaunchedEffect(Unit) {
        val saved = session.savedStateJson
        if (!saved.isNullOrBlank() && saved.length == 10) {
            val loaded = saved.take(9).map { it.digitToIntOrNull() ?: 0 }
            val turn = saved[9].digitToIntOrNull() ?: 1
            val (w, line) = TicTacToeEngine.checkWinner(loaded)
            if (w == 0) {
                board = loaded
                currentTurn = turn
                winner = 0
                winLine = line
            }
        }
    }

    fun applyMove(index: Int, player: Int) {
        if (board[index] != 0 || winner != 0) return
        val next = board.toMutableList().apply { this[index] = player }
        board = next
        val (w, line) = TicTacToeEngine.checkWinner(next)
        if (w != 0) {
            winner = w
            winLine = line
            when (w) {
                1 -> {
                    xWins++
                    SoundManager.playWin()
                    session.onRecordResult(xWins * 100, true, true)
                }
                2 -> {
                    oWins++
                    if (playerMode == PlayerMode.SINGLE_PLAYER) SoundManager.playLose() else SoundManager.playWin()
                    session.onRecordResult(xWins * 100, false, true)
                }
                else -> {
                    draws++
                    SoundManager.playBounce()
                    session.onRecordResult(xWins * 100, false, true)
                }
            }
        } else {
            SoundManager.playMove()
            val nextTurn = if (player == 1) 2 else 1
            currentTurn = nextTurn
            session.onSaveState(next.joinToString("") + nextTurn)
        }
    }

    // AI Turn
    LaunchedEffect(currentTurn, winner, playerMode, isPaused) {
        if (!isPaused && winner == 0 && playerMode == PlayerMode.SINGLE_PLAYER && currentTurn == 2) {
            delay(360)
            val aiIdx = TicTacToeEngine.chooseAiMove(board, difficulty)
            if (aiIdx >= 0) applyMove(aiIdx, 2)
        }
    }

    val overTitle = when (winner) {
        1 -> if (playerMode == PlayerMode.SINGLE_PLAYER) "You Win!" else "Player X Wins!"
        2 -> if (playerMode == PlayerMode.SINGLE_PLAYER) "AI Wins!" else "Player O Wins!"
        3 -> "It's a Draw!"
        else -> null
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = {
            if (winner == 0 && board.any { it != 0 }) {
                session.onSaveState(board.joinToString("") + currentTurn)
            }
            session.onExit()
        },
        onRestart = { resetRound() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = {
            difficulty = it
            resetRound()
        },
        playerMode = playerMode,
        onPlayerModeChange = {
            playerMode = it
            xWins = 0; oWins = 0; draws = 0
            resetRound()
        },
        scoreText = "X:$xWins  O:$oWins  D:$draws",
        bestScoreText = "BEST ${session.bestScore}",
        gameOverTitle = overTitle,
        gameOverSubtitle = "Scoreboard: X $xWins • Draws $draws • O $oWins",
        isWin = winner == 1 || (winner == 2 && playerMode == PlayerMode.LOCAL_MULTIPLAYER),
        onPlayAgain = { resetRound() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Turn Indicator Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PlayerBadge(
                    label = if (playerMode == PlayerMode.SINGLE_PLAYER) "YOU (X)" else "PLAYER X",
                    score = xWins,
                    active = winner == 0 && currentTurn == 1,
                    color = NeonCyan,
                    modifier = Modifier.weight(1f)
                )
                PlayerBadge(
                    label = if (playerMode == PlayerMode.SINGLE_PLAYER) "AI (O)" else "PLAYER O",
                    score = oWins,
                    active = winner == 0 && currentTurn == 2,
                    color = NeonMagenta,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // 3x3 Neon Board
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 360.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(SurfaceCard)
                    .border(1.5.dp, SurfaceBorder, RoundedCornerShape(24.dp))
                    .padding(14.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    for (r in 0..2) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            for (c in 0..2) {
                                val idx = r * 3 + c
                                val mark = board[idx]
                                val isWinCell = winLine?.contains(idx) == true
                                val scale by animateFloatAsState(
                                    targetValue = if (mark != 0) 1f else 0f,
                                    animationSpec = tween(200),
                                    label = "markScale"
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(
                                            if (isWinCell) NeonEmerald.copy(alpha = 0.22f)
                                            else Color(0xFF0E1425)
                                        )
                                        .border(
                                            1.dp,
                                            if (isWinCell) NeonEmerald else SurfaceBorder,
                                            RoundedCornerShape(16.dp)
                                        )
                                        .clickable(
                                            enabled = !isPaused && winner == 0 && mark == 0 &&
                                                (playerMode == PlayerMode.LOCAL_MULTIPLAYER || currentTurn == 1)
                                        ) {
                                            applyMove(idx, currentTurn)
                                        }
                                        .testTag("ttt_cell_$idx"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (mark != 0) {
                                        Canvas(modifier = Modifier.fillMaxSize().padding(20.dp)) {
                                            val w = size.width * scale
                                            val h = size.height * scale
                                            val ox = (size.width - w) / 2f
                                            val oy = (size.height - h) / 2f
                                            if (mark == 1) {
                                                drawLine(
                                                    NeonCyan,
                                                    Offset(ox, oy),
                                                    Offset(ox + w, oy + h),
                                                    strokeWidth = 12f,
                                                    cap = StrokeCap.Round
                                                )
                                                drawLine(
                                                    NeonCyan,
                                                    Offset(ox + w, oy),
                                                    Offset(ox, oy + h),
                                                    strokeWidth = 12f,
                                                    cap = StrokeCap.Round
                                                )
                                            } else {
                                                drawCircle(
                                                    color = NeonMagenta,
                                                    radius = minOf(w, h) / 2f,
                                                    style = Stroke(width = 12f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = when {
                    winner != 0 -> "Round Complete"
                    playerMode == PlayerMode.SINGLE_PLAYER && currentTurn == 2 -> "AI is thinking..."
                    currentTurn == 1 -> "X's Turn — Tap any square"
                    else -> "O's Turn — Tap any square"
                },
                style = MaterialTheme.typography.titleMedium,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun PlayerBadge(
    label: String,
    score: Int,
    active: Boolean,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (active) color.copy(alpha = 0.14f) else SurfaceCard)
            .border(
                width = if (active) 1.5.dp else 1.dp,
                color = if (active) color else SurfaceBorder,
                shape = RoundedCornerShape(16.dp)
            )
            .padding(vertical = 12.dp, horizontal = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (active) color else TextSecondary
        )
        Text(
            text = "$score",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
    }
}
