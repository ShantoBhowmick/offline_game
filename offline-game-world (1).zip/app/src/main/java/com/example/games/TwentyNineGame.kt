package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

private enum class Suit29(val symbol: String, val isRed: Boolean, val label: String) {
    SPADES("♠", false, "Spades"),
    HEARTS("♥", true, "Hearts"),
    CLUBS("♣", false, "Clubs"),
    DIAMONDS("♦", true, "Diamonds")
}

private enum class Rank29(val label: String, val power: Int, val points: Int) {
    SEVEN("7", 1, 0),
    EIGHT("8", 2, 0),
    QUEEN("Q", 3, 0),
    KING("K", 4, 0),
    TEN("10", 5, 1),
    ACE("A", 6, 1),
    NINE("9", 7, 2),
    JACK("J", 8, 3)
}

private data class Card29(val suit: Suit29, val rank: Rank29) {
    val shortLabel: String get() = "${rank.label}${suit.symbol}"
}

private enum class Phase29 { BIDDING, CHOOSE_TRUMP, PLAYING, ROUND_OVER }

@Composable
fun TwentyNineScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    val seatNames = listOf("You (S)", "West AI", "North Partner", "East AI")

    fun dealHands(): List<List<Card29>> {
        val deck = Suit29.entries.flatMap { s -> Rank29.entries.map { r -> Card29(s, r) } }.shuffled()
        return listOf(
            deck.subList(0, 8).sortedWith(compareBy({ it.suit.ordinal }, { -it.rank.power })),
            deck.subList(8, 16),
            deck.subList(16, 24),
            deck.subList(24, 32)
        )
    }

    var hands by remember { mutableStateOf(dealHands()) }
    var phase by remember { mutableStateOf(Phase29.BIDDING) }
    var currentBid by remember { mutableIntStateOf(16) }
    var highestBidder by remember { mutableIntStateOf(0) }
    var bidderPassed by remember { mutableStateOf(List(4) { false }) }
    var bidTurn by remember { mutableIntStateOf(0) }

    var trumpSuit by remember { mutableStateOf<Suit29?>(null) }
    var trumpRevealed by remember { mutableStateOf(false) }

    var trickCards by remember { mutableStateOf<List<Pair<Int, Card29>>>(emptyList()) }
    var playTurn by remember { mutableIntStateOf(0) }
    var trickNumber by remember { mutableIntStateOf(1) }
    var teamYourPts by remember { mutableIntStateOf(0) }
    var teamOppPts by remember { mutableIntStateOf(0) }
    var matchScore by remember { mutableIntStateOf(0) }
    var statusMsg by remember { mutableStateOf("Place your bid (16 - 28) or Pass") }
    var isPaused by remember { mutableStateOf(false) }

    fun restart() {
        hands = dealHands()
        phase = Phase29.BIDDING
        currentBid = 15
        highestBidder = -1
        bidderPassed = List(4) { false }
        bidTurn = 0
        trumpSuit = null
        trumpRevealed = false
        trickCards = emptyList()
        playTurn = 0
        trickNumber = 1
        teamYourPts = 0
        teamOppPts = 0
        statusMsg = "Bidding Phase: Bid 16+ or Pass"
        isPaused = false
    }

    LaunchedEffect(Unit) { restart() }

    fun advanceBidTurn(passedList: List<Boolean>, curBidder: Int, bidVal: Int) {
        val activeCount = passedList.count { !it }
        if (activeCount <= 1 && curBidder >= 0) {
            highestBidder = curBidder
            currentBid = bidVal.coerceAtLeast(16)
            if (curBidder == 0) {
                phase = Phase29.CHOOSE_TRUMP
                statusMsg = "You won the bid ($currentBid)! Pick the hidden Trump suit"
            } else {
                // AI picks strongest suit
                val aiHand = hands[curBidder]
                trumpSuit = Suit29.entries.maxByOrNull { s ->
                    aiHand.filter { it.suit == s }.sumOf { it.rank.points + 1 }
                } ?: Suit29.SPADES
                phase = Phase29.PLAYING
                playTurn = 0
                statusMsg = "${seatNames[curBidder]} won bid ($currentBid). Lead a card!"
            }
            return
        }
        if (passedList.all { it }) {
            // Forced 16 on South
            highestBidder = 0
            currentBid = 16
            phase = Phase29.CHOOSE_TRUMP
            statusMsg = "All passed — You bid 16. Choose Trump suit!"
            return
        }
        var next = (bidTurn + 1) % 4
        while (passedList[next]) next = (next + 1) % 4
        bidTurn = next
    }

    fun submitBid(amount: Int?) {
        if (phase != Phase29.BIDDING || bidTurn != 0) return
        if (amount == null) {
            val nextPass = bidderPassed.toMutableList().apply { this[0] = true }
            bidderPassed = nextPass
            SoundManager.playTap()
            advanceBidTurn(nextPass, highestBidder, currentBid)
        } else if (amount > currentBid && amount in 16..28) {
            currentBid = amount
            highestBidder = 0
            SoundManager.playMove()
            advanceBidTurn(bidderPassed, 0, amount)
        }
    }

    // AI Bidding
    LaunchedEffect(phase, bidTurn, isPaused) {
        if (!isPaused && phase == Phase29.BIDDING && bidTurn != 0) {
            delay(450)
            val hand = hands[bidTurn]
            val strength = 15 + hand.sumOf { it.rank.points } / 2
            val maxWilling = strength.coerceIn(16, 23)
            if (currentBid < maxWilling && Math.random() < 0.72) {
                val nextBid = maxOf(16, currentBid + 1)
                currentBid = nextBid
                highestBidder = bidTurn
                statusMsg = "${seatNames[bidTurn]} bids $nextBid"
                SoundManager.playTap()
                advanceBidTurn(bidderPassed, bidTurn, nextBid)
            } else {
                val nextPass = bidderPassed.toMutableList().apply { this[bidTurn] = true }
                bidderPassed = nextPass
                statusMsg = "${seatNames[bidTurn]} passes"
                advanceBidTurn(nextPass, highestBidder, currentBid)
            }
        }
    }

    fun legalCardsForSeat(seat: Int): List<Card29> {
        val h = hands[seat]
        if (trickCards.isEmpty()) return h
        val ledSuit = trickCards.first().second.suit
        val matching = h.filter { it.suit == ledSuit }
        return if (matching.isNotEmpty()) matching else h
    }

    fun trickWinner(cards: List<Pair<Int, Card29>>): Int {
        val ledSuit = cards.first().second.suit
        val trump = if (trumpRevealed) trumpSuit else null
        val trumpPlays = if (trump != null) cards.filter { it.second.suit == trump } else emptyList()
        return if (trumpPlays.isNotEmpty()) {
            trumpPlays.maxBy { it.second.rank.power }.first
        } else {
            cards.filter { it.second.suit == ledSuit }.maxBy { it.second.rank.power }.first
        }
    }

    fun playCard(seat: Int, card: Card29) {
        if (phase != Phase29.PLAYING || seat != playTurn || isPaused) return
        val nextHands = hands.toMutableList().apply { this[seat] = this[seat] - card }
        hands = nextHands
        val nextTrick = trickCards + (seat to card)
        trickCards = nextTrick
        SoundManager.playMove()

        if (nextTrick.size < 4) {
            playTurn = (seat + 1) % 4
        } else {
            // Resolve trick
            val winSeat = trickWinner(nextTrick)
            val pts = nextTrick.sumOf { it.second.rank.points } + if (trickNumber == 8) 1 else 0
            if (winSeat == 0 || winSeat == 2) teamYourPts += pts else teamOppPts += pts
            statusMsg = "${seatNames[winSeat]} won Trick $trickNumber (+$pts pts)"
            SoundManager.playMatch()
            if (trickNumber >= 8) {
                phase = Phase29.ROUND_OVER
                val bidTeamIsYours = highestBidder == 0 || highestBidder == 2
                val roundWon = if (bidTeamIsYours) teamYourPts >= currentBid else teamOppPts < currentBid
                if (roundWon) {
                    matchScore += 200 + teamYourPts * 10
                    SoundManager.playWin()
                } else {
                    SoundManager.playLose()
                }
                session.onRecordResult(matchScore, roundWon, true)
            } else {
                trickNumber++
                trickCards = emptyList()
                playTurn = winSeat
            }
        }
    }

    // AI Card Play
    LaunchedEffect(phase, playTurn, trickCards, isPaused) {
        if (!isPaused && phase == Phase29.PLAYING && playTurn != 0 && trickCards.size < 4) {
            delay(500)
            val legal = legalCardsForSeat(playTurn)
            if (legal.isNotEmpty()) {
                val ledSuit = trickCards.firstOrNull()?.second?.suit
                if (!trumpRevealed && ledSuit != null && legal.none { it.suit == ledSuit }) {
                    if (trumpSuit != null && legal.any { it.suit == trumpSuit }) {
                        trumpRevealed = true
                        statusMsg = "${seatNames[playTurn]} revealed Trump (${trumpSuit!!.symbol})!"
                    }
                }
                val pick = if (difficulty == Difficulty.EASY) {
                    legal.random()
                } else {
                    // Tactical: try to win valuable tricks or dump 0-pt low cards
                    legal.maxByOrNull { c ->
                        val isTrump = trumpRevealed && c.suit == trumpSuit
                        (if (isTrump) 20 else 0) + c.rank.power + c.rank.points * 2
                    } ?: legal.first()
                }
                playCard(playTurn, pick)
            }
        }
    }

    val bidTeamIsYours = highestBidder == 0 || highestBidder == 2
    val roundWon = if (bidTeamIsYours) teamYourPts >= currentBid else teamOppPts < currentBid

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = { difficulty = it; restart() },
        scoreText = "YOU+N: $teamYourPts  E+W: $teamOppPts",
        bestScoreText = if (highestBidder >= 0) "BID $currentBid" else "TRICK $trickNumber/8",
        gameOverTitle = if (phase == Phase29.ROUND_OVER) {
            if (roundWon) "Round Won!" else "Contract Failed"
        } else null,
        gameOverSubtitle = "Your Team: $teamYourPts pts • Opponents: $teamOppPts pts (Bid: $currentBid)",
        isWin = roundWon,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Table Felt Area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 420.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xFF0A2E25))
                    .border(2.dp, NeonEmerald.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "North Partner (${hands[2].size})",
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonCyan
                    )
                    Text(
                        text = when {
                            trumpRevealed && trumpSuit != null -> "TRUMP: ${trumpSuit!!.symbol} ${trumpSuit!!.label}"
                            trumpSuit != null -> "TRUMP: HIDDEN"
                            else -> "NO TRUMP YET"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonAmber
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("West AI (${hands[1].size})", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Text("East AI (${hands[3].size})", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                }

                // Trick Center Cards
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(86.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (trickCards.isEmpty()) {
                        Text(statusMsg, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    } else {
                        trickCards.forEach { (seat, card) ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(seatNames[seat].take(5), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Box(
                                    modifier = Modifier
                                        .size(width = 52.dp, height = 66.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFF8FAFC))
                                        .border(1.dp, NeonCyan, RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = card.shortLabel,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 16.sp,
                                        color = if (card.suit.isRed) Color(0xFFDC2626) else BgObsidian
                                    )
                                }
                            }
                        }
                    }
                }

                Text(
                    text = statusMsg,
                    style = MaterialTheme.typography.bodySmall,
                    color = NeonAmber
                )
            }

            // Phase Action Controls
            when (phase) {
                Phase29.BIDDING -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (bidTurn == 0) "Your Turn to Bid (Current: ${maxOf(15, currentBid)})" else "${seatNames[bidTurn]} bidding...",
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val next1 = maxOf(16, currentBid + 1)
                            val next2 = maxOf(17, currentBid + 2)
                            Button(
                                onClick = { submitBid(next1) },
                                enabled = bidTurn == 0 && next1 <= 28,
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = BgObsidian)
                            ) { Text("Bid $next1") }
                            Button(
                                onClick = { submitBid(next2) },
                                enabled = bidTurn == 0 && next2 <= 28,
                                colors = ButtonDefaults.buttonColors(containerColor = NeonAmber, contentColor = BgObsidian)
                            ) { Text("Bid $next2") }
                            Button(
                                onClick = { submitBid(null) },
                                enabled = bidTurn == 0,
                                colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated, contentColor = NeonCoral)
                            ) { Text("Pass") }
                        }
                    }
                }
                Phase29.CHOOSE_TRUMP -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Select Hidden Trump Suit", style = MaterialTheme.typography.titleSmall, color = NeonAmber)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Suit29.entries.forEach { s ->
                                Button(
                                    onClick = {
                                        trumpSuit = s
                                        phase = Phase29.PLAYING
                                        playTurn = 0
                                        statusMsg = "Trump hidden! Lead your first card."
                                        SoundManager.playTap()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated, contentColor = if (s.isRed) NeonCoral else TextPrimary)
                                ) {
                                    Text("${s.symbol} ${s.label}", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
                Phase29.PLAYING, Phase29.ROUND_OVER -> {
                    val yourLegal = if (playTurn == 0 && phase == Phase29.PLAYING) legalCardsForSeat(0) else emptyList()
                    val ledSuit = trickCards.firstOrNull()?.second?.suit
                    val canRevealTrump = !trumpRevealed && playTurn == 0 && ledSuit != null && hands[0].none { it.suit == ledSuit }

                    if (canRevealTrump) {
                        Button(
                            onClick = {
                                trumpRevealed = true
                                SoundManager.playMatch()
                                statusMsg = "Trump Revealed: ${trumpSuit?.symbol} ${trumpSuit?.label}"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonAmber, contentColor = BgObsidian)
                        ) {
                            Text("Reveal Hidden Trump")
                        }
                    }

                    // Player Hand
                    Row(
                        modifier = Modifier.fillMaxWidth().widthIn(max = 440.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally)
                    ) {
                        hands[0].forEach { card ->
                            val playable = playTurn == 0 && phase == Phase29.PLAYING && card in yourLegal
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(74.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (playable) Color(0xFFF8FAFC) else Color(0xFF94A3B8))
                                    .border(
                                        width = if (playable) 2.dp else 1.dp,
                                        color = if (playable) NeonCyan else SurfaceBorder,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable(enabled = playable) { playCard(0, card) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = card.rank.label,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 15.sp,
                                        color = if (card.suit.isRed) Color(0xFFDC2626) else BgObsidian
                                    )
                                    Text(
                                        text = card.suit.symbol,
                                        fontSize = 16.sp,
                                        color = if (card.suit.isRed) Color(0xFFDC2626) else BgObsidian
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
