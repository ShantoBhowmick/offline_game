package com.example.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.ui.components.GameScaffold
import com.example.ui.components.GameSessionController
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private object WordBank {
    val words4 = listOf(
        "GAME", "PLAY", "STAR", "MOON", "FIRE", "GOLD", "MIND", "WAVE", "HERO", "KING",
        "CARD", "DICE", "GRID", "TIME", "ZONE", "JUMP", "FAST", "CUBE", "NEON", "CODE",
        "LOCK", "HINT", "WINN", "WIND", "TREE", "BOOK", "SHIP", "LION", "BEAR", "FROG"
    ).filter { it.length == 4 }.distinct()

    val words5 = listOf(
        "AUDIO", "BRAIN", "CHESS", "CROWN", "DANCE", "EAGLE", "FLAME", "GHOST", "HEART", "INDEX",
        "JOKER", "KNIGHT", "LASER", "MAGIC", "NOBLE", "OCEAN", "PRIZE", "QUEST", "RIVER", "SMART",
        "TIGER", "UNITY", "VIVID", "WORLD", "XENON", "YOUTH", "ZEBRA", "SCORE", "POWER", "LEVEL",
        "BLOCK", "MATCH", "STONE", "SWIFT", "PULSE", "STORM", "SPARK", "TRACK", "BOARD", "SKILL",
        "APPLE", "GRAPE", "MANGO", "MELON", "PEACH", "BERRY", "LEMON", "CHILI", "PIZZA", "CANDY"
    ).filter { it.length == 5 }.distinct()

    val words6 = listOf(
        "ARCADE", "BINARY", "CASTLE", "DRAGON", "EMPIRE", "FALCON", "GALAXY", "HUNTER", "ISLAND", "JUNGLE",
        "KNIGHT", "LEGEND", "MATRIX", "NEBULA", "ORACLE", "PLANET", "PUZZLE", "QUARTZ", "ROCKET", "SILVER",
        "TARGET", "VECTOR", "WONDER", "ZENITH", "SHIELD", "BRIDGE", "MASTER", "PLAYER", "TROPHY", "VICTOR"
    ).filter { it.length == 6 }.distinct()

    fun randomWord(diff: Difficulty): String = when (diff) {
        Difficulty.EASY -> words4.random()
        Difficulty.MEDIUM -> words5.random()
        Difficulty.HARD -> words6.random()
    }
}

private enum class LetterMatch { NONE, ABSENT, PRESENT, CORRECT }

@Composable
fun WordPuzzleScreen(session: GameSessionController) {
    var difficulty by remember { mutableStateOf(session.initialDifficulty) }
    var target by remember { mutableStateOf(WordBank.randomWord(difficulty)) }
    val wordLen = target.length
    val maxAttempts = 6
    var guesses by remember { mutableStateOf(emptyList<String>()) }
    var currentGuess by remember { mutableStateOf("") }
    var hintMessage by remember { mutableStateOf<String?>(null) }
    var streak by remember { mutableIntStateOf(0) }
    var isPaused by remember { mutableStateOf(false) }
    var status by remember { mutableIntStateOf(0) } // 0 playing, 1 won, -1 lost

    fun restart(diff: Difficulty = difficulty) {
        target = WordBank.randomWord(diff)
        guesses = emptyList()
        currentGuess = ""
        hintMessage = null
        status = 0
        isPaused = false
    }

    fun evaluateGuess(guess: String): List<LetterMatch> {
        val result = MutableList(wordLen) { LetterMatch.ABSENT }
        val targetChars = target.toMutableList()
        for (i in 0 until wordLen) {
            if (guess[i] == targetChars[i]) {
                result[i] = LetterMatch.CORRECT
                targetChars[i] = '*'
            }
        }
        for (i in 0 until wordLen) {
            if (result[i] == LetterMatch.ABSENT) {
                val idx = targetChars.indexOf(guess[i])
                if (idx >= 0) {
                    result[i] = LetterMatch.PRESENT
                    targetChars[idx] = '*'
                }
            }
        }
        return result
    }

    fun submitGuess() {
        if (isPaused || status != 0 || currentGuess.length != wordLen) return
        val next = guesses + currentGuess
        guesses = next
        if (currentGuess == target) {
            status = 1
            streak++
            val score = (maxAttempts - next.size + 1) * 150 + streak * 50
            SoundManager.playWin()
            session.onRecordResult(score, true, true)
        } else if (next.size >= maxAttempts) {
            status = -1
            streak = 0
            SoundManager.playLose()
            session.onRecordResult(0, false, true)
        } else {
            SoundManager.playMove()
        }
        currentGuess = ""
    }

    // Build keyboard color map
    val keyStates = remember(guesses, target) {
        val map = mutableMapOf<Char, LetterMatch>()
        guesses.forEach { g ->
            val eval = evaluateGuess(g)
            g.forEachIndexed { i, ch ->
                val prev = map[ch] ?: LetterMatch.NONE
                val next = eval[i]
                if (next.ordinal > prev.ordinal) map[ch] = next
            }
        }
        map
    }

    GameScaffold(
        game = session.game,
        isMuted = session.isMuted,
        onToggleMute = session.onToggleMute,
        onBack = { session.onExit() },
        onRestart = { restart() },
        isPaused = isPaused,
        onPauseChange = { isPaused = it },
        difficulty = difficulty,
        onDifficultyChange = {
            difficulty = it
            restart(it)
        },
        scoreText = "STREAK $streak",
        bestScoreText = "${wordLen}-LETTER",
        gameOverTitle = when (status) {
            1 -> "Word Cracked!"
            -1 -> "Out of Tries!"
            else -> null
        },
        gameOverSubtitle = "The word was $target",
        isWin = status == 1,
        onPlayAgain = { restart() }
    ) { modifier ->
        Column(
            modifier = modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (row in 0 until maxAttempts) {
                    val word = when {
                        row < guesses.size -> guesses[row]
                        row == guesses.size -> currentGuess
                        else -> ""
                    }
                    val eval = if (row < guesses.size) evaluateGuess(word) else null
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (col in 0 until wordLen) {
                            val ch = word.getOrNull(col)?.toString() ?: ""
                            val bg = when (eval?.getOrNull(col)) {
                                LetterMatch.CORRECT -> NeonEmerald
                                LetterMatch.PRESENT -> NeonAmber
                                LetterMatch.ABSENT -> Color(0xFF334155)
                                else -> SurfaceCard
                            }
                            Box(
                                modifier = Modifier
                                    .size(if (wordLen == 6) 44.dp else 50.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(bg)
                                    .border(
                                        1.5.dp,
                                        if (ch.isNotEmpty() && eval == null) NeonCyan else SurfaceBorder,
                                        RoundedCornerShape(10.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = ch,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 20.sp,
                                    color = if (eval != null && eval[col] != LetterMatch.ABSENT) BgObsidian else TextPrimary
                                )
                            }
                        }
                    }
                }

                if (hintMessage != null) {
                    Text(
                        text = hintMessage!!,
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonAmber
                    )
                }
            }

            // Hint + Keyboard
            Column(
                modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val pos = (0 until wordLen).random()
                            hintMessage = "Hint: Letter #${pos + 1} is '${target[pos]}'"
                            SoundManager.playTap()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated, contentColor = NeonAmber),
                        modifier = Modifier.height(38.dp)
                    ) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.padding(start = 6.dp))
                        Text("Hint")
                    }
                    Button(
                        onClick = { submitGuess() },
                        enabled = currentGuess.length == wordLen && status == 0,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = BgObsidian),
                        modifier = Modifier.height(38.dp)
                    ) {
                        Text("SUBMIT", fontWeight = FontWeight.Bold)
                    }
                }

                val rows = listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
                rows.forEachIndexed { rIdx, rowKeys ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        rowKeys.forEach { ch ->
                            val bg = when (keyStates[ch]) {
                                LetterMatch.CORRECT -> NeonEmerald
                                LetterMatch.PRESENT -> NeonAmber
                                LetterMatch.ABSENT -> Color(0xFF1E293B)
                                else -> SurfaceElevated
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(bg)
                                    .clickable {
                                        if (status == 0 && !isPaused && currentGuess.length < wordLen) {
                                            currentGuess += ch
                                            SoundManager.playTap()
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = ch.toString(),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (keyStates[ch] == LetterMatch.CORRECT || keyStates[ch] == LetterMatch.PRESENT) BgObsidian else TextPrimary
                                )
                            }
                        }
                        if (rIdx == 2) {
                            Box(
                                modifier = Modifier
                                    .weight(1.4f)
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SurfaceCard)
                                    .border(1.dp, SurfaceBorder, RoundedCornerShape(8.dp))
                                    .clickable {
                                        if (currentGuess.isNotEmpty() && status == 0) {
                                            currentGuess = currentGuess.dropLast(1)
                                            SoundManager.playTap()
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = "Backspace", tint = TextSecondary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
