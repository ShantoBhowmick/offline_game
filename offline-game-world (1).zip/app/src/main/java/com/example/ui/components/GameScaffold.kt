package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.audio.SoundManager
import com.example.core.model.Difficulty
import com.example.core.model.GameInfo
import com.example.core.model.PlayerMode
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GameScaffold(
    game: GameInfo,
    isMuted: Boolean,
    onToggleMute: () -> Unit,
    onBack: () -> Unit,
    onRestart: () -> Unit,
    isPaused: Boolean = false,
    onPauseChange: ((Boolean) -> Unit)? = null,
    difficulty: Difficulty = Difficulty.MEDIUM,
    onDifficultyChange: ((Difficulty) -> Unit)? = null,
    playerMode: PlayerMode = PlayerMode.SINGLE_PLAYER,
    onPlayerModeChange: ((PlayerMode) -> Unit)? = null,
    scoreText: String? = null,
    bestScoreText: String? = null,
    gameOverTitle: String? = null,
    gameOverSubtitle: String? = null,
    isWin: Boolean = false,
    onPlayAgain: (() -> Unit)? = null,
    content: @Composable (Modifier) -> Unit
) {
    var showInstructions by remember { mutableStateOf(false) }

    BackHandler {
        if (showInstructions) {
            showInstructions = false
        } else if (isPaused && onPauseChange != null) {
            onPauseChange(false)
        } else {
            onBack()
        }
    }

    Scaffold(
        containerColor = BgObsidian,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF0E1426), BgObsidian)
                        )
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            SoundManager.playTap()
                            onBack()
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("game_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Game Hub",
                            tint = TextPrimary
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp)
                    ) {
                        Text(
                            text = game.title,
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (scoreText != null || bestScoreText != null) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                if (scoreText != null) {
                                    Text(
                                        text = scoreText,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = game.accentStart
                                    )
                                }
                                if (bestScoreText != null) {
                                    Text(
                                        text = bestScoreText,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }

                    IconButton(
                        onClick = {
                            SoundManager.playTap()
                            showInstructions = true
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("game_help_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.HelpOutline,
                            contentDescription = "How to Play",
                            tint = TextSecondary
                        )
                    }

                    IconButton(
                        onClick = {
                            onToggleMute()
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("game_mute_button")
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = if (isMuted) "Unmute Sound" else "Mute Sound",
                            tint = if (isMuted) TextSecondary else NeonCyan
                        )
                    }

                    if (onPauseChange != null) {
                        IconButton(
                            onClick = {
                                SoundManager.playTap()
                                onPauseChange(!isPaused)
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("game_pause_button")
                        ) {
                            Icon(
                                imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                contentDescription = if (isPaused) "Resume" else "Pause",
                                tint = TextPrimary
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            SoundManager.playTap()
                            onRestart()
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("game_restart_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Restart Game",
                            tint = TextPrimary
                        )
                    }
                }

                if (onDifficultyChange != null || onPlayerModeChange != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (onPlayerModeChange != null) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(SurfaceCard)
                                    .border(1.dp, SurfaceBorder, RoundedCornerShape(10.dp))
                                    .padding(3.dp),
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                PlayerMode.entries.forEach { mode ->
                                    val selected = mode == playerMode
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (selected) game.accentStart else Color.Transparent)
                                            .clickable {
                                                SoundManager.playTap()
                                                onPlayerModeChange(mode)
                                            }
                                            .padding(horizontal = 10.dp, vertical = 5.dp)
                                    ) {
                                        Text(
                                            text = mode.label,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (selected) BgObsidian else TextSecondary
                                        )
                                    }
                                }
                            }
                        }

                        if (onDifficultyChange != null) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(SurfaceCard)
                                    .border(1.dp, SurfaceBorder, RoundedCornerShape(10.dp))
                                    .padding(3.dp),
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Difficulty.entries.forEach { diff ->
                                    val selected = diff == difficulty
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (selected) SurfaceElevated else Color.Transparent)
                                            .border(
                                                width = if (selected) 1.dp else 0.dp,
                                                color = if (selected) game.accentStart else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable {
                                                SoundManager.playTap()
                                                onDifficultyChange(diff)
                                            }
                                            .padding(horizontal = 9.dp, vertical = 5.dp)
                                    ) {
                                        Text(
                                            text = diff.label,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (selected) game.accentStart else TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            content(
                Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
            )

            // Pause Overlay
            AnimatedVisibility(
                visible = isPaused && gameOverTitle == null,
                enter = fadeIn() + scaleIn(initialScale = 0.94f),
                exit = fadeOut() + scaleOut(targetScale = 0.94f)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.78f)),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        color = SurfaceCard,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .padding(24.dp)
                            .widthIn(max = 360.dp)
                            .border(1.dp, SurfaceBorder, RoundedCornerShape(24.dp))
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Game Paused",
                                style = MaterialTheme.typography.headlineSmall,
                                color = TextPrimary
                            )
                            Text(
                                text = game.title,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Button(
                                onClick = {
                                    SoundManager.playTap()
                                    onPauseChange?.invoke(false)
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = game.accentStart, contentColor = BgObsidian)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Resume Game", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = {
                                    SoundManager.playTap()
                                    onPauseChange?.invoke(false)
                                    onRestart()
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Restart")
                            }
                            TextButton(
                                onClick = {
                                    SoundManager.playTap()
                                    onBack()
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.Home, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Back to Hub")
                            }
                        }
                    }
                }
            }

            // Game Over / Victory Overlay
            AnimatedVisibility(
                visible = gameOverTitle != null,
                enter = fadeIn() + scaleIn(initialScale = 0.92f),
                exit = fadeOut() + scaleOut(targetScale = 0.92f)
            ) {
                if (gameOverTitle != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.78f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            color = SurfaceCard,
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .padding(24.dp)
                                .widthIn(max = 360.dp)
                                .border(
                                    1.5.dp,
                                    if (isWin) NeonAmber else SurfaceBorder,
                                    RoundedCornerShape(24.dp)
                                )
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(
                                            (if (isWin) NeonAmber else game.accentStart).copy(alpha = 0.16f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = if (isWin) NeonAmber else game.accentStart,
                                        modifier = Modifier.size(34.dp)
                                    )
                                }
                                Text(
                                    text = gameOverTitle,
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = TextPrimary
                                )
                                if (gameOverSubtitle != null) {
                                    Text(
                                        text = gameOverSubtitle,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Button(
                                    onClick = {
                                        SoundManager.playTap()
                                        (onPlayAgain ?: onRestart)()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("play_again_button"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = game.accentStart,
                                        contentColor = BgObsidian
                                    )
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Play Again", fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = {
                                        SoundManager.playTap()
                                        onBack()
                                    },
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Icon(Icons.Default.Home, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Back to Hub")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showInstructions) {
        AlertDialog(
            onDismissRequest = { showInstructions = false },
            containerColor = SurfaceCard,
            title = {
                Text(
                    text = "How to Play: ${game.title}",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    game.instructions.forEachIndexed { idx, step ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(game.accentStart.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${idx + 1}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = game.accentStart
                                )
                            }
                            Text(
                                text = step,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showInstructions = false },
                    colors = ButtonDefaults.buttonColors(containerColor = game.accentStart, contentColor = BgObsidian)
                ) {
                    Text("Got It")
                }
            }
        )
    }
}
