package com.example.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.audio.SoundManager
import com.example.core.data.GameProgressEntity
import com.example.core.data.GameRepository
import com.example.core.model.Difficulty
import com.example.core.model.GameCatalog
import com.example.core.model.GameId
import com.example.core.model.GameInfo
import com.example.core.model.PlayerMode
import kotlinx.coroutines.launch

class GameSessionController(
    val game: GameInfo,
    val progress: GameProgressEntity?,
    val isMuted: Boolean,
    val onToggleMute: () -> Unit,
    val onSaveState: (String?) -> Unit,
    val onRecordResult: (score: Int, won: Boolean, clearSaved: Boolean) -> Unit,
    val onExit: () -> Unit
) {
    val bestScore: Int get() = progress?.bestScore ?: 0
    val savedStateJson: String? get() = progress?.savedStateJson
    val initialDifficulty: Difficulty
        get() = runCatching { Difficulty.valueOf(progress?.lastDifficulty ?: "MEDIUM") }.getOrDefault(Difficulty.MEDIUM)
    val initialPlayerMode: PlayerMode
        get() = runCatching { PlayerMode.valueOf(progress?.lastPlayerMode ?: "SINGLE_PLAYER") }.getOrDefault(PlayerMode.SINGLE_PLAYER)
}

@Composable
fun rememberGameSession(
    gameId: GameId,
    repository: GameRepository,
    onBack: () -> Unit
): GameSessionController? {
    val game = remember(gameId) { GameCatalog.getById(gameId) }
    val progress by repository.observeGame(gameId).collectAsStateWithLifecycle(initialValue = null)
    val isMuted by repository.isMuted.collectAsStateWithLifecycle(initialValue = false)
    val scope = rememberCoroutineScope()
    var loaded by remember { mutableStateOf(false) }
    var initialProgress by remember { mutableStateOf<GameProgressEntity?>(null) }

    LaunchedEffect(gameId) {
        val existing = repository.getProgress(gameId)
        initialProgress = existing
        val diff = runCatching { Difficulty.valueOf(existing?.lastDifficulty ?: "MEDIUM") }.getOrDefault(Difficulty.MEDIUM)
        val mode = runCatching { PlayerMode.valueOf(existing?.lastPlayerMode ?: "SINGLE_PLAYER") }.getOrDefault(PlayerMode.SINGLE_PLAYER)
        repository.markGameOpened(gameId, diff, mode)
        loaded = true
    }

    if (!loaded) return null

    val effectiveProgress = progress ?: initialProgress
    return GameSessionController(
        game = game,
        progress = effectiveProgress,
        isMuted = isMuted,
        onToggleMute = {
            scope.launch {
                val next = !isMuted
                repository.setMuted(next)
                if (!next) SoundManager.playTap()
            }
        },
        onSaveState = { json ->
            scope.launch {
                repository.saveInProgressState(gameId, json)
            }
        },
        onRecordResult = { score, won, clearSaved ->
            scope.launch {
                repository.recordGameResult(gameId, score, won, clearSaved)
            }
        },
        onExit = onBack
    )
}
