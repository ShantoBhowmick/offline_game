package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.GameId
import com.example.core.model.GameInfo
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GameThumbnail(
    game: GameInfo,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        game.accentStart.copy(alpha = 0.28f),
                        game.accentEnd.copy(alpha = 0.14f),
                        Color(0xFF0D1324)
                    )
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(6.dp)) {
            when (game.id) {
                GameId.LUDO -> drawLudoThumb()
                GameId.TWENTY_NINE -> draw29Thumb(textMeasurer)
                GameId.TIC_TAC_TOE -> drawTicTacToeThumb()
                GameId.CARROM -> drawCarromThumb()
                GameId.SNAKE -> drawSnakeThumb()
                GameId.CANDY_MATCH -> drawCandyThumb()
                GameId.SUDOKU -> drawSudokuThumb(textMeasurer)
                GameId.CHESS -> drawChessThumb()
                GameId.MINESWEEPER -> drawMinesweeperThumb(textMeasurer)
                GameId.GAME_2048 -> draw2048Thumb(textMeasurer)
                GameId.BUBBLE_SHOOTER -> drawBubbleThumb()
                GameId.MEMORY_MATCH -> drawMemoryThumb()
                GameId.BLOCK_PUZZLE -> drawBlockThumb()
                GameId.SOLITAIRE -> drawSolitaireThumb(textMeasurer)
                GameId.CHECKERS -> drawCheckersThumb()
                GameId.CONNECT_FOUR -> drawConnectFourThumb()
                GameId.FRUIT_SLICE -> drawFruitSliceThumb()
                GameId.WORD_PUZZLE -> drawWordThumb(textMeasurer)
                GameId.JIGSAW_PUZZLE -> drawJigsawThumb()
                GameId.NUMBER_PUZZLE -> drawSlide15Thumb(textMeasurer)
            }
        }
    }
}

private fun DrawScope.drawLudoThumb() {
    val s = minOf(size.width, size.height)
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val box = s * 0.36f
    val r = CornerRadius(s * 0.08f, s * 0.08f)
    drawRoundRect(Color(0xFFEF4444), Offset(ox, oy), Size(box, box), r)
    drawRoundRect(Color(0xFF22C55E), Offset(ox + s - box, oy), Size(box, box), r)
    drawRoundRect(Color(0xFF3B82F6), Offset(ox, oy + s - box), Size(box, box), r)
    drawRoundRect(Color(0xFFFACC15), Offset(ox + s - box, oy + s - box), Size(box, box), r)
    // Center home diamond
    val cx = ox + s / 2f
    val cy = oy + s / 2f
    drawCircle(Color.White.copy(alpha = 0.9f), s * 0.14f, Offset(cx, cy))
    drawCircle(Color(0xFFFFB800), s * 0.08f, Offset(cx, cy))
    // Pawns
    drawCircle(Color.White, s * 0.06f, Offset(ox + box * 0.5f, oy + box * 0.5f))
    drawCircle(Color.White, s * 0.06f, Offset(ox + s - box * 0.5f, oy + box * 0.5f))
}

private fun DrawScope.draw29Thumb(measurer: TextMeasurer) {
    val w = size.width * 0.42f
    val h = size.height * 0.72f
    val cy = size.height * 0.14f
    drawRoundRect(
        Color(0xFFF8FAFC),
        Offset(size.width * 0.18f, cy + 4f),
        Size(w, h),
        CornerRadius(10f, 10f)
    )
    drawRoundRect(
        Color(0xFF00E5FF),
        Offset(size.width * 0.40f, cy - 4f),
        Size(w, h),
        CornerRadius(10f, 10f)
    )
    val res = measurer.measure(
        "29",
        TextStyle(color = Color(0xFF070A13), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
    )
    drawText(
        res,
        topLeft = Offset(
            size.width * 0.40f + (w - res.size.width) / 2f,
            cy - 4f + (h - res.size.height) / 2f
        )
    )
}

private fun DrawScope.drawTicTacToeThumb() {
    val s = minOf(size.width, size.height) * 0.84f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val c = Color(0xFF64748B)
    for (i in 1..2) {
        val x = ox + s * i / 3f
        val y = oy + s * i / 3f
        drawLine(c, Offset(x, oy), Offset(x, oy + s), strokeWidth = 3f)
        drawLine(c, Offset(ox, y), Offset(ox + s, y), strokeWidth = 3f)
    }
    val cell = s / 3f
    // X in top-left
    val p = cell * 0.25f
    drawLine(Color(0xFF00E5FF), Offset(ox + p, oy + p), Offset(ox + cell - p, oy + cell - p), 5f, StrokeCap.Round)
    drawLine(Color(0xFF00E5FF), Offset(ox + cell - p, oy + p), Offset(ox + p, oy + cell - p), 5f, StrokeCap.Round)
    // O in center
    drawCircle(Color(0xFFFF2E93), cell * 0.28f, Offset(ox + cell * 1.5f, oy + cell * 1.5f), style = Stroke(5f))
    // X in bottom-right
    val bx = ox + cell * 2f
    val by = oy + cell * 2f
    drawLine(Color(0xFF00E5FF), Offset(bx + p, by + p), Offset(bx + cell - p, by + cell - p), 5f, StrokeCap.Round)
    drawLine(Color(0xFF00E5FF), Offset(bx + cell - p, by + p), Offset(bx + p, by + cell - p), 5f, StrokeCap.Round)
}

private fun DrawScope.drawCarromThumb() {
    val s = minOf(size.width, size.height) * 0.88f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    drawRoundRect(Color(0xFFF3D5A5), Offset(ox, oy), Size(s, s), CornerRadius(12f, 12f))
    drawRoundRect(Color(0xFF78350F), Offset(ox, oy), Size(s, s), CornerRadius(12f, 12f), style = Stroke(6f))
    val cx = ox + s / 2f
    val cy = oy + s / 2f
    drawCircle(Color(0xFF92400E), s * 0.24f, Offset(cx, cy), style = Stroke(2f))
    drawCircle(Color(0xFFEF4444), s * 0.08f, Offset(cx, cy))
    drawCircle(Color.White, s * 0.07f, Offset(cx - s * 0.14f, cy - s * 0.08f))
    drawCircle(Color(0xFF1E293B), s * 0.07f, Offset(cx + s * 0.14f, cy + s * 0.08f))
    drawCircle(Color(0xFF00E5FF), s * 0.09f, Offset(cx, oy + s * 0.8f))
}

private fun DrawScope.drawSnakeThumb() {
    val s = minOf(size.width, size.height)
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val seg = s * 0.18f
    val pts = listOf(
        Offset(ox + s * 0.15f, oy + s * 0.65f),
        Offset(ox + s * 0.33f, oy + s * 0.65f),
        Offset(ox + s * 0.33f, oy + s * 0.45f),
        Offset(ox + s * 0.51f, oy + s * 0.45f),
        Offset(ox + s * 0.51f, oy + s * 0.25f)
    )
    pts.forEachIndexed { idx, p ->
        val color = if (idx == pts.lastIndex) Color(0xFF34D399) else Color(0xFF10B981)
        drawRoundRect(color, p, Size(seg, seg), CornerRadius(6f, 6f))
    }
    drawCircle(Color(0xFFFF5A5F), s * 0.09f, Offset(ox + s * 0.78f, oy + s * 0.34f))
}

private fun DrawScope.drawCandyThumb() {
    val colors = listOf(Color(0xFFFF2E93), Color(0xFF00E5FF), Color(0xFFFFB800), Color(0xFF8B5CF6))
    val s = minOf(size.width, size.height) * 0.86f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val step = s / 3f
    for (r in 0..2) {
        for (c in 0..2) {
            val col = if (r == 1) colors[0] else colors[(r * 3 + c) % colors.size]
            val cx = ox + c * step + step / 2f
            val cy = oy + r * step + step / 2f
            drawCircle(col, step * 0.36f, Offset(cx, cy))
            drawCircle(Color.White.copy(alpha = 0.45f), step * 0.12f, Offset(cx - step * 0.1f, cy - step * 0.1f))
        }
    }
}

private fun DrawScope.drawSudokuThumb(measurer: TextMeasurer) {
    val s = minOf(size.width, size.height) * 0.84f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    drawRoundRect(Color(0xFF1E293B), Offset(ox, oy), Size(s, s), CornerRadius(8f, 8f))
    val step = s / 3f
    for (i in 1..2) {
        drawLine(Color(0xFF60A5FA), Offset(ox + step * i, oy), Offset(ox + step * i, oy + s), 2.5f)
        drawLine(Color(0xFF60A5FA), Offset(ox, oy + step * i), Offset(ox + s, oy + step * i), 2.5f)
    }
    val nums = listOf("9" to 0 to 0, "4" to 1 to 1, "7" to 2 to 0, "2" to 2 to 2)
    nums.forEach { (pair, row) ->
        val (txt, col) = pair
        val res = measurer.measure(txt, TextStyle(Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold))
        drawText(res, topLeft = Offset(ox + col * step + (step - res.size.width) / 2f, oy + row * step + (step - res.size.height) / 2f))
    }
}

private fun DrawScope.drawChessThumb() {
    val s = minOf(size.width, size.height) * 0.84f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val step = s / 4f
    for (r in 0..3) {
        for (c in 0..3) {
            val col = if ((r + c) % 2 == 0) Color(0xFFCBD5E1) else Color(0xFF334155)
            drawRect(col, Offset(ox + c * step, oy + r * step), Size(step, step))
        }
    }
    // Crown silhouette
    val cx = ox + s / 2f
    val cy = oy + s / 2f
    drawCircle(Color(0xFFFFB800), s * 0.22f, Offset(cx, cy))
    drawCircle(Color(0xFF0F172A), s * 0.14f, Offset(cx, cy), style = Stroke(3f))
}

private fun DrawScope.drawMinesweeperThumb(measurer: TextMeasurer) {
    val s = minOf(size.width, size.height) * 0.84f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val step = s / 3f
    for (r in 0..2) {
        for (c in 0..2) {
            val col = if (r == 1 && c == 1) Color(0xFF334155) else Color(0xFF1E293B)
            drawRoundRect(col, Offset(ox + c * step + 2f, oy + r * step + 2f), Size(step - 4f, step - 4f), CornerRadius(4f, 4f))
        }
    }
    drawCircle(Color(0xFFFF5A5F), step * 0.30f, Offset(ox + step * 1.5f, oy + step * 1.5f))
    val res = measurer.measure("2", TextStyle(Color(0xFF34D399), fontSize = 11.sp, fontWeight = FontWeight.Bold))
    drawText(res, topLeft = Offset(ox + (step - res.size.width) / 2f, oy + (step - res.size.height) / 2f))
}

private fun DrawScope.draw2048Thumb(measurer: TextMeasurer) {
    val s = minOf(size.width, size.height) * 0.86f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    drawRoundRect(Color(0xFFF59E0B), Offset(ox, oy), Size(s, s), CornerRadius(12f, 12f))
    val res = measurer.measure("2048", TextStyle(Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold))
    drawText(res, topLeft = Offset(ox + (s - res.size.width) / 2f, oy + (s - res.size.height) / 2f))
}

private fun DrawScope.drawBubbleThumb() {
    val colors = listOf(Color(0xFFFF2E93), Color(0xFF00E5FF), Color(0xFFFFB800), Color(0xFF10B981))
    val r = minOf(size.width, size.height) * 0.14f
    val cx = size.width / 2f
    val top = size.height * 0.25f
    drawCircle(colors[0], r, Offset(cx - r * 1.8f, top))
    drawCircle(colors[1], r, Offset(cx, top))
    drawCircle(colors[2], r, Offset(cx + r * 1.8f, top))
    drawCircle(colors[1], r, Offset(cx - r * 0.9f, top + r * 1.6f))
    drawCircle(colors[3], r, Offset(cx + r * 0.9f, top + r * 1.6f))
    drawCircle(colors[1], r, Offset(cx, size.height * 0.82f))
}

private fun DrawScope.drawMemoryThumb() {
    val w = size.width * 0.36f
    val h = size.height * 0.38f
    drawRoundRect(Color(0xFF8B5CF6), Offset(size.width * 0.10f, size.height * 0.10f), Size(w, h), CornerRadius(8f, 8f))
    drawRoundRect(Color(0xFFEC4899), Offset(size.width * 0.54f, size.height * 0.10f), Size(w, h), CornerRadius(8f, 8f))
    drawRoundRect(Color(0xFFEC4899), Offset(size.width * 0.10f, size.height * 0.54f), Size(w, h), CornerRadius(8f, 8f))
    drawRoundRect(Color(0xFF334155), Offset(size.width * 0.54f, size.height * 0.54f), Size(w, h), CornerRadius(8f, 8f))
}

private fun DrawScope.drawBlockThumb() {
    val s = minOf(size.width, size.height) * 0.24f
    val ox = size.width * 0.22f
    val oy = size.height * 0.20f
    val coords = listOf(0 to 0, 1 to 0, 2 to 0, 1 to 1, 1 to 2)
    coords.forEachIndexed { i, (c, r) ->
        val col = if (i < 3) Color(0xFF00E5FF) else Color(0xFF3B82F6)
        drawRoundRect(col, Offset(ox + c * (s + 3f), oy + r * (s + 3f)), Size(s, s), CornerRadius(5f, 5f))
    }
}

private fun DrawScope.drawSolitaireThumb(measurer: TextMeasurer) {
    val w = size.width * 0.42f
    val h = size.height * 0.72f
    drawRoundRect(Color(0xFF10B981), Offset(size.width * 0.16f, size.height * 0.16f), Size(w, h), CornerRadius(8f, 8f))
    drawRoundRect(Color.White, Offset(size.width * 0.42f, size.height * 0.12f), Size(w, h), CornerRadius(8f, 8f))
    val res = measurer.measure("A♠", TextStyle(Color(0xFF0F172A), fontSize = 14.sp, fontWeight = FontWeight.Bold))
    drawText(res, topLeft = Offset(size.width * 0.42f + (w - res.size.width) / 2f, size.height * 0.12f + (h - res.size.height) / 2f))
}

private fun DrawScope.drawCheckersThumb() {
    val s = minOf(size.width, size.height) * 0.84f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val step = s / 3f
    for (r in 0..2) {
        for (c in 0..2) {
            drawRect(if ((r + c) % 2 == 0) Color(0xFF94A3B8) else Color(0xFF1E293B), Offset(ox + c * step, oy + r * step), Size(step, step))
        }
    }
    drawCircle(Color(0xFFEF4444), step * 0.34f, Offset(ox + step * 0.5f, oy + step * 1.5f))
    drawCircle(Color(0xFFF8FAFC), step * 0.34f, Offset(ox + step * 2.5f, oy + step * 0.5f))
}

private fun DrawScope.drawConnectFourThumb() {
    val s = minOf(size.width, size.height) * 0.86f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    drawRoundRect(Color(0xFF1D4ED8), Offset(ox, oy), Size(s, s), CornerRadius(10f, 10f))
    val step = s / 4f
    for (r in 0..3) {
        for (c in 0..3) {
            val col = when {
                r == 3 && c in 0..2 -> Color(0xFFFACC15)
                r == 2 && c == 1 -> Color(0xFFEF4444)
                r == 3 && c == 3 -> Color(0xFFEF4444)
                else -> Color(0xFF070A13)
            }
            drawCircle(col, step * 0.33f, Offset(ox + c * step + step / 2f, oy + r * step + step / 2f))
        }
    }
}

private fun DrawScope.drawFruitSliceThumb() {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val r = minOf(size.width, size.height) * 0.36f
    drawArc(Color(0xFF22C55E), startAngle = 20f, sweepAngle = 175f, useCenter = true, topLeft = Offset(cx - r, cy - r), size = Size(r * 2, r * 2))
    drawArc(Color(0xFFFF5A5F), startAngle = 25f, sweepAngle = 165f, useCenter = true, topLeft = Offset(cx - r * 0.8f, cy - r * 0.8f), size = Size(r * 1.6f, r * 1.6f))
    drawLine(Color.White, Offset(size.width * 0.14f, size.height * 0.78f), Offset(size.width * 0.86f, size.height * 0.22f), strokeWidth = 5f, cap = StrokeCap.Round)
}

private fun DrawScope.drawWordThumb(measurer: TextMeasurer) {
    val letters = listOf("W" to Color(0xFF10B981), "O" to Color(0xFFF59E0B), "R" to Color(0xFF10B981), "D" to Color(0xFF475569))
    val box = minOf(size.width / 4.6f, size.height * 0.55f)
    val startX = (size.width - box * 4 - 9f) / 2f
    val y = (size.height - box) / 2f
    letters.forEachIndexed { idx, (ch, col) ->
        val x = startX + idx * (box + 3f)
        drawRoundRect(col, Offset(x, y), Size(box, box), CornerRadius(5f, 5f))
        val res = measurer.measure(ch, TextStyle(Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold))
        drawText(res, topLeft = Offset(x + (box - res.size.width) / 2f, y + (box - res.size.height) / 2f))
    }
}

private fun DrawScope.drawJigsawThumb() {
    val s = minOf(size.width, size.height) * 0.76f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val h = s / 2f
    drawRoundRect(Color(0xFFA855F7), Offset(ox, oy), Size(h - 2f, h - 2f), CornerRadius(6f, 6f))
    drawRoundRect(Color(0xFF6366F1), Offset(ox + h + 2f, oy), Size(h - 2f, h - 2f), CornerRadius(6f, 6f))
    drawRoundRect(Color(0xFFEC4899), Offset(ox, oy + h + 2f), Size(h - 2f, h - 2f), CornerRadius(6f, 6f))
    drawCircle(Color(0xFFA855F7), h * 0.24f, Offset(ox + h, oy + h * 0.5f))
    drawCircle(Color(0xFF6366F1), h * 0.24f, Offset(ox + h * 1.5f, oy + h))
}

private fun DrawScope.drawSlide15Thumb(measurer: TextMeasurer) {
    val s = minOf(size.width, size.height) * 0.84f
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val step = s / 2f
    val items = listOf("1", "2", "3", "")
    items.forEachIndexed { idx, label ->
        if (label.isNotEmpty()) {
            val r = idx / 2
            val c = idx % 2
            val x = ox + c * step + 2f
            val y = oy + r * step + 2f
            drawRoundRect(Color(0xFF0EA5E9), Offset(x, y), Size(step - 4f, step - 4f), CornerRadius(7f, 7f))
            val res = measurer.measure(label, TextStyle(Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold))
            drawText(res, topLeft = Offset(x + (step - 4f - res.size.width) / 2f, y + (step - 4f - res.size.height) / 2f))
        }
    }
}
