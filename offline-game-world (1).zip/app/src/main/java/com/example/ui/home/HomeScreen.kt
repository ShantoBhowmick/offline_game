package com.example.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.audio.SoundManager
import com.example.core.model.GameCategory
import com.example.core.model.GameId
import com.example.ui.components.GameThumbnail
import com.example.ui.theme.BgObsidian
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    uiState: HomeUiState,
    onSearchQueryChange: (String) -> Unit,
    onCategorySelected: (GameCategory) -> Unit,
    onToggleFavorite: (GameId) -> Unit,
    onToggleMute: () -> Unit,
    onOpenGame: (GameId) -> Unit
) {
    val isSearching = uiState.searchQuery.isNotBlank()

    Scaffold(
        containerColor = BgObsidian,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // 1. Header with App Logo & Offline Status + Sound Mute
            item {
                HomeTopBar(
                    isMuted = uiState.isMuted,
                    totalPlayed = uiState.totalGamesPlayed,
                    totalWins = uiState.totalWins,
                    onToggleMute = onToggleMute
                )
            }

            // 2. Search Games Bar
            item {
                SearchBar(
                    query = uiState.searchQuery,
                    onQueryChange = onSearchQueryChange,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            if (!isSearching) {
                // 3. Hero Banner
                item {
                    HeroArcadeBanner(
                        featuredLead = uiState.recentGames.firstOrNull() ?: uiState.featuredGames.firstOrNull(),
                        isResume = uiState.recentGames.firstOrNull()?.hasSavedState == true,
                        onLaunch = { gameId ->
                            SoundManager.playTap()
                            onOpenGame(gameId)
                        },
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }

                // 4. Recently Played Section (only when user has opened games)
                if (uiState.recentGames.isNotEmpty()) {
                    item {
                        SectionHeader(
                            title = "Recently Played",
                            icon = Icons.Default.History,
                            iconTint = NeonCyan
                        )
                    }
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(uiState.recentGames, key = { "recent_${it.info.id}" }) { item ->
                                CompactHorizontalGameCard(
                                    item = item,
                                    onClick = {
                                        SoundManager.playTap()
                                        onOpenGame(item.info.id)
                                    },
                                    onToggleFavorite = { onToggleFavorite(item.info.id) }
                                )
                            }
                        }
                    }
                }

                // 5. Featured Games Section
                item {
                    SectionHeader(
                        title = "Featured Games",
                        icon = Icons.Default.Star,
                        iconTint = NeonAmber
                    )
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(uiState.featuredGames, key = { "feat_${it.info.id}" }) { item ->
                            FeaturedGameCard(
                                item = item,
                                onClick = {
                                    SoundManager.playTap()
                                    onOpenGame(item.info.id)
                                },
                                onToggleFavorite = { onToggleFavorite(item.info.id) }
                            )
                        }
                    }
                }

                // 6. Popular Games Section
                item {
                    SectionHeader(
                        title = "Popular Picks",
                        icon = Icons.Default.LocalFireDepartment,
                        iconTint = NeonMagenta
                    )
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(uiState.popularGames, key = { "pop_${it.info.id}" }) { item ->
                            CompactHorizontalGameCard(
                                item = item,
                                onClick = {
                                    SoundManager.playTap()
                                    onOpenGame(item.info.id)
                                },
                                onToggleFavorite = { onToggleFavorite(item.info.id) }
                            )
                        }
                    }
                }

                // 7. Favorites Section
                item {
                    SectionHeader(
                        title = "Favorites",
                        icon = Icons.Default.Favorite,
                        iconTint = NeonMagenta
                    )
                }
                item {
                    if (uiState.favoriteGames.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(SurfaceCard)
                                .border(1.dp, SurfaceBorder, RoundedCornerShape(16.dp))
                                .padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FavoriteBorder,
                                    contentDescription = null,
                                    tint = NeonMagenta,
                                    modifier = Modifier.size(28.dp)
                                )
                                Text(
                                    text = "Tap the heart icon on any game card to pin your go-to offline favorites here.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                    } else {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(uiState.favoriteGames, key = { "fav_${it.info.id}" }) { item ->
                                CompactHorizontalGameCard(
                                    item = item,
                                    onClick = {
                                        SoundManager.playTap()
                                        onOpenGame(item.info.id)
                                    },
                                    onToggleFavorite = { onToggleFavorite(item.info.id) }
                                )
                            }
                        }
                    }
                }
            }

            // 8. All Games Category Filter & Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionHeader(
                        title = if (isSearching) "Search Results (${uiState.filteredAllGames.size})" else "All 20 Offline Games",
                        icon = Icons.Default.SportsEsports,
                        iconTint = NeonViolet
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(GameCategory.entries) { category ->
                            val selected = category == uiState.selectedCategory
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(
                                        if (selected) Brush.horizontalGradient(listOf(NeonCyan, NeonViolet))
                                        else Brush.horizontalGradient(listOf(SurfaceCard, SurfaceCard))
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (selected) Color.Transparent else SurfaceBorder,
                                        shape = RoundedCornerShape(50)
                                    )
                                    .clickable {
                                        SoundManager.playTap()
                                        onCategorySelected(category)
                                    }
                                    .padding(horizontal = 16.dp, vertical = 9.dp)
                                    .testTag("category_${category.name.lowercase()}")
                            ) {
                                Text(
                                    text = category.displayName,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) BgObsidian else TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            if (uiState.filteredAllGames.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            text = "No matching games found",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "Try a different keyword or switch back to All Games.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            } else {
                val rows = uiState.filteredAllGames.chunked(2)
                items(rows, key = { row -> row.joinToString("_") { it.info.id.routeKey } }) { pair ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        pair.forEach { item ->
                            GridGameCard(
                                item = item,
                                onClick = {
                                    SoundManager.playTap()
                                    onOpenGame(item.info.id)
                                },
                                onToggleFavorite = { onToggleFavorite(item.info.id) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeTopBar(
    isMuted: Boolean,
    totalPlayed: Int,
    totalWins: Int,
    onToggleMute: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 12.dp, top = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Logo Emblem
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.linearGradient(listOf(NeonCyan, NeonViolet, NeonMagenta))
                )
                .padding(2.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_launcher_art),
                contentDescription = "Offline Game World Logo",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "Offline Game World",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(NeonEmerald.copy(alpha = 0.16f))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WifiOff,
                        contentDescription = null,
                        tint = NeonEmerald,
                        modifier = Modifier.size(11.dp)
                    )
                    Text(
                        text = "100% OFFLINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonEmerald
                    )
                }
                if (totalPlayed > 0) {
                    Text(
                        text = "$totalPlayed played • $totalWins wins",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
        }

        IconButton(
            onClick = onToggleMute,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(SurfaceCard)
                .testTag("home_mute_button")
        ) {
            Icon(
                imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                contentDescription = if (isMuted) "Unmute Sound Effects" else "Mute Sound Effects",
                tint = if (isMuted) TextMuted else NeonCyan
            )
        }
    }
}

@Composable
private fun SearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceCard)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search games",
            tint = NeonCyan,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Box(modifier = Modifier.weight(1f)) {
            if (query.isEmpty()) {
                Text(
                    text = "Search 20 games (Ludo, Chess, 29, Snake...)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                cursorBrush = SolidColor(NeonCyan),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search_input")
            )
        }
        AnimatedVisibility(visible = query.isNotEmpty()) {
            IconButton(
                onClick = { onQueryChange("") },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Clear search",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun HeroArcadeBanner(
    featuredLead: GameCardItem?,
    isResume: Boolean,
    onLaunch: (GameId) -> Unit,
    modifier: Modifier = Modifier
) {
    val lead = featuredLead ?: return
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(152.dp)
            .clip(RoundedCornerShape(22.dp))
            .border(1.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(22.dp))
            .clickable { onLaunch(lead.info.id) }
            .testTag("hero_banner_play")
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_hero_arcade),
            contentDescription = "Offline Arcade Showcase",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color(0xE6070A13),
                            Color(0xB80D1221),
                            Color(0x40070A13)
                        )
                    )
                )
        )
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    color = (if (isResume) NeonEmerald else NeonCyan).copy(alpha = 0.20f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (isResume) "CONTINUE SAVED GAME" else "SPOTLIGHT GAME",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isResume) NeonEmerald else NeonCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                Text(
                    text = lead.info.title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = lead.info.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Brush.horizontalGradient(listOf(lead.info.accentStart, lead.info.accentEnd)))
                        .padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = BgObsidian,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (isResume) "Resume" else "Play Now",
                        style = MaterialTheme.typography.labelLarge,
                        color = BgObsidian,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            GameThumbnail(
                game = lead.info,
                modifier = Modifier
                    .size(96.dp)
                    .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(14.dp))
            )
        }
    }
}

@Composable
private fun SectionHeader(
    title: String,
    icon: ImageVector,
    iconTint: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = TextPrimary
        )
    }
}

@Composable
private fun FeaturedGameCard(
    item: GameCardItem,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    val game = item.info
    Column(
        modifier = Modifier
            .width(214.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(SurfaceCard)
            .border(1.dp, game.accentStart.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
            .testTag("featured_card_${game.id.routeKey}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(112.dp)
        ) {
            GameThumbnail(
                game = game,
                modifier = Modifier.fillMaxSize()
            )
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(36.dp)
                    .padding(4.dp)
                    .clip(CircleShape)
                    .background(BgObsidian.copy(alpha = 0.65f))
            ) {
                Icon(
                    imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Toggle favorite",
                    tint = if (item.isFavorite) NeonMagenta else TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(BgObsidian.copy(alpha = 0.78f))
                    .padding(horizontal = 7.dp, vertical = 2.dp)
            ) {
                Text(
                    text = game.playersLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = game.accentStart
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = game.title,
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = game.subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = game.category.displayName.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = game.accentStart
            )
            if (item.hasSavedState) {
                Text(
                    text = "RESUME",
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonEmerald
                )
            } else if (item.bestScore > 0) {
                Text(
                    text = "BEST ${item.bestScore}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun CompactHorizontalGameCard(
    item: GameCardItem,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    val game = item.info
    Column(
        modifier = Modifier
            .width(146.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(SurfaceCard)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(10.dp)
            .testTag("compact_card_${game.id.routeKey}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(88.dp)
        ) {
            GameThumbnail(game = game, modifier = Modifier.fillMaxSize())
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(32.dp)
                    .padding(3.dp)
                    .clip(CircleShape)
                    .background(BgObsidian.copy(alpha = 0.65f))
            ) {
                Icon(
                    imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Toggle favorite",
                    tint = if (item.isFavorite) NeonMagenta else TextSecondary,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = game.title,
            style = MaterialTheme.typography.titleSmall,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = if (item.hasSavedState) "Saved • Tap to resume" else game.category.displayName,
            style = MaterialTheme.typography.labelSmall,
            color = if (item.hasSavedState) NeonEmerald else TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun GridGameCard(
    item: GameCardItem,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val game = item.info
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(SurfaceCard)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(10.dp)
            .testTag("game_card_${game.id.routeKey}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.32f)
        ) {
            GameThumbnail(game = game, modifier = Modifier.fillMaxSize())

            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(34.dp)
                    .padding(4.dp)
                    .clip(CircleShape)
                    .background(BgObsidian.copy(alpha = 0.65f))
            ) {
                Icon(
                    imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Toggle favorite",
                    tint = if (item.isFavorite) NeonMagenta else TextSecondary,
                    modifier = Modifier.size(15.dp)
                )
            }

            if (item.hasSavedState) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(5.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(NeonEmerald.copy(alpha = 0.9f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "SAVED",
                        style = MaterialTheme.typography.labelSmall,
                        color = BgObsidian
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = game.title,
            style = MaterialTheme.typography.titleSmall,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = game.subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(SurfaceElevated)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = game.category.displayName,
                    style = MaterialTheme.typography.labelSmall,
                    color = game.accentStart
                )
            }
            Text(
                text = if (item.bestScore > 0) "★ ${item.bestScore}" else game.playersLabel,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }
    }
}
