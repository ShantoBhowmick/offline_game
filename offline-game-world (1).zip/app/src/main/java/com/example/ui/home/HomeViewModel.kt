package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.core.audio.SoundManager
import com.example.core.data.GameProgressEntity
import com.example.core.data.GameRepository
import com.example.core.model.GameCatalog
import com.example.core.model.GameCategory
import com.example.core.model.GameId
import com.example.core.model.GameInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class GameCardItem(
    val info: GameInfo,
    val progress: GameProgressEntity?
) {
    val isFavorite: Boolean get() = progress?.isFavorite == true
    val bestScore: Int get() = progress?.bestScore ?: 0
    val hasSavedState: Boolean get() = !progress?.savedStateJson.isNullOrBlank()
    val lastPlayed: Long get() = progress?.lastPlayedTimestamp ?: 0L
}

data class HomeUiState(
    val searchQuery: String = "",
    val selectedCategory: GameCategory = GameCategory.ALL,
    val isMuted: Boolean = false,
    val featuredGames: List<GameCardItem> = emptyList(),
    val popularGames: List<GameCardItem> = emptyList(),
    val recentGames: List<GameCardItem> = emptyList(),
    val favoriteGames: List<GameCardItem> = emptyList(),
    val filteredAllGames: List<GameCardItem> = emptyList(),
    val totalGamesPlayed: Int = 0,
    val totalWins: Int = 0
)

class HomeViewModel(private val repository: GameRepository) : ViewModel() {

    private val searchQuery = MutableStateFlow("")
    private val selectedCategory = MutableStateFlow(GameCategory.ALL)

    init {
        viewModelScope.launch {
            repository.isMuted.collect { muted ->
                SoundManager.isMuted = muted
            }
        }
    }

    val uiState: StateFlow<HomeUiState> = combine(
        repository.allProgress,
        repository.isMuted,
        searchQuery,
        selectedCategory
    ) { progressList, muted, query, category ->
        val progressMap = progressList.associateBy { it.gameId }
        val allItems = GameCatalog.games.map { info ->
            GameCardItem(info = info, progress = progressMap[info.id.routeKey])
        }

        val q = query.trim().lowercase()
        val filtered = allItems.filter { item ->
            val matchesCat = category == GameCategory.ALL || item.info.category == category
            val matchesQuery = q.isEmpty() ||
                item.info.title.lowercase().contains(q) ||
                item.info.subtitle.lowercase().contains(q) ||
                item.info.category.displayName.lowercase().contains(q)
            matchesCat && matchesQuery
        }

        val recent = allItems
            .filter { it.lastPlayed > 0L }
            .sortedByDescending { it.lastPlayed }
            .take(8)

        val favorites = allItems.filter { it.isFavorite }
        val featured = allItems.filter { it.info.isFeatured }
        val popular = allItems.filter { it.info.isPopular }

        HomeUiState(
            searchQuery = query,
            selectedCategory = category,
            isMuted = muted,
            featuredGames = featured,
            popularGames = popular,
            recentGames = recent,
            favoriteGames = favorites,
            filteredAllGames = filtered,
            totalGamesPlayed = progressList.sumOf { it.gamesPlayed },
            totalWins = progressList.sumOf { it.gamesWon }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState(
            featuredGames = GameCatalog.games.filter { it.isFeatured }.map { GameCardItem(it, null) },
            popularGames = GameCatalog.games.filter { it.isPopular }.map { GameCardItem(it, null) },
            filteredAllGames = GameCatalog.games.map { GameCardItem(it, null) }
        )
    )

    fun onSearchQueryChange(query: String) {
        searchQuery.value = query
    }

    fun onCategorySelected(category: GameCategory) {
        selectedCategory.value = category
    }

    fun onToggleFavorite(gameId: GameId) {
        viewModelScope.launch {
            repository.toggleFavorite(gameId)
        }
    }

    fun onToggleMute() {
        viewModelScope.launch {
            val next = !uiState.value.isMuted
            repository.setMuted(next)
            if (!next) SoundManager.playTap()
        }
    }

    class Factory(private val repository: GameRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(repository) as T
        }
    }
}
