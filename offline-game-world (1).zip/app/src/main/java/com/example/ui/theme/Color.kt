package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Dark Gaming Surfaces
val BgObsidian = Color(0xFF070A13)
val BgNavy = Color(0xFF0D1221)
val SurfaceCard = Color(0xFF131B31)
val SurfaceElevated = Color(0xFF1A2442)
val SurfaceBorder = Color(0xFF28355C)

// Neon Accents
val NeonCyan = Color(0xFF00E5FF)
val NeonViolet = Color(0xFF8B5CF6)
val NeonMagenta = Color(0xFFFF2E93)
val NeonAmber = Color(0xFFFFB800)
val NeonEmerald = Color(0xFF10B981)
val NeonCoral = Color(0xFFFF5A5F)
val NeonBlue = Color(0xFF3B82F6)

// Text Hierarchy
val TextPrimary = Color(0xFFF4F7FF)
val TextSecondary = Color(0xFFA7B3D1)
val TextMuted = Color(0xFF6B789B)
