package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val GamingDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = BgObsidian,
    primaryContainer = SurfaceElevated,
    onPrimaryContainer = NeonCyan,
    secondary = NeonViolet,
    onSecondary = TextPrimary,
    secondaryContainer = ColorTokens.VioletContainer,
    onSecondaryContainer = TextPrimary,
    tertiary = NeonMagenta,
    onTertiary = TextPrimary,
    background = BgObsidian,
    onBackground = TextPrimary,
    surface = BgNavy,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceBorder,
    error = NeonCoral,
    onError = TextPrimary
)

private object ColorTokens {
    val VioletContainer = androidx.compose.ui.graphics.Color(0xFF281C4D)
}

val GamingShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun OfflineGameWorldTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GamingDarkColorScheme,
        typography = AppTypography,
        shapes = GamingShapes,
        content = content
    )
}
