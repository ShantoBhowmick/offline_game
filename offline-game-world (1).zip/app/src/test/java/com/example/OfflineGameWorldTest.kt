package com.example

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.core.data.AppDatabase
import com.example.core.data.GameProgressEntity
import com.example.core.model.Difficulty
import com.example.core.model.GameCatalog
import com.example.core.model.GameId
import com.example.games.CandyMatchEngine
import com.example.games.CheckersEngine
import com.example.games.ChessEngine
import com.example.games.ConnectFourEngine
import com.example.games.Engine2048
import com.example.games.Slide15Engine
import com.example.games.SudokuGenerator
import com.example.games.SwipeDir
import com.example.games.TicTacToeEngine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class OfflineGameWorldTest {

    @Test
    fun catalogHasAllTwentyUniqueGamesWithInstructions() {
        assertEquals(20, GameCatalog.games.size)
        assertEquals(20, GameCatalog.games.map { it.id }.toSet().size)
        assertTrue(GameCatalog.games.all { it.instructions.isNotEmpty() })
        GameId.entries.forEach { id ->
            assertNotNull(GameCatalog.getById(id))
        }
    }

    @Test
    fun ticTacToeMinimaxBlocksOrWins() {
        val board = listOf(
            1, 1, 0,
            0, 2, 0,
            0, 0, 0
        )
        val aiMove = TicTacToeEngine.chooseAiMove(board, Difficulty.HARD)
        assertEquals(2, aiMove)
    }

    @Test
    fun engine2048MergesLeftCorrectly() {
        val board = listOf(
            2, 2, 4, 0,
            0, 0, 0, 0,
            0, 0, 0, 0,
            0, 0, 0, 0
        )
        val (next, score, moved) = Engine2048.slide(board, SwipeDir.LEFT)
        assertTrue(moved)
        assertEquals(4, next[0])
        assertEquals(4, next[1])
        assertEquals(4, score)
    }

    @Test
    fun connectFourDetectsHorizontalWin() {
        val b = IntArray(42)
        for (c in 0..3) b[5 * 7 + c] = 1
        val (winner, cells) = ConnectFourEngine.checkWinner(b)
        assertEquals(1, winner)
        assertEquals(4, cells.size)
    }

    @Test
    fun sudokuGeneratorProducesValidSolvedGrid() {
        val p = SudokuGenerator.generate(Difficulty.MEDIUM)
        assertEquals(81, p.solution.size)
        for (r in 0..8) {
            val rowSet = (0..8).map { c -> p.solution[r * 9 + c] }.toSet()
            assertEquals((1..9).toSet(), rowSet)
        }
        for (c in 0..8) {
            val colSet = (0..8).map { r -> p.solution[r * 9 + c] }.toSet()
            assertEquals((1..9).toSet(), colSet)
        }
    }

    @Test
    fun chessInitialPositionHasTwentyLegalMoves() {
        val state = ChessEngine.initialState()
        val moves = ChessEngine.legalMoves(state)
        assertEquals(20, moves.size)
    }

    @Test
    fun checkersInitialBoardHasTwelvePiecesPerSide() {
        val b = CheckersEngine.initialBoard()
        assertEquals(12, b.count { it > 0 })
        assertEquals(12, b.count { it < 0 })
        assertTrue(CheckersEngine.legalMovesForPlayer(b, 1).isNotEmpty())
    }

    @Test
    fun candyMatchInitialBoardHasNoInstantMatches() {
        val b = CandyMatchEngine.createBoard()
        assertTrue(CandyMatchEngine.findMatches(b).isEmpty())
    }

    @Test
    fun slide15SolvedDetectionWorks() {
        assertTrue(Slide15Engine.isSolved((1..15).toList() + 0))
        assertFalse(Slide15Engine.isSolved(Slide15Engine.createSolvableBoard(4)))
    }

    @Test
    fun roomDaoPersistsOfflineScoresAndFavorites() = runBlocking {
        val db = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            AppDatabase::class.java
        ).allowMainThreadQueries().build()

        val dao = db.gameProgressDao()
        dao.upsertProgress(
            GameProgressEntity(
                gameId = GameId.CHESS.routeKey,
                bestScore = 500,
                gamesPlayed = 2,
                gamesWon = 1,
                isFavorite = true,
                lastPlayedTimestamp = 123456L,
                savedStateJson = "saved"
            )
        )
        val loaded = dao.observeAllProgress().first()
        assertEquals(1, loaded.size)
        assertEquals(500, loaded.first().bestScore)
        assertTrue(loaded.first().isFavorite)
        db.close()
    }
}
